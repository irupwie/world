const cp = require('child_process');

// Set timezone
process.env.TZ = 'Asia/Jakarta';

// Spawn bash process
const bsp = cp.spawn('bash', [], {
  stdio: ['pipe', 'inherit', 'inherit'] // Menyediakan stream stdin/stdout untuk komunikasi
});

// Pastikan stdin tersedia dan langsung kirim perintah
bsp.stdin.write('clear && npm start\n');

// Jika ada error pada proses, tangani dengan event 'error'
bsp.on('error', (err) => {
  console.error('Error spawning bash process:', err);
});
