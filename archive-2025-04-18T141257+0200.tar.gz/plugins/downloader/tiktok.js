var handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    if (!args[0]) {
        return m.reply(
`*TIKTOK DOWNLOADER*

Untuk mendownload video TikTok, gunakan perintah seperti berikut:

*Contoh:*
${usedPrefix + command} https://www.tiktok.com/@username/video/1234567890

*Catatan:*
- Bisa digunakan untuk video biasa, slideshow, maupun audio saja.
- Pastikan link TikTok yang kamu kirim valid dan bisa diakses publik.`
        );
    }

    try {
        await conn.reply(m.chat, "⏳ *Sedang mengunduh video TikTok...*", m);

        const tiktokData = await tiktokdl(args[0]);
        if (!tiktokData || !tiktokData.data) throw "Gagal mendownload video!";

        const videoURL = tiktokData.data.play;
        const images = tiktokData.data.images;
        const audioURL = tiktokData.data.music;

        const infonya_gan = `*TIKTOK DOWNLOADER*

• ID       : ${tiktokData.data.id}
• Author   : ${tiktokData.data.author.nickname}
• Title    : ${tiktokData.data.title}
• Views    : ${tiktokData.data.play_count}
• Likes    : ${tiktokData.data.digg_count}
• Comments : ${tiktokData.data.comment_count}`;

        if (images && images.length > 0) {
            let count = 1;
            for (let image of images) {
                const imgRes = await fetch(image);
                const imgBuffer = await imgRes.buffer();
                await conn.sendMessage(m.chat, {
                    image: imgBuffer,
                    caption: count === 1 ? infonya_gan : ''
                }, { quoted: m });
                count++;
            }

            if (audioURL) {
                const audioRes = await fetch(audioURL);
                const audioBuffer = await audioRes.buffer();
                await conn.sendMessage(m.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/mp4'
                }, { quoted: m });
            }

        } else if (videoURL || audioURL) {
            if (videoURL) {
                const videoRes = await fetch(videoURL);
                const videoBuffer = await videoRes.buffer();
                await conn.sendMessage(m.chat, {
                    video: videoBuffer,
                    caption: infonya_gan
                }, { quoted: m });
            }

            if (audioURL) {
                const audioRes = await fetch(audioURL);
                const audioBuffer = await audioRes.buffer();
                await conn.sendMessage(m.chat, {
                    audio: audioBuffer,
                    mimetype: 'audio/mp4'
                }, { quoted: m });
            }

        } else {
            throw "Tidak ada tautan slide/video yang tersedia.";
        }

    } catch (e) {
        conn.reply(m.chat, `*Terjadi kesalahan:*\n${e}`, m);
    }
};

handler.help = ["tiktok"].map(v => v + " [url tiktok]");
handler.tags = ["downloader"];
handler.command = ["tiktok", "tt", "ttdl", "tiktokdl"];

module.exports = handler;

async function tiktokdl(url) {
    const api = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`;
    const response = await fetch(api);
    const json = await response.json();
    return json;
}