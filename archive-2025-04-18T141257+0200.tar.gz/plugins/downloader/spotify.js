const axios = require('axios')

const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `Usage: ${usedPrefix + command} <url>`

    const url = args[0]
    m.reply(wait)

    try {
        const response = await axios.get(`https://api.ryzendesu.vip/api/downloader/spotify?url=${encodeURIComponent(url)}`)
        const data = response.data

        if (data.success) {
            if (data.metadata.playlistName) {
                const playlistName = data.metadata.playlistName
                const cover = data.metadata.cover
                const tracks = data.tracks

                m.reply(`*Playlist:* ${playlistName}\n*Cover:* ${cover}\n*Total Tracks:* ${tracks.length}`)

                for (let i = 0; i < tracks.length; i++) {
                    const track = tracks[i]

                    if (track.success) {
                        const { title, artists, album, cover, releaseDate } = track.metadata
                        const link = track.link

                        const audioResponse = await axios.get(link, { responseType: 'arraybuffer' })
                        const audioBuffer = audioResponse.data

                        await conn.sendMessage(m.chat, {
                            document: audioBuffer,
                            mimetype: 'audio/mpeg',
                            fileName: `${title}.mp3`,
                            caption: `
*Title:* ${title}
*Artists:* ${artists}
*Album:* ${album}
*Release Date:* ${releaseDate}
*Cover:* ${cover}
                            `,
                        }, { quoted: m })

                        await delay(1500)
                    } else {
                        m.reply(`Error: Failed to download track ${i + 1}`)
                    }
                }
            } else {
                const { title, artists, album, cover, releaseDate } = data.metadata
                const link = data.link

                const audioResponse = await axios.get(link, { responseType: 'arraybuffer' })
                const audioBuffer = audioResponse.data

                await conn.sendMessage(m.chat, {
                    document: audioBuffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`,
                    caption: `
*Title:* ${title}
*Artists:* ${artists}
*Album:* ${album}
*Release Date:* ${releaseDate}
*Cover:* ${cover}
                    `,
                }, { quoted: m })
            }
        } else {
            throw 'Error: Failed to download. Please check the URL and try again.'
        }
    } catch (err) {
        console.error(err)
        throw `Error: ${err.message}`
    }
}

handler.help = ['spotify']
handler.tags = ['downloader']
handler.command = ["spotify", "spotifydl"]
handler.limit = true

module.exports = handler