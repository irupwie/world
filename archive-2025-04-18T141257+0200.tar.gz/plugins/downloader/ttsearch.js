const axios = require("axios");

async function ttSearch(query) {
    return new Promise(async (resolve, reject) => {
        axios("https://tikwm.com/api/feed/search", {
            headers: {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                cookie: "current_language=en",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            data: {
                keywords: query,
                count: 12,
                cursor: 0,
                web: 1,
                hd: 1,
            },
            method: "POST",
        }).then((res) => {
            resolve(res.data.data);
        });
    });
}

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[query]*`;
    let [keyword, data] = text.split("•");

    try {
        if (keyword === "videos" || keyword === "audios") {
            if (!data) throw "*• Link data tidak ditemukan!*";
            let url = "https://tikwm.com" + data.trim();
            await conn.sendMessage(m.chat, {
                text: `*Download Link:*\n${url}`
            }, {
                quoted: m
            });
        } else {
            let search = await (await ttSearch(text)).videos;
            if (!search || !search.length) throw "*• Tidak ada hasil ditemukan!*";

            let resultText = `*• Hasil pencarian dari:* ${text}\n*• Total Video:* ${search.length}\n\n`;
            search.forEach((i, a) => {
                resultText += `*${a + 1}. ${i.title}*\n`;
                resultText += `• Region: ${i.region}\n`;
                resultText += `• Author: ${i.author.nickname}\n`;
                resultText += `• Video: ${usedPrefix + command} videos•${i.play}\n`;
                resultText += `• Audio: ${usedPrefix + command} audios•${i.music}\n\n`;
            });

            await conn.sendMessage(m.chat, {
                text: resultText.trim()
            }, {
                quoted: m
            });
        }
    } catch (e) {
        console.log(e);
        throw "*• Terjadi kesalahan saat memproses permintaan!*";
    }
};

handler.help = ["tiktoks", "ttsearch"].map((a) => a + " *[query]*");
handler.tags = ["downloader"];
handler.command = ["tiktoks", "ttsearch", "tiktoksearch"];

module.exports = handler;