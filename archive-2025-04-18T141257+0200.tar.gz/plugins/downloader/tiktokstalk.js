const fetch = require("node-fetch");
const cheerio = require("cheerio");

module.exports = {
  help: ["tiktostalk", "tiktok_stalk"],
  tags: ["downloader"],
  command: ["tiktokstalk", "tiktok_stalk", "ttstalk"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      args,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[username]*`;
    m.reply(wait);
    
    let result = await tiktokStalk(text.split(" ").join(""));
    if (!result || result.status === "error") {
      throw `*• Gagal mengambil data akun TikTok.*\n*• Alasan:* ${result.message || 'Unknown error'}`;
    }

    let cap = `*[ TIKTOK - STALK ]*
*• Nickname :* ${result.user.nickname}
*• Id :* ${result.user.id}
*• Region :* ${result.user.region}
*• Bio :* ${result.user.signature || '-'}
*• Followers :* ${result.stats.followerCount}
*• Following :* ${result.stats.followingCount}
*• Total Hearts :* ${result.stats.heartCount}
*• Total Videos :* ${result.stats.videoCount}
*• Url :* https://tiktok.com/@${result.user.uniqueId}`;

    conn.sendMessage(
      m.chat,
      { image: { url: result.user.avatarThumb }, caption: cap },
      { quoted: m },
    );
  },
};

async function tiktokStalk(username) {
  try {
    const res = await fetch(`https://www.tiktok.com/@${username}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
      },
    });

    const html = await res.text();
    const $ = cheerio.load(html);
    const rawData = $("#__UNIVERSAL_DATA_FOR_REHYDRATION__").text();
    const json = JSON.parse(rawData);
    const scope = json["__DEFAULT_SCOPE__"];
    const userDetail = scope?.["webapp.user-detail"];

    if (!userDetail || userDetail.statusCode !== 0) {
      return { status: "error", message: "User tidak ditemukan atau konten dibatasi berdasarkan region/IP." };
    }

    const userInfo = userDetail["userInfo"];
    if (!userInfo?.user?.uniqueId) {
      return { status: "error", message: "Akun tidak ditemukan atau bersifat privat." };
    }

    return userInfo;
  } catch (err) {
    console.log("[TIKTOK STALK ERROR]", err);
    return { status: "error", message: err.message };
  }
}