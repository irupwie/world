let timeout = 30000;

let handler = async (m, {
    conn
}) => {
    conn.tebaklagu = conn.tebaklagu || {};
    let id = m.chat;
    if (id in conn.tebaklagu) {
        conn.reply(m.chat, "You already have a question to answer!", conn.tebaklagu[id][0]);
        return;
    }

    let res = await fetch("https://raw.githubusercontent.com/qisyana/scrape/main/tebaklagu.json");
    if (!res.ok) return m.reply("Failed to fetch data.");

    let src = await res.json();
    let json = src[Math.floor(Math.random() * src.length)];

    let clue = json.judul.replace(/[AIUEOaiueo]/g, "_");
    let caption = `*[ TEBAK LAGU ]*
*• Timeout :* 30 seconds
*• Artist :* ${json.artis}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

    let q = await m.reply(caption);
    conn.tebaklagu[id] = [
        await conn.sendFile(m.chat, json.lagu, null, caption, q),
        json,
        setTimeout(() => {
            if (conn.tebaklagu[id]) {
                m.reply(`*Game Over !!*\nYou lose with reason : *[ Timeout ]*\n\n• Answer : *[ ${json.judul} ]*`);
                delete conn.tebaklagu[id];
            }
        }, timeout),
    ];
};

handler.before = async (m, {
    conn
}) => {
    conn.tebaklagu = conn.tebaklagu || {};
    let id = m.chat;
    if (!m.text || m.isCommand || !conn.tebaklagu[id]) return;

    let json = conn.tebaklagu[id][1];
    let reward = db.data.users[m.sender];

    if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
        clearTimeout(conn.tebaklagu[id][2]);
        m.reply(`*Game Over !!*\nYou lose with reason : *[ ${m.text} ]*\n\n• Answer : *[ ${json.judul} ]*`);
        delete conn.tebaklagu[id];
    } else if (m.text.toLowerCase() === json.judul.toLowerCase()) {
        let money = Math.floor(Math.random() * 401) + 100;
        reward.money += money;
        reward.wintebaklagu += 1;
        clearTimeout(conn.tebaklagu[id][2]);
        m.reply(`*Congratulations!*\nYou guessed it right.\n+${money} money`);
        delete conn.tebaklagu[id];
    }
};

handler.help = ["tebaklagu"];
handler.tags = ["game"];
handler.command = ["tebaklagu"];
handler.group = true;

module.exports = handler;