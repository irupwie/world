const { tebakkata } = require("@bochilteam/scraper");

let timeout = 30000;

let handler = async (m, { conn }) => {
    conn.tebakkata = conn.tebakkata || {};
    let id = m.chat;
    if (id in conn.tebakkata) {
        conn.reply(m.chat, "Masih ada soal yang belum dijawab!", conn.tebakkata[id][0]);
        return;
    }

    let json = await tebakkata();
    if (!json || !json.jawaban) return m.reply("Gagal mengambil soal.");

    let caption = `*Tebak Kata*
Soal: ${json.soal}
Balas pesan ini untuk menjawab. 
Ketik *nyerah* untuk menyerah.`;

    let q = await m.reply(caption);
    conn.tebakkata[id] = [
        q,
        json,
        setTimeout(() => {
            if (conn.tebakkata[id]) {
                m.reply(`*Waktu habis!*\nJawabannya: ${json.jawaban}`);
                delete conn.tebakkata[id];
            }
        }, timeout),
    ];
};

handler.before = async (m, { conn }) => {
    conn.tebakkata = conn.tebakkata || {};
    let id = m.chat;
    if (!m.text || m.isCommand || !conn.tebakkata[id]) return;

    let json = conn.tebakkata[id][1];
    let reward = db.data.users[m.sender];

    if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
        clearTimeout(conn.tebakkata[id][2]);
        m.reply(`*Menyerah?*\nJawabannya: ${json.jawaban}`);
        delete conn.tebakkata[id];
    } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
        let money = Math.floor(Math.random() * 401) + 100; // 100–500
        reward.money += money;
        reward.wintebakkata = 1
        clearTimeout(conn.tebakkata[id][2]);
        m.reply(`*Benar!*\n+${money} uang`);
        delete conn.tebakkata[id];
    }
};

handler.help = ["tebakkata"];
handler.tags = ["game"];
handler.command = ["tebakkata"];
handler.group = true;

module.exports = handler;