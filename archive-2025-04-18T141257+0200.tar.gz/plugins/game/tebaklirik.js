//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : game/tebaklirik


let timeout = 30000;

let handler = async (m, {
    conn
}) => {
    conn.tebaklirik = conn.tebaklirik || {};
    let id = m.chat;
    if (id in conn.tebaklirik) {
        conn.reply(m.chat, "You already have a question to answer!", conn.tebaklirik[id][0]);
        return;
    }

    let res = await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json");
    if (!res.ok) return m.reply("Failed to fetch data.");

    let data = await res.json();
    let json = data[Math.floor(Math.random() * data.length)];

    let clue = json.jawaban.replace(/[AIUEOaiueo]/g, "_");
    let caption = `*[ TEBAK LIRIK ]*
*• Timeout :* 30 seconds
*• Question :* ${json.soal}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

    conn.tebaklirik[id] = [
        await m.reply(caption),
        json,
        setTimeout(() => {
            if (conn.tebaklirik[id]) {
                m.reply(`*Game Over !!*\nYou lose with reason : *[ Timeout ]*\n\n• Answer : *[ ${json.jawaban} ]*`);
                delete conn.tebaklirik[id];
            }
        }, timeout),
    ];
};

handler.before = async (m, {
    conn
}) => {
    conn.tebaklirik = conn.tebaklirik || {};
    let id = m.chat;
    if (!m.text || m.isCommand || !conn.tebaklirik[id]) return;

    let json = conn.tebaklirik[id][1];
    let reward = db.data.users[m.sender];

    if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
        clearTimeout(conn.tebaklirik[id][2]);
        m.reply(`*Game Over !!*\nYou lose with reason : *[ ${m.text} ]*\n\n• Answer : *[ ${json.jawaban} ]*`);
        delete conn.tebaklirik[id];
    } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
        let money = Math.floor(Math.random() * 401) + 100;
        reward.money += money;
        reward.wintebaklirik += 1    clearTimeout(conn.tebaklirik[id][2]);
        m.reply(`*Congratulations!*\nYou guessed it right.\n+${money} money`);
        delete conn.tebaklirik[id];
    }
};

handler.help = ["tebaklirik"];
handler.tags = ["game"];
handler.command = ["tebaklirik"];
handler.group = true;

module.exports = handler;