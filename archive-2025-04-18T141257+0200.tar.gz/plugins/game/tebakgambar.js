let timeout = 30000; // 30 detik

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.tebakgambar = conn.tebakgambar || {};
    let id = m.chat;
    
    if (id in conn.tebakgambar) {
        conn.reply(
            m.chat,
            "You already have an active question!",
            conn.tebakgambar[id][0],
        );
        return;
    }

    let res = await fetch(`https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json`);
    let src = await res.json();
    let json = src[Math.floor(Math.random() * src.length)];

    let caption = `*[ TEBAK GAMBAR ]*
*• Timeout:* 30 seconds

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

    let msg = await conn.sendMessage(m.chat, {
        image: { url: json.img },
        caption: caption
    }, { quoted: m });

    conn.tebakgambar[id] = [
        msg,
        json,
        setTimeout(() => {
            if (conn.tebakgambar[id]) {
                conn.sendMessage(id, {
                    text: `*Game Over!*\nYou lose due to: *[ Timeout ]*\n\n• Answer: *[ ${json.jawaban} ]*`
                }, {
                    quoted: m
                });
                delete conn.tebakgambar[id];
            }
        }, timeout),
    ];
};

handler.before = async (m, { conn }) => {
    conn.tebakgambar = conn.tebakgambar || {};
    let id = m.chat;
    if (!m.text || m.isCommand || !conn.tebakgambar[id]) return;

    let json = conn.tebakgambar[id][1];
    let reward = db.data.users[m.sender];

    if (["nyerah", "surender"].includes(m.text.toLowerCase())) {
        clearTimeout(conn.tebakgambar[id][2]);
        conn.sendMessage(m.chat, {
            text: `*Game Over!*\nYou gave up: *[ ${m.text} ]*\n\n• Answer: *[ ${json.jawaban} ]*`
        }, {
            quoted: conn.tebakgambar[id][0]
        });
        delete conn.tebakgambar[id];
    } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
        let moneyReward = Math.floor(Math.random() * 401) + 100; // 100-500
        reward.money += moneyReward;
        reward.wintebakgambar += 1
        clearTimeout(conn.tebakgambar[id][2]);
        conn.sendMessage(m.chat, {
            text: `*Congratulations!* You guessed the correct answer!\n\n*• Money:* +${moneyReward}`
        }, {
            quoted: conn.tebakgambar[id][0]
        });
        delete conn.tebakgambar[id];
    }
};

handler.help = ["tebakgambar"];
handler.tags = ["game"];
handler.command = ["tebakgambar"];
handler.group = true;

module.exports = handler;