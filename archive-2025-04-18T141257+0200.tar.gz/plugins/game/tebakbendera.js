//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : game/tebakbendera


let timeout = 30000; // 30 detik
let handler = async (m, {
    conn,
    command,
    usedPrefix
}) => {
    conn.tebakbendera = conn.tebakbendera || {};
    let id = m.chat;
    if (id in conn.tebakbendera) {
        conn.reply(
            m.chat,
            "Masih ada soal belum terjawab di chat ini",
            conn.tebakbendera[id].reply,
        );
        throw false;
    }

    let res = await fetch('https://raw.githubusercontent.com/qisyana/scrape/main/flag.json');
    let src = await res.json();
    let Apps = src[Math.floor(Math.random() * src.length)];
    let json = Apps;

    let caption = `*[ TEBAK BENDERA ]*
*• Timeout :* 30 seconds
*• Question :* Bendera dari negara manakah ini?`.trim();

    let q = await conn.sendMessage(
        m.chat, {
            image: {
                url: json.img
            },
            caption: caption
        }, {
            quoted: m
        },
    );

    conn.tebakbendera[id] = {
        reply: q,
        ...json,
    };

    setTimeout(() => {
        if (conn.tebakbendera[id]) {
            conn.reply(
                m.chat,
                `*</> T I M E O U T </>*\n*• Jawaban :* ${json.name}`,
                q,
            );
            delete conn.tebakbendera[id];
        }
    }, timeout);
};

handler.before = async (m, {
    conn
}) => {
    conn.tebakbendera = conn.tebakbendera || {};
    let id = m.chat;
    if (m.isCommand) return;
    if (!conn.tebakbendera[id]) return;

    let json = conn.tebakbendera[id];
    let reward = db.data.users[m.sender];

    if (m.text.toLowerCase() === json.name.toLowerCase()) {
        let money = Math.floor(Math.random() * 401) + 100; // 100 - 500
        reward.money += money;
        reward.wintebakbendera += 1
        m.reply(`*Jawaban benar!*\n+${money} money`);

        delete conn.tebakbendera[id];
    }
};

handler.help = ["tebakbendera"];
handler.tags = ["game"];
handler.command = ["tebakbendera", "guessflag"];
handler.group = true;

module.exports = handler;