//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : game/tebakhero

const cheerio = require("cheerio");
const { parseStringPromise } = require("xml2js");
let timeout = 30000;

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.tebakhero = conn.tebakhero || {};
    let id = m.chat;
    if (id in conn.tebakhero) {
        conn.reply(
            m.chat,
            "You already have a question to answer!",
            conn.tebakhero[id][0],
        );
        return;
    }

    let json = await tebakhero("id");
    if (!json.voice) return m.reply("Failed to fetch voice data.");

    let caption = `*[ TEBAK HERO ML ]*
*• Timeout :* 30 seconds
*• Question :* Guess the ML Hero based on their voice

Reply to this message to answer the question
Type *\`nyerah\`* to surrender`.trim();

    // Mengirim pesan text terlebih dahulu jika kamu ingin menyertakan caption
    await conn.sendMessage(m.chat, { text: caption });
    // Mengirim audio langsung dari URL tanpa menyimpan file secara lokal
    let q = await conn.sendMessage(
        m.chat,
        { audio: { url: json.voice }, mimetype: 'audio/mpeg' },
        { quoted: m }
    );
    conn.tebakhero[id] = [
        q,
        json,
        setTimeout(() => {
            if (conn.tebakhero[id]) {
                conn.sendMessage(
                    id,
                    { text: `*Game Over !!*\nYou lose with reason : *[ Timeout ]*\n\n• Answer : *[ ${json.hero} ]*` },
                    { quoted: m },
                );
                delete conn.tebakhero[id];
            }
        }, timeout),
    ];
};

handler.before = async (m, { conn }) => {
    conn.tebakhero = conn.tebakhero || {};
    let id = m.chat;
    if (!m.text || m.isCommand || !conn.tebakhero[id]) return;

    let json = conn.tebakhero[id][1];
    let reward = db.data.users[m.sender];

    if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
        clearTimeout(conn.tebakhero[id][2]);
        conn.sendMessage(
            m.chat,
            { text: `*Game Over !!*\nYou lose with reason : *[ ${m.text} ]*\n\n• Answer : *[ ${json.hero} ]*` },
            { quoted: conn.tebakhero[id][0] },
        );
        delete conn.tebakhero[id];
    } else if (m.text.toLowerCase() === json.hero.toLowerCase()) {
        let money = Math.floor(Math.random() * 401) + 100; // 100–500
        reward.money += money;
        reward.wimtebakhero += 1
        clearTimeout(conn.tebakhero[id][2]);

        m.reply(`*Congratulations!*\nYou guessed it right.\n+${money} money`);
        delete conn.tebakhero[id];
    }
};

handler.help = ["tebakhero"];
handler.tags = ["game"];
handler.command = ["tebakhero"];
handler.group = true;

module.exports = handler;

// Function to fetch hero and voice
async function tebakhero(tema = "id") {
    try {
        let karakter = ["Aamon", "Assassin", "Jungler", "Akai", "Tank", "Aldous", "Fighter", "Alice", "Alpha", "Alucard", "Angela", "Support", "Roamer", "Argus", "EXP Laner", "Arlott", "Atlas", "Aulus", "Aurora", "Mage", "Badang", "Balmond", "Bane", "Barats", "Baxia", "Beatrix", "Marksman", "Gold Laner", "Belerick", "Benedetta", "Brody", "Bruno", "Carmilla", "Caecilion", "Mid Laner", "Chou", "Figter", "Cici", "Claude", "Clint", "Cyclops", "Diggie", "Dyrroth", "Edith", "Esmeralda", "Estes", "Eudora", "Fanny", "Faramis", "Floryn", "Franco", "Fredrinn", "Freya", "Gatotkaca", "Gloo", "Gord", "Granger", "Grock", "Guinevere", "Gusion", "Hanabi", "Hanzo", "Harith", "Harley", "Hayabusa", "Helcurt", "Hilda", "Hylos", "Irithel", "Ixia", "Jawhead", "Johnson", "Joy", "Asassin", "Julian", "Kadita", "Kagura", "Kaja", "Karina", "Karrie", "Khaleed", "Khufra", "Kimmy", "Lancelot", "Layla", "Leomord", "Lesley", "Ling", "Lolita", "Lunox", "Luo Yi", "Lylia", "Martis", "Masha", "Mathilda", "Melissa", "Minotaur", "Minsitthar", "Miya", "Moskov", "Nana", "Natalia", "Natan", "Novaria", "Odette", "Paquito", "Pharsa", "Phoveus", "Popol and Kupa", "Rafaela", "Roger", "Ruby", "Saber", "Selena", "Silvanna", "Sun", "Terizla", "Thamuz", "Tigreal", "Uranus", "Vale", "Valentina", "Valir", "Vexana", "Wanwan", "Xavier", "Yin", "Yu Zhong", "Yve", "Zhask", "Zilong"];
        let chara = karakter[Math.floor(Math.random() * karakter.length)];
        const url = tema === "id" ? `https://mobile-legends.fandom.com/wiki/${chara.toLowerCase()}/Audio/id` : tema === "en" ? `https://mobilelegendsbuild.com/sitemap.xml` : null;
        if (!url) throw new Error("Tema tidak valid");

        let res = await fetch(url);
        let data = await res.text();

        if (tema === "en") {
            const result = await parseStringPromise(data);
            const targetUrl = result.urlset.url.filter(url => url.loc[0].includes("sound/" + chara.toLowerCase())).map(url => url.loc[0])[0];
            if (!targetUrl) return [];
            res = await fetch(targetUrl);
            data = await res.text();
        }

        const $ = cheerio.load(data);
        let audio = $("audio").map((i, el) => $(el).attr("src")).get();
        let audio_random = audio[Math.floor(Math.random() * audio.length)];
        if (!audio_random) return await tebakhero();

        return {
            hero: chara,
            voice: audio_random || audio
        };
    } catch (error) {
        return {
            hero: null,
            voice: null
        };
    }
}