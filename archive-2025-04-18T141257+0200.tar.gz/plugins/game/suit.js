let timeout = 60000;
let handler = async (m, { conn, usedPrefix }) => {
  conn.suit = conn.suit ? conn.suit : {};

  if (
    Object.values(conn.suit).find(
      (room) =>
        room.id.startsWith("suit") && [room.p, room.p2].includes(m.sender),
    )
  ) {
    return m.reply("Selesaikan suit sebelumnya terlebih dahulu.");
  }

  if (!m.mentionedJid[0]) {
    return m.reply(
      `_Siapa yang ingin kamu tantang suit?_\nTag orangnya.. Contoh:\n\n${usedPrefix}suit @user`,
    );
  }

  if (
    Object.values(conn.suit).find(
      (room) =>
        room.id.startsWith("suit") &&
        [room.p, room.p2].includes(m.mentionedJid[0]),
    )
  ) {
    return m.reply("Orang yang kamu tantang sedang bermain suit dengan orang lain.");
  }

  let id = "suit_" + new Date() * 1;
  let caption = `
_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit!

Silakan @${m.mentionedJid[0].split`@`[0]} respon tantangan tersebut.
`.trim();
  let footer = `\nKetik "terima/ok/gas" untuk memulai suit\nKetik "tolak/gabisa/nanti" untuk membatalkan`;

  conn.suit[id] = {
    chat: await conn.sendMessage(m.chat, {
      text: caption + footer,
      contextInfo: {
        mentionedJid: conn.parseMention(caption),
      },
    }, { quoted: m }),
    id: id,
    p: m.sender,
    p2: m.mentionedJid[0],
    status: "wait",
    waktu: setTimeout(() => {
      if (conn.suit[id]) conn.sendMessage(m.chat, { text: "_Waktu suit habis_" }, { quoted: m });
      delete conn.suit[id];
    }, timeout),
    timeout,
  };
};

handler.tags = ["game"];
handler.help = ["suitpvp"];
handler.command = ["suitpvp", "suit"];
handler.limit = false;
handler.group = true;

module.exports = handler;