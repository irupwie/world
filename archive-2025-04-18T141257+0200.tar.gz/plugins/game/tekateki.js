//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : game/tekateki


let timeout = 30000;

let handler = async (m, {
    conn
}) => {
    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    if (id in conn.tekateki) {
        conn.reply(m.chat, "You already have a question to answer!", conn.tekateki[id][0]);
        return;
    }

    let res = await fetch("https://raw.githubusercontent.com/qisyana/scrape/main/tekateki.json");
    if (!res.ok) return m.reply("Failed to fetch teka-teki data.");

    let data = await res.json();
    let json = data[Math.floor(Math.random() * data.length)];
    let clue = json.jawaban.replace(/[AIUEOaiueo]/g, "_");

    let caption = `*[ TEKA TEKI ]*
*• Timeout :* 30 seconds
*• Question :* ${json.pertanyaan}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

    conn.tekateki[id] = [
        await conn.reply(m.chat, caption, m),
        json,
        setTimeout(() => {
            if (conn.tekateki[id]) {
                m.reply(`*Game Over !!*\nYou lose with reason : *[ Timeout ]*\n\n• Answer : *[ ${json.jawaban} ]*`);
                delete conn.tekateki[id];
            }
        }, timeout),
    ];
};

handler.before = async (m, {
    conn
}) => {
    conn.tekateki = conn.tekateki || {};
    let id = m.chat;

    if (!m.text || m.isCommand || !conn.tekateki[id]) return;

    let json = conn.tekateki[id][1];
    let reward = db.data.users[m.sender];

    if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
        clearTimeout(conn.tekateki[id][2]);
        m.reply(`*Game Over !!*\nYou lose with reason : *[ ${m.text} ]*\n\n• Answer : *[ ${json.jawaban} ]*`);
        delete conn.tekateki[id];
    } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
        let money = Math.floor(Math.random() * 401) + 100;
        reward.money += money;
        reward.wintekateki += 1
        clearTimeout(conn.tekateki[id][2]);
        m.reply(`*Congratulations!*\nYou guessed it right.\n+${money} money`);
        delete conn.tekateki[id];
    }
};

handler.help = ["tekateki"];
handler.tags = ["game"];
handler.command = ["tekateki"];
handler.group = true;

module.exports = handler;