let bar = (min, max) => {
  const progress = (min / max) * 10;
  const filledBars = Math.floor(progress);
  const emptyBars = 10 - filledBars;
  return "[" + "█".repeat(filledBars) + "▒".repeat(emptyBars) + "]";
};

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const num = m.sender;
  const user = db.data.users[num];

  try {
    let pp = await conn.profilePictureUrl(num, "image").catch(() => "https://files.catbox.moe/ifx2y7.png");
    let name = user.name || "Unknown";
    let umur = user.age || "-";
    let register = user.registered ? "✓" : "×";
    let premium = user.premium ? "✓" : "×";
    let limit = isNaN(user.limit) ? user.limit : Func.formatNumber(user.limit);
    let premiumDate = isNaN(user.premiumDate)
      ? user.premiumDate
      : `${(await Func.toDate(user.premiumDate)) || "Nothing expired"}`;

    let { currentXp, currentLevel, nextLevel, xpToLevelUp } =
      Func.leveling(user.exp, global.multiplier, 100);

    let bio;
    try {
      bio = await (await conn.fetchStatus(num)).status;
    } catch (e) {
      bio = "no bio yet";
    }

    let caption = `
┌─⭓「 *PROFILE USER* 」
│ *• Name :* ${name}
│ *• Age :* ${umur}
│ *• Tag :* @${num.split("@")[0]}
│ *• Url :* wa.me/${num.split("@")[0]}
│ *• Register :* ${register}
│ *• Limit :* ${limit}
│ *• Role :* ${user.role}
│ *• Level :* ${user.level}
│ *• Premium :* ${premium}
│ *• Exp :* ${Func.formatNumber(user.exp)}
│ *• Money :* ${Func.formatNumber(user.money)}
│ *• Bio :* ${bio}
│ *• Progress :* ${bar(user.exp, xpToLevelUp)} ${Math.floor((user.exp / xpToLevelUp) * 100)}%
└───────────────⭓

*• Last Register :*
${require("moment-timezone")(user.regTime).tz("Asia/Jakarta").format("YYYY/MM/DD HH:mm:ss")} *[ ${await getUptime(user.regTime)} ]*
`;

    await conn.sendMessage(m.chat, { text: caption.trim(), contextInfo: { mentionedJid: [num] } }, { quoted: m });
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan saat memuat profil.");
  }
};

handler.help = ["profile"];
handler.tags = ["user"];
handler.command = ["profile", "me", "infome", "akun", "infoprofile"];
handler.register = true;

module.exports = handler;

async function getUptime(startTime) {
  let currentTime = Date.now();
  let uptime = currentTime - startTime;
  let seconds = Math.floor(uptime / 1000);
  let minutes = Math.floor(seconds / 60);
  let hours = Math.floor(minutes / 60);
  let days = Math.floor(hours / 24);

  hours %= 24;
  minutes %= 60;
  seconds %= 60;

  let dSeconds = seconds < 1 ? "" : seconds + " S ";
  let dMinutes = minutes < 1 ? "" : minutes + " M ";
  let dHours = hours < 1 ? "" : hours + " H ";
  let dDays = days < 1 ? "" : days + " D ";
  return dDays + dHours + dMinutes + dSeconds;
}