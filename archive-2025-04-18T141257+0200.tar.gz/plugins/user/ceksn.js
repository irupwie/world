const {
    createHash
} = require('crypto');

let handler = async function(m, {
    conn
}) {
    let sn = createHash('md5').update(m.sender).digest('hex');
    let name = await conn.getName(m.sender);

    let teks = `
> 📝 Serial Number kamu berhasil dibuat!

Nama: ${name}
SN: ${sn}
`;

    m.reply(teks.trim());
};

handler.help = ['ceksn'];
handler.tags = ['user'];
handler.command = ["ceksn"];
handler.register = true;

module.exports = handler;