let handler = async (m, { args, command }) => {
    let users = global.db.data.users;
    let winTypes = {
        susunkata: 'Win Susun Kata',
        tebakkata: 'Win Tebak Kata',
        tebakbendera: 'Win Tebak Bendera',
        tebakgambar: 'Win Tebak Gambar',
        tebakhero: 'Win Tebak Hero',
        tebaklirik: 'Win Tebak Lirik',
        tekateki: 'Win Teka Teki',
    };

    if (command === 'mywin' || command === 'win') {
        let who = m.isGroup ? (m.mentionedJid[0] || m.sender) : m.sender;
        let msg = `*[ WIN - GAME ]*\n> hai kak ${m.name}\n`;
        for (let type in winTypes) {
            msg += `> ${users[who][`win${type}`] || 0} ${winTypes[type]}\n`;
        }
        return m.reply(msg);
    }

    if (command === 'topwin') {
        let typeArg = args[0]?.toLowerCase();
        if (typeArg && !winTypes[typeArg]) return m.reply(`Game tidak ditemukan!\nContoh: .topwin susunkata`);

        let sorted = Object.entries(users).map(([jid, data]) => {
            let total = typeArg
                ? data[`win${typeArg}`] || 0
                : Object.keys(winTypes).reduce((sum, t) => sum + (data[`win${t}`] || 0), 0);
            return { jid, total };
        }).filter(u => u.total > 0)
          .sort((a, b) => b.total - a.total)
          .slice(0, 10);

        if (sorted.length === 0) return m.reply(`Belum ada yang menang di game ini.`);

        let title = typeArg ? `Top 10 ${winTypes[typeArg]}` : `Top 10 Win Semua Game`;
        let text = `*${title}*\n\n` + sorted.map((u, i) =>
            `${i + 1}. @${u.jid.split('@')[0]} - ${u.total} win`
        ).join('\n');

        return conn.sendMessage(m.chat, { text, mentions: sorted.map(u => u.jid) }, { quoted: m });
    }
};

handler.help = ['mywin', 'topwin', 'topwin [game]'];
handler.tags = ['user'];
handler.command = ['mywin', 'win', 'topwin'];

module.exports = handler;