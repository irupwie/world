let handler = async function(m, { conn }) {
    let user = global.db.data.users[m.sender];
    if (!user.registered) {
        return m.reply('Kamu belum terdaftar.');
    }

    user.registered = false;
    m.reply(`Pendaftaran kamu telah dibatalkan.\n\nJika ingin mendaftar kembali, gunakan perintah:\n.daftar nama.umur`);
}

handler.help = ['autounreg']
handler.tags = ['user']
handler.command = ['autounreg']
handler.register = true
handler.limit = 10

module.exports = handler