const {
    createHash
} = require('crypto');

let handler = async function(m, {
    conn,
    args,
    command,
    usedPrefix
}) {
    if (!args[0])
        throw `Silakan masukkan Nomor Seri (Serial Number).\nContoh: ${usedPrefix + command} nomorseri\n\nNomor Seri dapat Anda lihat dengan perintah:\n${usedPrefix}ceksn`;

    let user = global.db.data.users[m.sender];
    let sn = createHash('md5').update(m.sender).digest('hex');

    if (args[0] !== sn)
        throw 'Nomor Seri yang Anda masukkan tidak cocok. Pastikan Anda menyalinnya dengan benar.';

    user.registered = false;
    m.reply(`Pendaftaran Anda telah dibatalkan.\n\nJika ingin mendaftar kembali, silakan gunakan perintah:\n${usedPrefix}daftar nama.umur`);
}

handler.help = ['unreg']
handler.tags = ['user']
handler.command = ['unreg', 'unregister']
handler.register = true

module.exports = handler