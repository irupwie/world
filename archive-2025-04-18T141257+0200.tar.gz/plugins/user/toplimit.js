const moneyPerLimit = 2500;

let handler = async (m, { conn, command, args }) => {
    const users = global.db.data.users;

    if (command === "limit") {
        let who = m.isGroup
            ? (m.mentionedJid && m.mentionedJid[0]) || m.sender
            : m.sender;

        m.reply(`*[ INFO LIMIT ]*\n> Hai kak ${m.name}, sisa limit kamu: ${users[who].limit}`);
        return;
    }

    if (["toplimit", "lblimit", "leaderboardlimit"].includes(command)) {
        let sorted = Object.entries(users)
            .filter(([_, data]) => !data.premium) // filter non-premium saja
            .map(([jid, data]) => ({ jid, limit: data.limit || 0 }))
            .sort((a, b) => b.limit - a.limit) // urut dari terbesar
            .slice(0, 10); // ambil 10 teratas

        let leaderboard = "*[ LEADERBOARD LIMIT TERBANYAK ]*\n\n";
        let mentions = [];
        let i = 1;
        for (const user of sorted) {
            mentions.push(user.jid);
            leaderboard += `${i++}. @${user.jid.split('@')[0]} - ${user.limit} Limit\n`;
        }

        conn.reply(m.chat, leaderboard.trim(), m, { mentions });
        return;
    }

    // Untuk buylimit dan buylimitall
    let count;
    if (command) {
        count = command.replace(/^buylimit/i, "");
    }

    if (count) {
        if (/all/i.test(count)) {
            count = Math.floor(users[m.sender].money / moneyPerLimit);
        } else {
            count = parseInt(count) || parseInt(args[0]) || 1;
        }
    } else {
        count = 1;
    }

    count = Math.max(1, count);

    if (users[m.sender].money >= moneyPerLimit * count) {
        users[m.sender].money -= moneyPerLimit * count;
        users[m.sender].limit += count;
        conn.reply(m.chat, `*Transaksi berhasil:*\n-${moneyPerLimit * count} Money\n+${count} Limit`, m);
    } else {
        conn.reply(
            m.chat,
            `*Gagal membeli limit!*\nKamu butuh ${moneyPerLimit * count} Money, tapi kamu hanya punya ${users[m.sender].money}.`,
            m
        );
    }
};

handler.help = ['limit [@user]', 'buylimit', 'buylimitall', 'toplimit'];
handler.tags = ['user'];
handler.command = ['limit', 'buylimit', 'buylimitall', 'toplimit', 'lblimit', 'leaderboardlimit'];

module.exports = handler;