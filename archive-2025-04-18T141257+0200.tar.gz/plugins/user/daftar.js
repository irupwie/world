const { createHash } = require('crypto');
let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i;

let handler = async function(m, { text, usedPrefix }) {
    let user = global.db.data.users[m.sender];

    if (user.registered === true) {
        return m.reply(`Anda sudah terdaftar sebelumnya.\n\nJika ingin mendaftar ulang, gunakan perintah:\n*${usedPrefix}unreg <Serial Number>*`);
    }

    if (!Reg.test(text)) {
        return m.reply(`*Cara Mendaftar Bot:*

Ketik perintah dengan format:
*${usedPrefix}daftar nama.umur*

Contoh:
*${usedPrefix}daftar Andi.20*

*Catatan:*
- Gunakan titik (.) sebagai pemisah antara nama dan umur
- Nama boleh huruf/angka, umur wajib angka
- Umur minimal 5 tahun dan maksimal 120 tahun`);
    }

    let [_, name, splitter, age] = text.match(Reg);

    if (!name) return m.reply('Nama tidak boleh kosong dan harus berupa huruf atau angka.');
    if (!age) return m.reply('Umur tidak boleh kosong dan harus berupa angka.');

    age = parseInt(age);
    if (age > 120) return m.reply('Maaf, umur yang Anda masukkan terlalu besar (maks 120).');
    if (age < 5) return m.reply('Maaf, umur minimal untuk mendaftar adalah 5 tahun.');

    user.name = name.trim();
    user.age = age;
    user.regTime = +new Date;
    user.registered = true;

    let sn = createHash('md5').update(m.sender).digest('hex');

    return m.reply(`
*Pendaftaran Berhasil!*

Berikut data Anda:
• Nama  : ${name}
• Umur  : ${age} tahun
• SN    : ${sn}

Simpan Serial Number (SN) ini dengan baik.
Digunakan untuk *unregister* jika diperlukan di masa depan.
`.trim());
};

handler.help = ['daftar'];
handler.tags = ['user'];
handler.command = ["daftar", "daftarbot", "register", "reg", "registerbot"];

module.exports = handler;