//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : fun/fun-ceksifat


let handler = async (m, {
    conn,
    command,
    text
}) => {
    if (!text) return conn.reply(m.chat, "*• Contoh :* .ceksifat Aldog", m);

    const percent = [
        "0%", "0,1%", "0,4%", "1%", "2%", "3%", "5%", "6%", "9%", "10%", "11%", "12%", "15%", "17%", "20%", "22%", "25%",
        "27%", "30%", "33%", "35%", "37%", "40%", "41%", "44%", "46%", "49%", "50%", "52%", "54%", "57%", "60%",
        "63%", "66%", "69%", "70%", "72%", "73%", "75%", "78%", "80%", "81%", "84%", "87%", "88%", "90%", "92%",
        "93%", "94%", "95%", "96%", "98%", "98,3%", "99%", "99,5%", "99,7%", "99,9%", "100%"
    ];

    const sifatBaik = [
        "Rendah hati", "Jujur", "Setia", "Pemaaf", "Dermawan", "Penyayang", "Bijaksana", "Pekerja Keras", "Humoris",
        "Sopan", "Ramah", "Tegas tapi lembut", "Pintar membawa diri", "Kharismatik", "Pemimpin alami", "Empati tinggi",
        "Pendengar yang baik", "Tulus", "Cerdas emosional", "Supportif", "Bisa diandalkan", "Rajin ibadah", "Penuh semangat"
    ];

    const sifatBuruk = [
        "Sombong", "Pemarah", "Iri hati", "Pendendam", "Pelit", "Suka bohong", "Moody", "Manipulatif", "Drama Queen",
        "Narsis", "Overthinking", "Tukang gosip", "Ghosting mulu", "Caper gak jelas", "Playboy / Playgirl", "Suka ngambek",
        "Terlalu cuek", "Over proud", "Malas minta maaf", "Keras kepala", "Dikit-dikit story", "Muka dua"
    ];

    const aktivitas = [
        "Scroll TikTok seharian", "Main game sampai lupa waktu", "Chat mantan secara diam-diam", "Kepo-in story mantan",
        "Tiduran sambil mikirin hidup", "Nonton anime semalaman", "Makan mulu", "Rebahan jadi hobi", "Berimajinasi liar",
        "Stalking IG gebetan", "Curhat ke AI", "Ngonten gak jadi-jadi", "Bikin fake akun", "Pura-pura sibuk",
        "Lupa mandi 2 hari", "Tidur siang jadi hobi", "Dengerin lagu galau", "Chat temen tapi di-read doang",
        "Ngumpulin niat doang", "Rewatch anime kesukaan", "Meratapi mantan", "AFK dari dunia nyata"
    ];

    const kecerdasan = [
        "IQ Dewa", "Cerdas tapi mager", "Sok tau", "Fast learner", "Sadar diri", "Jenius dalam hal random",
        "Cerdas berlogika", "Pinter ngeles", "Mikir dulu baru ngomong", "Overthinker intelektual", "Terlalu pinter sampai dianggap aneh",
        "Pemecah masalah", "Tahu banyak hal nggak penting", "Ngerti semua tapi lupa semua", "Pintar diam-diam", "Pemikir kritis",
        "Multi-talenta", "Kreatif banget", "Jago analisa", "Terlalu genius untuk dunia ini"
    ];

    const kenakalan = [
        "Ngumpetin remote", "Ngomporin temen", "Bolos online", "Ngeprank temen", "Bikin drama", "Suka nyela orang",
        "Ngilang pas dibutuhin", "Mancing keributan", "Suka ganggu orang tidur", "Curang pas main game", "Ngintip tugas temen",
        "Nulis di meja sekolah", "Gibah berjamaah", "Fake akun buat stalking", "Nge-like foto lama mantan", "Pura-pura sibuk biar gak ditugasin"
    ];

    const keberanian = [
        "Berani tampil beda", "Sok berani", "Pemberani sejati", "Cuma berani di chat", "Takut tapi maju",
        "Nekat", "Penakut akut", "Pemberani hanya di dunia maya", "Nggak takut malu", "Berani confess",
        "Berani lawan guru", "Berani jujur walau sakit", "Berani DM crush", "Ngakuin salah tanpa drama"
    ];

    const ketakutan = [
        "Takut ditinggal", "Takut ditolak", "Takut sendirian", "Takut gagal", "Takut kehilangan sinyal",
        "Takut ketahuan", "Takut lihat saldo", "Takut dipanggil guru", "Takut nyalain kamera zoom",
        "Takut ditanya 'kapan nikah?'", "Takut salah ngomong", "Takut ngaca", "Takut masa depan", "Takut ketemu mantan"
    ];

    const hasil = `
╭━─┈◇「 *Sifat ${text}* 」◇┈━╮
┃
┃• Nama : ${text}
┃• Ahlak Baik : ${pickRandom(percent)}
┃• Ahlak Buruk : ${pickRandom(percent)}
┃• Orang yang : ${pickRandom(sifatBaik)} tapi kadang ${pickRandom(sifatBuruk)}
┃• Sering : ${pickRandom(aktivitas)}
┃• Kecerdasan : ${pickRandom(kecerdasan)} (${pickRandom(percent)})
┃• Kenakalan : ${pickRandom(kenakalan)} (${pickRandom(percent)})
┃• Keberanian : ${pickRandom(keberanian)} (${pickRandom(percent)})
┃• Ketakutan : ${pickRandom(ketakutan)} (${pickRandom(percent)})
╰━─┈◇┈◇┈◇┈◇┈◇┈◇┈◇┈◇┈━╯
`.trim();

    conn.reply(m.chat, hasil, m);
};

handler.help = ["ceksifat *[nama]*"];
handler.tags = ["fun"];
handler.command = ["ceksifat"];
handler.limit = true;

module.exports = handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}