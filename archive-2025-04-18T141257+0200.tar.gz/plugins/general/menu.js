const { promises: fs } = require('fs');
const moment = require('moment-timezone');

let handler = async (m, { conn, usedPrefix, command, args }) => {
  // Create context info once for all responses
  const ctx = {
    contextInfo: {
      externalAdReply: {
        title: "Ciko Bot",
        body: "WaBot",
        thumbnailUrl: "https://files.catbox.moe/eomr5j.jpg",
        mediaUrl: 'https://instagram/tos',
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  };

  try {
    const time = moment.tz('Asia/Jakarta').format('HH:mm:ss');
    const date = moment.tz('Asia/Jakarta').format('DD MMMM YYYY');
    const uptime = formatUptime(process.uptime());
    const name = m.pushName || 'User';
    const tags = {};
    
    // Collect all plugin commands and organize by tags
    for (let pluginName in global.plugins) {
      const plugin = global.plugins[pluginName];
      if (!plugin || !plugin.tags) continue;
      
      for (let tag of plugin.tags) {
        if (!tags[tag]) tags[tag] = [];
        let cmds = plugin.help || [];
        if (typeof cmds === 'string') cmds = [cmds];
        for (let cmd of cmds) {
          if (!tags[tag].includes(cmd)) { // Prevent duplicate commands
            tags[tag].push(cmd);
          }
        }
      }
    }
    
    let text = '';
    const category = args[0]?.toLowerCase();
    
    if (!category) {
      // Main menu
      text += `Hallo ${name}!\n\n`;
      text += `Tanggal: ${date}\n`;
      text += `Waktu: ${time}\n`;
      text += `Uptime: ${uptime}\n\n`;
      text += `Daftar Kategori:\n`;
      
      for (let tag in tags) {
        text += `- ${usedPrefix}${command} ${tag.toLowerCase()}\n`;
      }
      
      text += `\nKetik ${usedPrefix}${command} <kategori> untuk melihat perintah di dalamnya.`;
      text += `\nKetik ${usedPrefix}${command} all untuk melihat semua perintah.`;
      text += `\nContoh: ${usedPrefix}${command} tools`;
    } else if (category === 'all') {
      // All commands from all categories
      text += `Menu Semua Kategori:\n\n`;
      let totalCmds = 0;
      
      for (let tag in tags) {
        const cmds = tags[tag].sort();
        totalCmds += cmds.length;
        text += `*${tag.toUpperCase()}* (${cmds.length} fitur)\n`;
        
        for (let cmd of cmds) {
          text += `- ${usedPrefix}${cmd}\n`;
        }
        
        text += '\n';
      }
      
      text += `Total: ${totalCmds} fitur`;
    } else if (tags[category]) {
      // Commands from specific category
      const cmds = tags[category].sort();
      text += `Menu Kategori: ${category.toUpperCase()}\n`;
      text += `Jumlah fitur: ${cmds.length}\n\n`;
      
      for (let cmd of cmds) {
        text += `- ${usedPrefix}${cmd}\n`;
      }
    } else {
      // Category not found
      text += `Kategori "${category}" tidak ditemukan.\n`;
      text += `Gunakan perintah ${usedPrefix}${command} untuk melihat daftar kategori yang tersedia.`;
    }
    
    // Send the response with context info
    await conn.reply(m.chat, text.trim(), m, ctx);
    
  } catch (e) {
    console.error('Error in menu handler:', e);
    const errorText = 'Terjadi kesalahan saat memproses menu. Mohon coba lagi nanti.';
    await conn.reply(m.chat, errorText, m, ctx);
  }
};

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

handler.help = ['menu [kategori]'];
handler.tags = ['general'];
handler.command = ['menu', 'help', 'bot'];

module.exports = handler;