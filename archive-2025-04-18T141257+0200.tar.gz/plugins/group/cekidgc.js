let handler = async (m, { conn, args, groupMetadata }) => {
    let linkRegex = /chat\.whatsapp\.com\/([\w\d]+)/i;
    let match = args[0] ? args[0].match(linkRegex) : null;

    if (match) {
        let code = match[1];
        let res = await conn.query({
            tag: 'iq',
            attrs: {
                type: 'get',
                xmlns: 'w:g2',
                to: '@g.us'
            },
            content: [{ tag: 'invite', attrs: { code } }]
        });

        let id = res?.content?.[0]?.attrs?.id;
        if (id) {
            conn.reply(m.sender, `*G R O U P - I D*\n\n   ◦ Name : ${res.content[0].attrs.subject || ''}\n   ◦ ID : ${id}@g.us`, m);
        }
    } else {
        conn.reply(m.sender, `*G R O U P - I D*\n\n   ◦ Name : ${groupMetadata.subject}\n   ◦ ID : ${groupMetadata.id}@g.us`, m);
    }
};

handler.help = ["cekidgc"]
handler.tags = ["group"]
handler.command = ["cekidgc"]
handler.group = true
module.exports = handler