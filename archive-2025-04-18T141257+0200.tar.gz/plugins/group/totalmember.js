const PhoneNum = require("awesome-phonenumber");

module.exports = {
    help: ["totalmem", "askot"].map((cmd) => cmd + " *[total member]*"),
    tags: ["group"],
    command: ["totalmem", "askot"],
    group: true,
    code: async (
        m, {
            conn,
            usedPrefix,
            command,
            text,
            isOwner,
            isAdmin,
            isBotAdmin,
            isPrems,
            chatUpdate,
        },
    ) => {
        try {
            const regionNames = new Intl.DisplayNames(["en"], {
                type: "region"
            });
            const data = await conn.groupMetadata(m.chat);
            const participants = data.participants || [];

            let countryMembers = {};

            for (let participant of participants) {
                let phone = "+" + participant.id.split("@")[0];
                let parsed = PhoneNum(phone);
                let regionCode = parsed.getRegionCode() || "Unknown";
                let country = regionNames.of(regionCode) || "Unknown";

                if (!countryMembers[country]) countryMembers[country] = [];
                countryMembers[country].push(participant.id);
            }

            let countryCounts = Object.keys(countryMembers).map((country) => ({
                name: country,
                total: countryMembers[country].length,
                jid: countryMembers[country],
            }));

            let totalSum = countryCounts.reduce((acc, curr) => acc + curr.total, 0);
            let totalRegion = Object.keys(countryMembers).length;

            let hasil = countryCounts.map(({
                name,
                total,
                jid
            }) => ({
                name,
                total,
                jid,
                percentage: ((total / totalSum) * 100).toFixed(2) + "%",
            }));

            let cap = `┌─⭓「 *TOTAL MEMBER* 」
│ *• Name :* ${data.subject}
│ *• Total :* ${participants.length}
│ *• Total Region :* ${totalRegion}
└───────────────⭓

┌─⭓「 *REGION MEMBER* 」
${hasil
  .sort((a, b) => b.total - a.total)
  .map(
    (item) =>
      `│ *• Region :* ${item.name} *[ ${item.percentage} ]*
│ *• Total :* ${item.total}` +
      (item.jid[0].startsWith("62")
        ? ""
        : `\n│ *• Jid :*\n${item.jid
            .map((i) => "│ @" + i.split("@")[0])
            .join("\n")}`),
  )
  .join("\n├───────────────⭓\n")}
└───────────────⭓`;

            conn.reply(m.chat, cap, fakestatus("*[ Total member ]*"));
        } catch (e) {
            console.error(e);
            conn.reply(m.chat, "Terjadi kesalahan saat memproses data grup.", m);
        }
    },
};