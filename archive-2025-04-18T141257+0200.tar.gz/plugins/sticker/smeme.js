const { createCanvas, loadImage, registerFont } = require('canvas');
const fs = require('fs').promises;
const path = require('path');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        // Periksa apakah text diberikan
        if (!text) {
            throw `Balas gambar dengan perintah:\n\n*${usedPrefix + command} teks_atas|teks_bawah*`;
        }
        
        // Split text menjadi teks atas dan bawah, dengan handling untuk string kosong
        let [atas = '', bawah = ''] = text.split('|').map(item => item.trim());
        
        // Dapatkan quoted message
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        
        // Validasi mime type
        if (!mime) {
            throw `Balas gambar dengan perintah:\n\n*${usedPrefix + command} teks_atas|teks_bawah*`;
        }
        
        if (!/image\/(jpe?g|png)/i.test(mime)) {
            throw `_*Mime ${mime} tidak didukung! Hanya jpg/jpeg/png.*_`;
        }
        
        // Tampilkan pesan bahwa proses sedang berjalan
        await conn.reply(m.chat, '⏳ Sedang membuat stiker meme...', m);
        
        // Download gambar
        const buffer = await q.download();
        if (!buffer) throw 'Gagal mengunduh gambar.';
        
        // Membuat meme menggunakan canvas
        const memeBuffer = await createMeme(buffer, atas, bawah);
        
        // Kirim sebagai stiker
        await conn.sendImageAsSticker(m.chat, memeBuffer, m, {
            packname: global.packname || 'Sticker Meme',
            author: global.author || 'Bot'
        });
    } catch (err) {
        console.error('Error in smeme handler:', err);
        m.reply(typeof err === 'string' ? err : 'Terjadi kesalahan saat membuat stiker meme.');
    }
};

// Konfigurasi handler
handler.help = ['stickermeme <teks_atas|teks_bawah>'];
handler.tags = ['sticker'];
handler.command = /^(smeme|smim|smemeh|stickermeme)$/i;
handler.limit = 1;

module.exports = handler;

/**
 * Membuat meme menggunakan canvas
 * @param {Buffer} imageBuffer - Buffer gambar
 * @param {string} topText - Teks bagian atas
 * @param {string} bottomText - Teks bagian bawah
 * @returns {Promise<Buffer>} - Buffer gambar meme
 */
async function createMeme(imageBuffer, topText, bottomText) {
    try {
        // Load image dari buffer
        const image = await loadImage(imageBuffer);
        
        // Tentukan ukuran canvas
        const width = image.width;
        const height = image.height;
        
        // Buat canvas dengan ukuran yang sama
        const canvas = createCanvas(width, height);
        const ctx = canvas.getContext('2d');
        
        // Gambar image ke canvas
        ctx.drawImage(image, 0, 0, width, height);
        
        // Konfigurasi teks
        const fontSize = Math.floor(width / 10); // Font size proporsional dengan lebar gambar
        const strokeWidth = Math.max(2, Math.floor(fontSize / 15)); // Ketebalan stroke proporsional dengan font
        
        ctx.font = `bold ${fontSize}px Impact, Arial, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = 'white';
        ctx.strokeStyle = 'black';
        ctx.lineWidth = strokeWidth;
        ctx.lineJoin = 'round';
        
        // Fungsi untuk membagi teks menjadi beberapa baris
        function wrapText(text, maxWidth) {
            const words = text.split(' ');
            const lines = [];
            let currentLine = '';
            
            for (let i = 0; i < words.length; i++) {
                const testLine = currentLine.length > 0 
                    ? currentLine + ' ' + words[i] 
                    : words[i];
                    
                const metrics = ctx.measureText(testLine);
                
                if (metrics.width > maxWidth && i > 0) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            
            lines.push(currentLine);
            return lines;
        }
        
        // Tentukan max width untuk teks (80% dari lebar gambar)
        const maxTextWidth = width * 0.8;
        
        // Gambar teks atas
        if (topText) {
            const topLines = wrapText(topText.toUpperCase(), maxTextWidth);
            const topY = fontSize + 10; // Padding dari atas
            
            topLines.forEach((line, index) => {
                const y = topY + (index * fontSize);
                ctx.strokeText(line, width / 2, y);
                ctx.fillText(line, width / 2, y);
            });
        }
        
        // Gambar teks bawah
        if (bottomText) {
            const bottomLines = wrapText(bottomText.toUpperCase(), maxTextWidth);
            const bottomY = height - (bottomLines.length * fontSize) - 10; // Padding dari bawah
            
            bottomLines.forEach((line, index) => {
                const y = bottomY + (index * fontSize);
                ctx.strokeText(line, width / 2, y);
                ctx.fillText(line, width / 2, y);
            });
        }
        
        // Convert canvas ke buffer
        return canvas.toBuffer('image/png');
    } catch (error) {
        console.error('Error creating meme with canvas:', error);
        throw new Error('Gagal membuat meme dengan canvas');
    }
}