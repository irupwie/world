const axios = require("axios");

const handler = async (m, { conn, args, command }) => {
  const q = m.quoted ? m.quoted : m;
  const text = args.length ? args.join(" ") : m.quoted?.text || "";

  if (!text) {
    return m.reply(`*Cara menggunakan fitur quote chat stiker:*

1. Balas pesan seseorang dengan perintah:
   *.${command}*
2. Atau ketik:
   *.${command} [pesan teks]*

Contoh:
*.${command} Halo, apa kabar?*

Keterangan gaya:
> *.qc* = putih  
> *.qc2* = hitam  
> *.qc3* = biru gelap  
> *.qc4* = biru keabu-abuan`);
  }

  const senderName = q.name || m.name || "User";
  const pp = await conn.profilePictureUrl(q.sender || m.sender, "image").catch(() => "https://telegra.ph/file/320b066dc81928b782c7b.png");

  const reply = m.quoted ? {
    name: m.quoted.name || "Unknown",
    text: m.quoted.text || "",
  } : undefined;

  const processingMsg = await m.reply("⏳ Sedang membuat stiker quote, tunggu sebentar...");

  const backgroundColor = {
    qc: "#ffffff",
    qc2: "#030303",
    qc3: "#0C0950",
    qc4: "#1A2634",
  }[command] || "#ffffff";

  const messageObj = {
    type: "quote",
    format: "png",
    backgroundColor,
    width: 512,
    height: 768,
    scale: 2,
    messages: [{
      avatar: true,
      from: {
        name: senderName,
        photo: { url: pp },
      },
      text,
      replyMessage: reply
    }]
  };

  const maxRetries = 3;
  let attempt = 0;
  let success = false;

  while (attempt < maxRetries && !success) {
    try {
      attempt++;
      const response = await axios.post("https://bot.lyo.su/quote/generate", messageObj, {
        headers: { "Content-Type": "application/json" }
      });

      const buffer = Buffer.from(response.data.result.image, "base64");

      await conn.sendImageAsSticker(m.chat, buffer, m, {
        packname: `${global.packname}`,
        author: `${global.author}`
      });

      if (conn.deleteMessage) await conn.deleteMessage(m.chat, processingMsg.key);
      success = true;

    } catch (err) {
      if (attempt >= maxRetries) {
        m.reply(`*Gagal membuat stiker setelah ${maxRetries} percobaan.*\n_Silakan coba lagi nanti atau laporkan ke admin._\n\n_Error: ${err?.message || "Tidak diketahui"}_`);
      }
    }
  }
};

handler.help = ["qc", "qc2", "qc3", "qc4"].map(a => a + " *[text atau balas pesan]*");
handler.tags = ["sticker"];
handler.command = ["qc", "qc2", "qc3", "qc4"];

module.exports = handler;