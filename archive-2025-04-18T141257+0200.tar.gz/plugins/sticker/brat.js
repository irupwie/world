const fetch = require("node-fetch");

let handler = async (m, { conn, text, command, usedPrefix }) => {
    const gifCommands = ['bratgif', 'bratvid', 'bratvideo', 'bratanimasi'];
    const isGif = gifCommands.includes(command);
    const maxLength = isGif ? 250 : 150;

    let input = text || (m.quoted && m.quoted.text);
    if (!input) {
        return m.reply(`*Cara pakai:*
• Ketik: *${usedPrefix}${command} teks kamu*
• Atau balas pesan lalu ketik: *${usedPrefix}${command}*

*Info:*
• *${usedPrefix}brat* = stiker gambar
• *${usedPrefix}bratgif* = stiker animasi (min. 2 kata)
• Maks. ${maxLength} karakter`);
    }

    if (input.length > maxLength) {
        return m.reply(`Maksimal ${maxLength} karakter!`);
    }

    if (isGif && input.trim().split(/\s+/).length < 2) {
        return m.reply("Minimal 2 kata untuk versi animasi!");
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏰",
            key: m.key
        }
    });

    const apiUrl = isGif
        ? `https://api.ryzendesu.vip/api/image/brat/animated?text=${encodeURIComponent(input)}`
        : `https://aqul-brat.hf.space/api/brat?text=${encodeURIComponent(input)}`;

    try {
        const res = await fetch(apiUrl);
        if (!res.ok) throw new Error("Gagal mengambil gambar dari API");

        const buffer = await res.buffer();

        await conn.sendImageAsSticker(m.chat, buffer, m, {
            packname: `${global.packname}`,
            author: `${global.author}`,
        });
    } catch (err) {
        m.reply(`Terjadi kesalahan saat membuat stiker.\n- ${err.message}`);
    }
};

handler.help = ['brat', 'bratgif', 'bratvid', 'bratvideo', 'bratanimasi'];
handler.tags = ['convert'];
handler.command = ['brat', 'bratgif', 'bratvid', 'bratvideo', 'bratanimasi'];
handler.limit = true;

module.exports = handler;