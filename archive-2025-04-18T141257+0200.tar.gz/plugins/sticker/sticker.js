const fs = require('fs');
const sharp = require('sharp');

let handler = async (m, {
    conn,
    command,
    usedPrefix
}) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (/image/.test(mime)) {
        let media = await q.download();

        let processedMedia = await sharp(media)
            .resize(512, 512, {
                fit: 'contain',
                background: { r: 255, g: 255, b: 255, alpha: 0 }
            })
            .png()
            .toBuffer();

        let encmedia = await conn.sendImageAsSticker(m.chat, processedMedia, m, {
            packname: global.packname,
            author: global.author
        });

        await fs.unlinkSync(encmedia);

    } else if (/video/.test(mime)) {
        if ((q.msg || q).seconds > 7) return m.reply('Maksimal durasi video adalah 6 detik!');
        let media = await q.download();

        let encmedia = await conn.sendVideoAsSticker(m.chat, media, m, {
            packname: global.packname,
            author: global.author
        });

        await fs.unlinkSync(encmedia);

    } else {
        m.reply(`*Cara membuat stiker dengan bot ini sangat mudah!*

Cukup kirim atau *balas gambar atau video* dengan caption:
*${usedPrefix}${command}*

Contoh:
1. Kirim gambar, lalu beri caption:
   *${usedPrefix}${command}*
2. Atau balas gambar orang lain dengan ketik:
   *${usedPrefix}${command}*

Catatan:
- Gambar akan otomatis diubah menjadi stiker.
- Untuk video, durasi maksimal adalah *6 detik*. Jika lebih, bot tidak akan memproses.

Selamat mencoba!`);
    }
};

handler.help = ['sticker'];
handler.tags = ['sticker'];
handler.command = ["stiker", "sticker", "setiker", "s", "seticker"];

module.exports = handler;