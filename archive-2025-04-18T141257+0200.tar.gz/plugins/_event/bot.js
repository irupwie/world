//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : _event/bot


const {
    performance
} = require('perf_hooks');
const os = require('os');

const config = {
    ownerContact: '0@s.whatsapp.net',
    customPrefixes: /^(bot|bot\?|bott)$/i
};

const formatUptime = (seconds) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h} jam, ${m} menit, ${s} detik`;
};

const handler = async (m, {
    conn
}) => {
    const start = Date.now();
    const senderName = m.sender.replace(/@.+/g, '');

    const ping = Date.now() - start;
    const uptime = formatUptime(process.uptime());

    const responseText = [
        `*Pong 🏓*`,
        `> Uptime bot: *${uptime}*`,
        `> Waktu respon: *${ping} ms*`,
        `> _Hai @${senderName} 👋🏼_`
    ].join('\n');

    if (conn.updateMessage) {
        await conn.updateMessage(sent, responseText);
    } else {
        await conn.reply(m.chat, responseText, m);
    }
};

handler.customPrefix = config.customPrefixes;
handler.command = new RegExp();

module.exports = handler;