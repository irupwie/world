module.exports = {
  before: async function all(m) {
    const jakarta = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });
    const current = new Date(jakarta);
    
    if (current.getHours() === 0 && current.getMinutes() === 0) {
      let list = Object.entries(global.db.data.users);
      let resetCount = 0;
      
      list.forEach(([user, data]) => {
        if (data.limit === 0) {
          data.limit = 100;
          resetCount++;
        }
      });
      
      if (resetCount > 0) {
        console.log(`${resetCount} user dengan limit 0 berhasil direset pada ${current}`);
      } else {
        console.log(`Tidak ada user dengan limit 0 pada ${current}`);
      }
    }
  }
}