const fs = require('fs');
let handler = m => m;

// Track last activity time for each chat
const chatActivity = {};

handler.all = async function(m, {
    isAdmin,
    isBotAdmin
}) {
    let chat = db.data.chats[m.chat];
    let user = db.data.users[m.sender];
    
    // Update last activity time for this chat
    chatActivity[m.chat] = Date.now();
    
    // Check for autosticker feature
    if (chat.autosticker && !chat.isBanned && !user.banned && !m.isBaileys) {
        let q = m;
        let stiker = false;
        let mime = (q.msg || q).mimetype || '';
        if (/webp/.test(mime)) return;
        if (/image/.test(mime)) {
            try {
                let imgPath = './tmp/temp_image.jpg';
                let img = await q.download();
                if (!img) return;
                fs.writeFileSync(imgPath, img);
                await conn.sendImageAsSticker(m.chat, imgPath, m, {
                    packname: global.packname,
                    author: global.author
                });
                fs.unlink(imgPath, (err) => {
                    if (err) console.error('Gagal menghapus file gambar sementara:', err);
                    else console.log('File gambar sementara dihapus');
                });
            } catch (e) {
                console.error('Error processing image:', e);
                await this.reply(m.chat, 'Gagal membuat stiker dari gambar', m);
                return;
            }
        } else if (/video/.test(mime)) {
            if ((q.msg || q).seconds > 7) return await this.reply(m.chat, 'Durasi maks 6 detik!', m);
            try {
                let videoPath = './tmp/temp_video.mp4';
                let video = await q.download();
                if (!video) return;
                fs.writeFileSync(videoPath, video);
                await conn.sendVideoAsSticker(m.chat, videoPath, m, {
                    packname: global.packname,
                    author: global.author
                });
                fs.unlink(videoPath, (err) => {
                    if (err) console.error('Gagal menghapus file video sementara:', err);
                    else console.log('File video sementara dihapus');
                });
            } catch (e) {
                console.error('Error processing video:', e);
                await this.reply(m.chat, 'Gagal membuat stiker dari video', m);
                return;
            }
        }
    }
    return !0;
}

// Set up a periodic check for inactive chats (runs every minute)
setInterval(() => {
    const thirtyMinutesInMs = 30 * 60 * 1000;
    const currentTime = Date.now();
    
    // Check all chats with recorded activity
    for (const chatId in chatActivity) {
        const lastActivityTime = chatActivity[chatId];
        
        // If more than 30 minutes of inactivity
        if (currentTime - lastActivityTime > thirtyMinutesInMs) {
            try {
                // Disable autosticker if it was enabled
                if (db.data.chats[chatId] && db.data.chats[chatId].autosticker) {
                    db.data.chats[chatId].autosticker = false;
                    console.log(`Autosticker dinonaktifkan untuk chat ${chatId} karena tidak ada aktivitas selama 30 menit`);
                    
                    // Optionally send notification to the chat
                    conn.sendMessage(chatId, { 
                        text: 'Fitur autosticker dinonaktifkan karena tidak ada aktivitas selama 30 menit' 
                    });
                }
                
                // Remove from tracking after handling
                delete chatActivity[chatId];
            } catch (e) {
                console.error(`Error disabling autosticker for chat ${chatId}:`, e);
            }
        }
    }
}, 60000); // Check every minute

module.exports = handler;