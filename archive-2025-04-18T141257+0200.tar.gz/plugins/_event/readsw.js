let handler = m => m;

handler.before = async function(m, { conn }) {
	let setbot = db.data.settings[conn.user.jid] || {};
	if (m.key.remoteJid !== "status@broadcast" || !setbot.autoReadSw) return;

	conn.story = conn.story || [];

	const config = {
		ownerJid: owner[1][0] + "@s.whatsapp.net",
		emojis: [
			"😀", "😂", "😍", "🥺", "😎", "😢", "😡", "😱", "👍", "👎",
			"👏", "💪", "🙏", "🎉", "🎂", "🌟", "🌈", "🔥", "🍎", "🍕",
			"🍔", "🍟", "🍣", "🍜", "🎸", "🎧", "🎤", "🎬", "🏆", "⚽",
			"🏀", "🏈", "🏊", "🚴", "🚗", "✈️", "🚀", "🚂", "🏠", "🌍"
		]
	};

	const sendReact = async () => {
		let emoji = config.emojis.getRandom();
		try {
			await conn.sendMessage(m.key.remoteJid, {
				react: { text: emoji, key: m.key }
			}, { statusJidList: [m.key.participant, m.sender] });
		} catch (e) {
			console.error("Error saat me-react SW:", e.message);
		}
	};

	const handleMedia = async () => {
		let caption = m.text || '';
		await conn.readMessages([m.key]);
		await sendReact();

		try {
			let media = await m.download();
			await conn.sendFile(config.ownerJid, media, '', caption, m, false, {
				mentions: [m.sender],
				mimetype: m.mimetype
			});

			conn.story.push({
				sender: m.sender,
				time: new Date(),
				type: m.mtype,
				caption,
				quoted: m,
				buffer: media
			});
		} catch (e) {
			console.log(e);
			await conn.reply(config.ownerJid, caption, m, {
				mentions: [m.sender]
			});
		}
	};

	const handleText = async () => {
		let caption = m.text || '';
		await conn.readMessages([m.key]);
		await sendReact();

		await conn.reply(config.ownerJid, caption, m, {
			mentions: [m.sender]
		});

		conn.story.push({
			sender: m.sender,
			time: new Date(),
			type: m.mtype,
			message: caption,
			quoted: m
		});
	};

	switch (m.mtype) {
		case "videoMessage":
		case "imageMessage":
		case "audioMessage":
			await handleMedia();
			break;
		case "extendedTextMessage":
			await handleText();
			break;
	}
};

module.exports = handler;