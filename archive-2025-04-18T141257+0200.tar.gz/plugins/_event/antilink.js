const fs = require('fs');
const path = require('path');

const warnFile = path.join(__dirname, '../../database/warn.json');

// CONFIGURATION: Simply add new link types here
const LINK_TYPES = {
  whatsapp: {
    name: "WhatsApp Group",
    regex: /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i,
    configKey: "antiLink",
    isOwnGroupExempt: true  // Special flag for WhatsApp links only
  },
  youtube: {
    name: "YouTube",
    regex: /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/\S+|youtu\.be\/\S+)/i,
    configKey: "antilinkyt"
  },
  whatsappch: {
  name: "WhatsApp Channel",
  regex: /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/[a-zA-Z0-9]+/i,
  configKey: "antilinkch"
  },
  instagram: {
    name: "Instagram",
    regex: /(?:https?:\/\/)?(?:www\.)?(?:instagram\.com|instagr\.am)\/(?:p|reel|tv|stories|guide|explore|[\w.-]+)\/[^\s]+/i,
    configKey: "antilinkig"
  },
};

// Warn data management
function loadWarnData() {
  try {
    const data = JSON.parse(fs.readFileSync(warnFile, 'utf-8'));
    if (!data || typeof data !== 'object') return { groups: {} };
    if (!data.groups) data.groups = {};
    return data;
  } catch {
    return { groups: {} };
  }
}

function saveWarnData(data) {
  try {
    const dir = path.dirname(warnFile);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(warnFile, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving warn data:', error);
    return false;
  }
}

// Main handler
let handler = m => m;

handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
  // Skip processing for non-group messages or messages from the bot
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;

  let chat = global.db.data.chats[m.chat];
  if (!chat) return true;

  // Initialize warn data
  let warnData = loadWarnData();
  if (!warnData.groups[m.chat]) {
    warnData.groups[m.chat] = { max: 5, users: {} };
  }

  try {
    // Check for each link type
    for (const [typeId, linkType] of Object.entries(LINK_TYPES)) {
      // Skip if this anti-link feature is not enabled
      if (!chat[linkType.configKey]) continue;
      
      // Skip if no matching link found
      if (!linkType.regex.test(m.text)) continue;
      
      // Get sender name for notifications
      const senderName = await conn.getName(m.sender);
      
      // Check for WhatsApp own group link exception
      if (linkType.isOwnGroupExempt) {
        try {
          const currentGroupLink = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(m.chat);
          const isCurrentGroupLink = new RegExp(currentGroupLink, 'i').test(m.text);
          
          if (isCurrentGroupLink) {
            await m.reply('*「 ANTI LINK 」*\n\nLink yang dibagikan adalah milik grup ini sendiri.');
            return true;
          }
        } catch (error) {
          console.error('Error checking current group link:', error);
        }
      }
      
      // Admin exception
      if (isAdmin) {
        await m.reply(`*「 ANTI LINK ${linkType.name.toUpperCase()} 」*\n\nAnda adalah admin grup, pengecualian diberikan.`);
        return true;
      }
      
      // Bot not admin warning
      if (!isBotAdmin) {
        await m.reply(`*「 ANTI LINK ${linkType.name.toUpperCase()} 」*\n\nBot bukan admin, tidak bisa mengeluarkan pengguna.`);
        return true;
      }
      
      // Process the violation
      const groupData = warnData.groups[m.chat];
      const userWarns = groupData.users[m.sender] || 0;
      
      // Increment warning counter
      groupData.users[m.sender] = userWarns + 1;
      saveWarnData(warnData);
      
      // Delete the message with the link
      await conn.sendMessage(m.chat, { delete: m.key });
      
      // Check if max warnings reached
      if (groupData.users[m.sender] >= groupData.max) {
        // Reset counter and kick user
        groupData.users[m.sender] = 0;
        saveWarnData(warnData);
        
        await m.reply(`*「 ANTI LINK ${linkType.name.toUpperCase()} 」*\n\n*${senderName}* telah mengirim link ${linkType.name} sebanyak ${groupData.max} kali.\nPengguna akan dikeluarkan.`);
        
        setTimeout(async () => {
          try {
            await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
          } catch (error) {
            console.error('Gagal mengeluarkan peserta:', error);
            await m.reply('*「 ERROR 」*\n\nGagal mengeluarkan pengguna dari grup.');
          }
        }, 1000);
      } else {
        // Just warn the user
        await m.reply(`*「 ANTI LINK ${linkType.name.toUpperCase()} 」*\n\n*${senderName}*, Anda mengirim link ${linkType.name}!\nPeringatan ${groupData.users[m.sender]}/${groupData.max}\nLink akan dihapus, dan Anda akan dikeluarkan setelah ${groupData.max} peringatan.`);
      }
      
      return true; // End processing after handling a link
    }
  } catch (error) {
    console.error('Error dalam handler antiLink:', error);
  }

  return true;
};

module.exports = handler;