const fs = require('fs').promises
const path = require('path')

const ROOT_FOLDER = path.resolve(__dirname, '../../database')
const DB_BASE_FOLDER = path.join(ROOT_FOLDER, 'totalpesan')

const initFolders = async () => {
    try {
        await fs.mkdir(DB_BASE_FOLDER, {
            recursive: true
        })
    } catch (err) {
        console.error('Gagal membuat folder database:', err)
    }
}

initFolders()

const getGroupFilePath = (groupId) => {
    const safeGroupId = groupId.replace(/[^a-zA-Z0-9]/g, '_')
    return path.join(DB_BASE_FOLDER, `${safeGroupId}.json`)
}

const fileExists = async (filePath) => {
    try {
        await fs.access(filePath)
        return true
    } catch {
        return false
    }
}

const ensureGroupDatabase = async (groupId) => {
    try {
        const groupFilePath = getGroupFilePath(groupId)
        const dbExists = await fileExists(groupFilePath)
        if (!dbExists) {
            const emptyGroupDb = {
                groupId,
                createdAt: new Date().toISOString(),
                lastUpdated: new Date().toISOString(),
                members: {},
            }
            await fs.writeFile(groupFilePath, JSON.stringify(emptyGroupDb, null, 2), 'utf-8')
        }
    } catch (error) {
        console.error(`Error ensuring database for group ${groupId}:`, error)
        throw error
    }
}

const loadGroupDatabase = async (groupId) => {
    try {
        await ensureGroupDatabase(groupId)
        const groupFilePath = getGroupFilePath(groupId)
        const data = await fs.readFile(groupFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        console.error(`Error reading database for group ${groupId}:`, error)
        return {
            groupId,
            createdAt: new Date().toISOString(),
            lastUpdated: new Date().toISOString(),
            members: {},
        }
    }
}

const saveGroupDatabase = async (groupId, data) => {
    try {
        data.lastUpdated = new Date().toISOString()
        const groupFilePath = getGroupFilePath(groupId)
        await fs.writeFile(groupFilePath, JSON.stringify(data, null, 2), 'utf-8')
    } catch (error) {
        console.error(`Error saving database for group ${groupId}:`, error)
        throw error
    }
}

const before = async (m) => {
    if (m.isBaileys && m.fromMe) return true
    if (!m.isGroup) return true
    try {
        const {
            chat: groupId,
            sender: senderId
        } = m
        const groupData = await loadGroupDatabase(groupId)
        if (!groupData.members[senderId]) {
            groupData.members[senderId] = {
                totalPesan: 0,
                firstMessage: new Date().toISOString(),
                lastMessage: new Date().toISOString(),
            }
        }
        groupData.members[senderId].totalPesan += 1
        groupData.members[senderId].lastMessage = new Date().toISOString()
        await saveGroupDatabase(groupId, groupData)
        return true
    } catch (error) {
        console.error('Error in before handler:', error)
        return true
    }
}

const getGroupStats = async (groupId) => {
    try {
        const groupData = await loadGroupDatabase(groupId)
        const totalMessages = Object.values(groupData.members).reduce(
            (sum, member) => sum + member.totalPesan,
            0
        )
        const memberRanking = Object.entries(groupData.members)
            .map(([id, data]) => ({
                id,
                totalPesan: data.totalPesan
            }))
            .sort((a, b) => b.totalPesan - a.totalPesan)
        return {
            groupId,
            totalMessages,
            memberCount: Object.keys(groupData.members).length,
            topMembers: memberRanking.slice(0, 5),
            lastUpdated: groupData.lastUpdated,
        }
    } catch (error) {
        console.error(`Error getting stats for group ${groupId}:`, error)
        return {
            error: 'Failed to retrieve group statistics'
        }
    }
}

const listGroups = async () => {
    try {
        const files = await fs.readdir(DB_BASE_FOLDER)
        return files
            .filter((file) => file.endsWith('.json'))
            .map((file) => path.basename(file, '.json'))
    } catch (error) {
        console.error('Error listing groups:', error)
        return []
    }
}

module.exports = {
    before,
    loadGroupDatabase,
    saveGroupDatabase,
    getGroupStats,
    listGroups
}