const os = require("os");
const { exec } = require("child_process");

module.exports = {
    help: ["os *[os info]*"],
    tags: ["info"],
    command: ["os"],
    code: async (m, {
        conn
    }) => {
        const formatBytes = (bytes) => {
            const gb = bytes / (1024 ** 3);
            const mb = bytes / (1024 ** 2);
            return gb >= 1
                ? `${gb.toFixed(2)} GB`
                : `${mb.toFixed(2)} MB`;
        };

        let timestamp = Date.now();
        let latensi = Date.now() - timestamp;

        exec(`neofetch --stdout`, (error, stdout) => {
            let info = stdout.toString("utf-8").replace(/Memory:/, "RAM:");
            let usedHeap = process.memoryUsage().heapUsed;
            let totalMem = os.totalmem();
            let freeMem = os.freemem();

            m.reply(`*=== Informasi Sistem ===*\n\n${info}\n*Latensi:* ${latensi.toFixed(2)} ms\n*Heap Digunakan:* ${formatBytes(usedHeap)}\n*RAM Tersedia:* ${formatBytes(freeMem)}\n*RAM Total:* ${formatBytes(totalMem)}\n*OS:* ${os.version()}\n*Platform:* ${os.platform()}\n*Hostname:* ${os.hostname()}`);
        });
    }
};