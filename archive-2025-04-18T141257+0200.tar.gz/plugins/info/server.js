const axios = require("axios");
const os = require("os");
const moment = require("moment-timezone");

let handler = async (m) => {
  try {
    const response = await axios.get('http://ip-api.com/json/');
    const serverInfo = response.data;

    const osType = os.type(); // 'Linux', 'Darwin', 'Windows_NT'
    const osPlatform = os.platform(); // 'linux', 'win32', 'darwin'
    const osArch = os.arch(); // 'x64', 'arm', etc.
    const totalRAM = Math.floor(os.totalmem() / (1024 * 1024));
    const freeRAM = Math.floor(os.freemem() / (1024 * 1024));
    const usedRAM = totalRAM - freeRAM;
    const uptime = os.uptime();
    const uptimeFormatted = formatUptime(uptime);
    const processor = os.cpus()[0].model;
    const cpuCores = os.cpus().length;
    const loadAvg = os.loadavg().map(avg => avg.toFixed(2)).join(', ');
    const hostname = os.hostname();
    const networkInterfaces = os.networkInterfaces();

    // Current time in server's timezone
    const currentTime = moment().tz(serverInfo.timezone).format('YYYY-MM-DD HH:mm:ss');

    let serverMessage = `•  S E R V E R   I N F O\n\n`;
    serverMessage += `┌  ◦  Hostname : ${hostname}\n`;
    serverMessage += `│  ◦  OS : ${osType} (${osPlatform}) [${osArch}]\n`;
    serverMessage += `│  ◦  Processor : ${processor} (${cpuCores} cores)\n`;
    serverMessage += `│  ◦  Load Average (1m, 5m, 15m) : ${loadAvg}\n`;
    serverMessage += `│  ◦  RAM Used : ${usedRAM} MB / ${totalRAM} MB\n`;
    serverMessage += `│  ◦  Uptime : ${uptimeFormatted}\n`;
    serverMessage += `│  ◦  Current Time : ${currentTime}\n`;
    serverMessage += `│\n`;
    serverMessage += `├  ◦  Geo Info\n`;
    serverMessage += `│  ◦  Country : ${serverInfo.country} (${serverInfo.countryCode})\n`;
    serverMessage += `│  ◦  Region : ${serverInfo.regionName} (${serverInfo.region})\n`;
    serverMessage += `│  ◦  City : ${serverInfo.city}\n`;
    serverMessage += `│  ◦  Zip : ${serverInfo.zip}\n`;
    serverMessage += `│  ◦  Coordinates : ${serverInfo.lat}, ${serverInfo.lon}\n`;
    serverMessage += `│  ◦  Timezone : ${serverInfo.timezone}\n`;
    serverMessage += `│\n`;
    serverMessage += `├  ◦  Network\n`;
    serverMessage += `│  ◦  ISP : ${serverInfo.isp}\n`;
    serverMessage += `│  ◦  Org : ${serverInfo.org}\n`;
    serverMessage += `│  ◦  AS : ${serverInfo.as}\n`;
    serverMessage += `│  ◦  IP : HIDDEN\n`;

    // Append network interfaces
    serverMessage += `│  ◦  Interfaces :\n`;
    Object.entries(networkInterfaces).forEach(([name, infos]) => {
      infos.forEach(info => {
        if (!info.internal && info.family === 'IPv4') {
          serverMessage += `│     ◦  ${name} - ${info.address}\n`;
        }
      });
    });

    serverMessage += `└─────────────────────`;

    await m.reply(serverMessage);
  } catch (e) {
    console.error(e);
    await m.reply("Gagal mengambil data server.");
  }
};

function formatUptime(uptime) {
  const seconds = Math.floor(uptime % 60);
  const minutes = Math.floor((uptime / 60) % 60);
  const hours = Math.floor((uptime / (60 * 60)) % 24);
  const days = Math.floor(uptime / (60 * 60 * 24));

  return [
    days ? `${days}d` : '',
    hours ? `${hours}h` : '',
    minutes ? `${minutes}m` : '',
    seconds ? `${seconds}s` : ''
  ].filter(Boolean).join(' ');
}

handler.command = ['server'];
handler.tags = ['info'];
handler.help = ['server'];

module.exports = handler;