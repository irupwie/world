let handler = async (m, { conn, args }) => {
    let showDetail = args.includes('--detail');
    let groupIds = Object.keys(conn.chats).filter(id => id.endsWith('@g.us'));
    if (!groupIds.length) return m.reply("Bot tidak tergabung di grup manapun.");

    let allMentions = [];
    let text = `╭───〔 *List Grup Bot* 〕───╮\n\n`;

    for (let i = 0; i < groupIds.length; i++) {
        let id = groupIds[i];
        let metadata = await conn.groupMetadata(id).catch(() => null);
        if (!metadata) continue;

        let ownerJid = metadata.owner || '';
        if (ownerJid) allMentions.push(ownerJid);

        text += `*${i + 1}. ${metadata.subject}*\n`;
        text += `├ ID        : ${id}\n`;
        text += `├ Members   : ${metadata.participants.length}\n`;
        text += `├ Owner     : ${ownerJid ? `@${ownerJid.split('@')[0]}` : 'Tidak diketahui'}\n`;

        if (showDetail) {
            let members = metadata.participants.map(p => `@${p.id.split('@')[0]}`).join('\n    ');
            text += `└ Anggota   :\n    ${members}\n\n`;
            allMentions.push(...metadata.participants.map(p => p.id));
        } else {
            text += `└──────────────\n\n`;
        }
    }

    text += `╰───────────────╯`;

    m.reply(text.trim(), null, { mentions: [...new Set(allMentions)] });
};

handler.help = ["listgc", "gcl"];
handler.tags = ["info"];
handler.command = ["listgc", "gcl"];

module.exports = handler;