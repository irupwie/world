let handler = async (m) => {
  m.reply(`
┌─〔 *Special Thanks To* 〕─⬣
│ • *Tuhan Yang Maha Esa* (Pencipta Segalanya)
│ • *Botcahx* (Base Script)
│ • *WibuSoft* (Sumber Inspirasi)
│ • *Carl* (Kontributor Spesial)
└─────────────⬣
`);
};

handler.help = ["tqto *[credits script]*"];
handler.tags = ["info"];
handler.command = ["tqto", "thank", "tq"];

module.exports = handler;