let handler = async (m, { conn, text, usedPrefix, command }) => {
  let formatDuration = (ms) => {
    let seconds = Math.floor(ms / 1000) % 60;
    let minutes = Math.floor(ms / (60 * 1000)) % 60;
    let hours = Math.floor(ms / (60 * 60 * 1000)) % 24;
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    return [
      days ? `${days} hari` : "",
      hours ? `${hours} jam` : "",
      minutes ? `${minutes} menit` : "",
      seconds ? `${seconds} detik` : "",
    ].filter(v => v).join(", ");
  };

  let botUptime = formatDuration(process.uptime() * 1000);
  let osUptime = formatDuration(require("os").uptime() * 1000);

  let info = `*[ INFO RUNTIME BOT ]*\n\n` +
             `> • *Bot Aktif Selama:* ${botUptime}\n` +
             `> • *Sistem Operasi Aktif Selama:* ${osUptime}`;

  m.reply(info);
};

handler.help = ["runtime", "uptime"].map((a) => a + " *[Runtime bot]*");
handler.tags = ["info"];
handler.command = ["runtime", "uptime"];
module.exports = handler;