let handler = async (m, { conn }) => {
  let nomor = global.owner;
  let array = [];

  for (let i of nomor) {
    let nama = await conn.getName(i + "@s.whatsapp.net");
    array.push([i, nama]);
  }

  await conn.sendContact(m.chat, array, m);
};

handler.help = ["owner", "creator"];
handler.tags = ["info"];
handler.command = ["owner", "creator"];

module.exports = handler;