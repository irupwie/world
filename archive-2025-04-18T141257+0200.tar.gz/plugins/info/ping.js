const os = require("os");
const { performance } = require("perf_hooks");
const { sizeFormatter } = require("human-readable");
const format = sizeFormatter({
    std: "JEDEC",
    decimalPlaces: 2,
    render: (literal, symbol) => `${literal} ${symbol}B`,
});

let handler = async (m, { conn }) => {
    const used = process.memoryUsage();
    const totalRAM = os.totalmem();
    const freeRAM = os.freemem();
    const usedRAM = totalRAM - freeRAM;
    const ramUsagePercentage = ((usedRAM / totalRAM) * 100).toFixed(2);

    const cpus = os.cpus();
    const cpuModel = cpus[0]?.model.trim();
    const cpuSpeed = cpus[0]?.speed;
    const cpuUsage = getCpuUsage();

    const netInterfaces = os.networkInterfaces();
    const mainInterface = getMainNetworkInterface(netInterfaces);
    const ipAddress = mainInterface?.address || "Unknown";

    const chats = Object.values(conn.chats).filter(c => c.isChats);
    const groups = chats.filter(c => c.jid?.endsWith("@g.us"));
    const personal = chats.length - groups.length;
    const activeChats = chats.filter(c => c.unread > 0).length;

    const uptime = process.uptime() * 1000;
    let old = performance.now();
    let neww = performance.now();
    let speed = neww - old;

    const osInfo = {
        platform: os.platform(),
        release: os.release(),
        type: os.type(),
        arch: os.arch(),
        hostname: os.hostname(),
        loadavg: os.loadavg()[0].toFixed(2)
    };

    let statusBar = (percent) => {
        const completed = Math.round(percent / 10);
        return "█".repeat(completed) + "░".repeat(10 - completed);
    };

    let txt = `
*╔════❰ 𝗕𝗢𝗧 𝗦𝗧𝗔𝗧𝗨𝗦 ❱════╗*

*🔄 Performance*
❯ *Ping:* ${Math.round(speed)} ms
❯ *Uptime:* ${clockString(uptime)}
❯ *Status:* ${Math.round(speed) < 300 ? '✅ Good' : '⚠️ Needs attention'}

*💬 Chat Statistics*
❯ *Total Chats:* ${chats.length}
❯ *Groups:* ${groups.length}
❯ *Personal:* ${personal}
❯ *Active Chats:* ${activeChats}

*💻 System Resources*
❯ *RAM Usage:* ${ramUsagePercentage}% ${statusBar(ramUsagePercentage)}
❯ *Used:* ${format(usedRAM)} / ${format(totalRAM)}
❯ *Free:* ${format(freeRAM)}
❯ *Heap Usage:* ${(used.heapUsed / 1024 / 1024).toFixed(2)} MB

*⚙️ CPU Information*
❯ *Model:* ${cpuModel}
❯ *Speed:* ${cpuSpeed} MHz
❯ *Cores:* ${cpus.length}
❯ *Load:* ${cpuUsage}% ${statusBar(cpuUsage)}

*🖥️ System Information*
❯ *OS:* ${osInfo.type} ${osInfo.release} (${osInfo.platform})
❯ *Architecture:* ${osInfo.arch}
❯ *IP Address:* ${ipAddress}
❯ *Hostname:* ${osInfo.hostname}
❯ *System Load:* ${osInfo.loadavg}

*╚════════════════════╝*
`.trim();

    m.reply(txt);
};

handler.help = ["status", "ping", "speed"];
handler.tags = ["info", "tools"];
handler.command = ["status", "ping", "speed"];
module.exports = handler;

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [
        h > 0 ? h + ' hour' + (h > 1 ? 's' : '') : '',
        m > 0 ? m + ' minute' + (m > 1 ? 's' : '') : '',
        s + ' second' + (s > 1 ? 's' : '')
    ].filter(Boolean).join(', ');
}

function getCpuUsage() {
    const load = os.loadavg()[0];
    const cpuCount = os.cpus().length;
    const usage = (load / cpuCount) * 100;
    return usage.toFixed(2);
}

function getMainNetworkInterface(interfaces) {
    for (const name in interfaces) {
        const iface = interfaces[name];
        for (const entry of iface) {
            if (!entry.internal && entry.family === 'IPv4') {
                return entry;
            }
        }
    }
    for (const name in interfaces) {
        const iface = interfaces[name];
        for (const entry of iface) {
            if (!entry.internal) {
                return entry;
            }
        }
    }
    const firstInterface = Object.values(interfaces)[0];
    return firstInterface ? firstInterface[0] : null;
}