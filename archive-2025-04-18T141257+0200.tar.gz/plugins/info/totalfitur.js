let handler = async (m, { command }) => {
  const plugins = Object.values(global.plugins);

  const activeCommands = plugins
    .filter(p => p.help && !p.disabled)
    .flatMap(p => p.help);

  const totalPlugins = plugins.length;
  const totalCommands = activeCommands.length;

  m.reply(
    `*+ T O T A L - F E A T U R E S*\n\n` +
    `*• Total Files :* ${totalPlugins}\n` +
    `*• Total Command :* ${totalCommands}\n\n`
  );
};

handler.help = ["totalfitur *[get total features]*"];
handler.tags = ["info"];
handler.command = ["totalfitur"];

module.exports = handler;