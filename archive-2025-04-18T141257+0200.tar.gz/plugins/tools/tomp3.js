const { toPTT, toAudio } = require('../../lib/converter.js');

let handler = async (m, { conn, usedPrefix, command }) => {
    try {
        const chat = global.db.data.chats[m.chat];
        const q = m.quoted ? m.quoted : m;
        const mime = (m.quoted ? m.quoted : m.msg).mimetype || '';

        // Cek apakah mime type bukan audio atau video
        if (!/^audio|^video/.test(mime)) {
            throw `*Format tidak didukung!*\n\nFormat yang didukung:\n- Audio\n- Voice Note (VN)\n- Video\n\nBalas salah satu media di atas dengan caption *${usedPrefix + command}*`;
        }

        const media = await q.download?.();
        if (!media) throw 'Gagal mengunduh media. Coba lagi.';

        let audio;
        if (/tovn|toppt/i.test(command)) {
            audio = await toPTT(media, 'mp4');
        } else {
            audio = await toAudio(media, 'mp4');
        }

        if (!audio?.data) throw 'Gagal mengonversi media ke audio.';

        await conn.sendFile(
            m.chat,
            audio.data,
            'audio.mp3',
            '',
            m,
            null,
            {
                mimetype: 'audio/mp4',
                ptt: /tovn|toppt/i.test(command),
                asDocument: !/tovn|toppt/i.test(command) && chat?.useDocument
            }
        );
    } catch (err) {
        console.error(err);
        m.reply(typeof err === 'string' ? err : 'Terjadi kesalahan saat mengonversi media.');
    }
};

handler.help = ['tovn', 'toppt', 'tomp3', 'toaudio'];
handler.tags = ['tools'];
handler.command = ['tovn', 'toppt', 'tomp3', 'toaudio'];
handler.limit = 1;

module.exports = handler;