let handler = async(m, { text, usedPrefix, command }) => {
	
	if (!text) throw `Input link!`
	
	let idJid = text.split('/');
	let jid = idJid[4] ? idJid[4] : idJid[0]; 
	let reqs = await conn.newsletterMetadata("invite", jid);
	if (!reqs?.name) throw `Link invalid!`
	
	let txt = `*[ ✓ ] Inspect Newsletter Metadata*\n\n` +
		` *◈ Name :* ${reqs.name}\n` +
		` *◈ Status :* ${reqs.state}\n` +
		` *◈ CreatedAt :* ${konversiTimestamp(reqs.creation_time)}\n` +
		` *◈ JID :* ${reqs.id}\n` +
		` *◈ Followers :* ${reqs.subscribers}\n` +
		` *◈ Verification :* ${reqs.verification}\n` +
		` *◈ Description :* \n` + reqs.description
	
	await m.reply(txt)
};
handler.help = ["inspectchannel"];
handler.tags = ["tools"];
handler.command = ["inspectchannel", "inspectch"]
handler.limit = true

module.exports = handler;	
		
function konversiTimestamp(timestamp) {

    // Buat objek Date dari timestamp (dalam detik)
    var tanggalWaktu = new Date(timestamp * 1000);
    // Format tanggal dan waktu
    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
    var formatTanggalWaktu = tanggalWaktu.toLocaleDateString('id-ID', options);

    // Mendapatkan hari dan bulan dalam bahasa Indonesia
    var hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    var bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

    var hariID = hari[tanggalWaktu.getDay()];
    var bulanID = bulan[tanggalWaktu.getMonth()];
    
    return formatTanggalWaktu || "Unknown"
}