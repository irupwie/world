//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : tools/toimg


const handler = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    const notStickerMessage = `Reply stiker dengan: *${usedPrefix + command}*`

    if (!m.quoted) return m.reply(notStickerMessage)

    const q = m.quoted || m
    const mime = q.mtype || '' // Gunakan mtype, bukan mediaType

    if (!/sticker/.test(mime)) return m.reply(notStickerMessage)

    try {
        const media = await q.download()
        await conn.sendMessage(
            m.chat, {
                image: media,
                caption: ''
            }, {
                quoted: m
            }
        )
    } catch (err) {
        console.error(err)
        m.reply('❌ Gagal mengonversi stiker ke gambar.')
    }
}

handler.help = ['toimg']
handler.tags = ['tools']
handler.command = ['toimg']

module.exports = handler