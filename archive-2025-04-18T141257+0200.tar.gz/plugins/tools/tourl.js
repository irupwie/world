const fetch = require("node-fetch");
const FormData = require("form-data");
const fileType = require("file-type");

let handler = async (m, {
    conn
}) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    if (!mime) throw 'Tidak ada media yang ditemukan';

    let media = await q.download();
    let isSupported = /image\/(png|jpe?g|gif)|video\/mp4|audio\/mp3/.test(mime);
    if (!isSupported) throw 'Format file tidak didukung untuk upload';

    let url = await uploadToCatbox(media);
    let sizeMB = (media.length / (1024 * 1024)).toFixed(2);

    await m.reply(`*Berhasil diupload!*\n\n• URL: ${url}\n• Ukuran: ${sizeMB} MB`);
};

handler.help = ['tourl'];
handler.tags = ['tools'];
handler.command = ["tourl", "upload"]
handler.limit = 1

module.exports = handler;

async function uploadToCatbox(buffer) {
    let {
        ext
    } = await fileType.fromBuffer(buffer);
    let form = new FormData();
    form.append("fileToUpload", buffer, `file.${ext}`);
    form.append("reqtype", "fileupload");

    let res = await fetch("https://catbox.moe/user/api.php", {
        method: "POST",
        body: form,
    });

    if (!res.ok) throw new Error(`Gagal upload: ${res.statusText}`);

    return await res.text();
}