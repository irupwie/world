const { proto } = require("baileys");
const handler = async (m, { conn, text, command, usedPrefix }) => {
  db.data.msg = db.data.msg ? db.data.msg : {};
  let M = proto.WebMessageInfo;

  if (command.startsWith("add")) {
    if (!m.quoted) {
      throw `Contoh: *${usedPrefix + command} ucapanpagi*\nBalas pesan/media yang ingin disimpan dengan nama itu.`;
    } else if (!text) {
      throw `Contoh: *${usedPrefix + command} ucapanpagi*\nBalas ${command.replace('add', '')} dan beri nama.`;
    }

    const mediaType = command.replace('add', '');
    let msgs = db.data.msg;
    if (text in msgs) {
      throw `'${text}' sudah ada! Gunakan nama lain.`;
    }

    const quotedObj = await m.getQuotedObj();
    msgs[text] = {
      content: M.fromObject(quotedObj).toJSON(),
      type: mediaType,
      date: new Date().toLocaleString(),
      sender: m.sender
    };

    m.reply(`✅ Berhasil menyimpan ${mediaType}: *[ ${text} ]*\n\nGunakan *${usedPrefix}get${mediaType} ${text}* untuk mengambilnya.`);
  } 
  else if (command.startsWith("get")) {
    if (!text) {
      const mediaType = command.replace('get', '');
      throw `Contoh: *${usedPrefix}${command} ucapanpagi*\nAmbil ${mediaType} yang telah disimpan.\nGunakan *${usedPrefix}list${mediaType}* untuk melihat daftar.`;
    }

    let msgs = db.data.msg;
    if (!(text in msgs)) {
      throw `'${text}' tidak ditemukan!\nGunakan *${usedPrefix}listmsg* untuk melihat semua pesan tersimpan.`;
    }

    const requestedType = command.replace('get', '');
    let storedType = '';
    let msg = null;

    if (msgs[text].type) {
      storedType = msgs[text].type || '';
      if (requestedType && requestedType !== storedType && requestedType !== 'msg') {
        throw `'${text}' bukan tipe ${requestedType}, tapi ${storedType}.\nGunakan *${usedPrefix}get${storedType} ${text}* sebagai gantinya.`;
      }

      msg = msgs[text].content;
    } else {
      msg = msgs[text];
      storedType = 'message';
    }

    try {
      await conn.sendMessage(m.chat, { forward: msg }, { quoted: m });
      m.reply(`✅ ${storedType} berhasil dikirim: *[ ${text} ]*`);
    } catch (error) {
      m.reply(`❌ Gagal mengambil pesan: ${error.message}\nCoba simpan ulang pesannya.`);
    }
  }
  else if (command === "delmsg" || command === "deletemsg") {
    if (!text) {
      throw `Contoh: *${usedPrefix + command} ucapanpagi*\nHapus pesan tersimpan dengan nama itu.`;
    }

    let msgs = db.data.msg;
    if (!(text in msgs)) {
      throw `'${text}' tidak ditemukan!\nGunakan *${usedPrefix}listmsg* untuk melihat semua pesan tersimpan.`;
    }

    const msgSender = msgs[text].sender;
    if (msgSender && msgSender !== m.sender && !m.isOwner) {
      throw `❌ Hanya bisa menghapus pesan yang kamu simpan sendiri atau jika kamu admin.`;
    }

    const msgType = msgs[text].type || 'message';
    delete msgs[text];
    m.reply(`✅ ${msgType} berhasil dihapus: *[ ${text} ]*`);
  }
  else if (command === "renamemsg") {
    if (!text) {
      throw `Contoh: *${usedPrefix + command} lama|baru*\nGanti nama pesan dari "lama" ke "baru".`;
    }

    const [oldName, newName] = text.split('|').map(v => v.trim());
    if (!oldName || !newName) {
      throw `Format salah!\nContoh: *${usedPrefix + command} lama|baru*`;
    }

    let msgs = db.data.msg;
    if (!(oldName in msgs)) {
      throw `'${oldName}' tidak ditemukan!\nGunakan *${usedPrefix}listmsg* untuk melihat semua pesan.`;
    }

    if (newName in msgs) {
      throw `'${newName}' sudah ada! Gunakan nama lain.`;
    }

    const msgSender = msgs[oldName].sender;
    if (msgSender && msgSender !== m.sender && !m.isOwner) {
      throw `❌ Hanya bisa mengganti nama pesan milikmu atau jika kamu admin.`;
    }

    msgs[newName] = msgs[oldName];
    delete msgs[oldName];
    m.reply(`✅ Nama pesan diubah dari *[ ${oldName} ]* ke *[ ${newName} ]*`);
  }
  else if (command === "infomsg") {
    if (!text) {
      throw `Contoh: *${usedPrefix + command} ucapanpagi*\nLihat detail info dari pesan yang disimpan.`;
    }

    let msgs = db.data.msg;
    if (!(text in msgs)) {
      throw `'${text}' tidak ditemukan!\nGunakan *${usedPrefix}listmsg* untuk melihat semua pesan.`;
    }

    const msg = msgs[text];
    const msgType = msg.type || 'message';
    const msgDate = msg.date || 'Tidak diketahui';
    const msgSender = msg.sender ? `@${msg.sender.split('@')[0]}` : 'Tidak diketahui';

    let infoText = `*📝 INFO PESAN*\n\n`;
    infoText += `• *Nama:* ${text}\n`;
    infoText += `• *Tipe:* ${msgType}\n`;
    infoText += `• *Ditambahkan oleh:* ${msgSender}\n`;
    infoText += `• *Tanggal:* ${msgDate}\n`;
    infoText += `\nGunakan *${usedPrefix}get${msgType} ${text}* untuk mengambil pesan ini.`;

    m.reply(infoText, null, {
      mentions: msg.sender ? [msg.sender] : []
    });
  }
  else if (command.startsWith("list")) {
    let msgs = db.data.msg;
    let listMsg = Object.keys(msgs);
    const requestedType = command.replace('list', '');

    if (requestedType && requestedType !== 'msg') {
      listMsg = listMsg.filter(key => 
        msgs[key].type && msgs[key].type === requestedType
      );
    }

    if (listMsg.length === 0) {
      m.reply(`Belum ada ${requestedType || 'pesan'} tersimpan.\nBalas pesan lalu ketik *${usedPrefix}add${requestedType || 'msg'} [nama]* untuk menyimpan.`);
      return;
    }

    let msgList = `*📋 DAFTAR ${(requestedType || 'PESAN').toUpperCase()} TERSIMPAN*\n\n`;
    listMsg.forEach((msg, i) => {
      const msgType = msgs[msg].type || 'msg';
      const msgDate = msgs[msg].date ? `(${msgs[msg].date.split(' ')[0]})` : '';
      msgList += `${i + 1}. ${msg} - ${msgType} ${msgDate}\n`;
    });
    msgList += `\n*Perintah:*\n`;
    msgList += `• *${usedPrefix}get${requestedType || 'msg'} [nama]*\n`;
    msgList += `• *${usedPrefix}delmsg [nama]*\n`;
    msgList += `• *${usedPrefix}renamemsg [lama|baru]*\n`;
    msgList += `• *${usedPrefix}infomsg [nama]*`;

    m.reply(msgList);
  }
  else if (command === "searchmsg") {
    if (!text) {
      throw `Contoh: *${usedPrefix + command} pagi*\nCari pesan berdasarkan nama.`;
    }

    let msgs = db.data.msg;
    let listMsg = Object.keys(msgs).filter(key => 
      key.toLowerCase().includes(text.toLowerCase())
    );

    if (listMsg.length === 0) {
      m.reply(`Tidak ditemukan pesan dengan kata "${text}".\nGunakan *${usedPrefix}listmsg* untuk melihat semua.`);
      return;
    }

    let msgList = `*🔍 HASIL PENCARIAN: "${text}"*\n\n`;
    listMsg.forEach((msg, i) => {
      const msgType = msgs[msg].type || 'msg';
      msgList += `${i + 1}. ${msg} - ${msgType}\n`;
    });
    msgList += `\nGunakan *${usedPrefix}get[type] [nama]* untuk mengambil.`;

    m.reply(msgList);
  }
  else if (command === "clearmsg") {
    if (!m.isOwner) {
      throw `❌ Hanya owner bot yang bisa menghapus semua pesan.`;
    }

    const count = Object.keys(db.data.msg).length;
    db.data.msg = {};
    m.reply(`✅ Semua ${count} pesan berhasil dihapus.`);
  }
};

handler.help = [
  "addvn *[nama]* - Simpan voice note",
  "addmsg *[nama]* - Simpan pesan/chat",
  "addvideo *[nama]* - Simpan video",
  "addaudio *[nama]* - Simpan audio",
  "addimg *[nama]* - Simpan gambar",
  "addsticker *[nama]* - Simpan stiker",
  "addgif *[nama]* - Simpan gif",
  "getvn *[nama]* - Kirim voice note",
  "getmsg *[nama]* - Kirim pesan/chat",
  "getvideo *[nama]* - Kirim video",
  "getaudio *[nama]* - Kirim audio",
  "getimg *[nama]* - Kirim gambar",
  "getsticker *[nama]* - Kirim stiker",
  "getgif *[nama]* - Kirim gif",
  "delmsg *[nama]* - Hapus pesan",
  "deletemsg *[nama]* - Hapus pesan",
  "renamemsg *[lama|baru]* - Ganti nama pesan",
  "infomsg *[nama]* - Info detail pesan",
  "searchmsg *[kata]* - Cari pesan tersimpan",
  "listvn - Daftar voice note",
  "listmsg - Daftar semua pesan",
  "listvideo - Daftar video",
  "listaudio - Daftar audio",
  "listimg - Daftar gambar",
  "liststicker - Daftar stiker",
  "listgif - Daftar gif",
  "clearmsg - Hapus semua pesan (owner only)"
];
handler.tags = ["tools"];
handler.command = [
  "addvn", "addmsg", "addvideo", "addaudio", "addimg", "addsticker", "addgif",
  "getvn", "getmsg", "getvideo", "getaudio", "getimg", "getsticker", "getgif",
  "delmsg", "deletemsg", "renamemsg", "infomsg", "searchmsg",
  "listvn", "listmsg", "listvideo", "listaudio", "listimg", "liststicker", "listgif",
  "clearmsg"
];

module.exports = handler;