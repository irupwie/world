//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : tools/autosticker


let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    let chat = global.db.data.chats[m.chat];
    const arg = args[0]?.toLowerCase();
    const toggle = {
        on: true,
        off: false
    } [arg];
    const currentStatus = chat.autosticker ? "AKTIF" : "NONAKTIF";

    if (toggle === undefined) {
        return m.reply(
            `*[ STATUS AUTOSTICKER ]*\n` +
            `Saat ini autosticker: *${currentStatus}*\n\n` +
            `*[ CARA PAKAI ${command.toUpperCase()} ]*\n` +
            `• ${usedPrefix + command} on\n` +
            `• ${usedPrefix + command} off`
        );
    }

    if (chat.autosticker === toggle) {
        return m.reply(`*[ ✓ ] Autosticker sudah dalam keadaan *${toggle ? "AKTIF" : "NONAKTIF"}* sebelumnya.`);
    }

    chat.autosticker = toggle;
    return m.reply(`*[ ✓ ] Autosticker berhasil di${toggle ? "aktifkan" : "nonaktifkan"}!*`);
};

handler.help = ["autosticker [on/off]"];
handler.tags = ["tools"];
handler.command = ["autosticker"];
handler.private = true;
handler.limit = true;

module.exports = handler;