const axios = require('axios');

async function upscale(buffer) {
  try {
    let formData = new FormData();
    formData.append('image', new Blob([buffer], { type: 'image/png' }), 'image.png');
    let { data } = await axios.post('https://api.imggen.ai/guest-upload', formData, {
      headers: {
        "content-type": "multipart/form-data",
        origin: "https://imggen.ai",
        referer: "https://imggen.ai/",
        "user-agent": "Mozilla/5.0"
      }
    });
    let result = await axios.post('https://api.imggen.ai/guest-upscale-image', {
      image: {
        url: `https://api.imggen.ai${data.image.url}`,
        name: data.image.name,
        original_name: data.image.original_name,
        folder_name: data.image.folder_name,
        extname: data.image.extname
      }
    }, {
      headers: {
        "content-type": "application/json",
        origin: "https://imggen.ai",
        referer: "https://imggen.ai/",
        "user-agent": "Mozilla/5.0"
      }
    });
    return `https://api.imggen.ai${result.data.upscaled_image}`;
  } catch (err) {
    throw new Error('Gagal melakukan upscale gambar.');
  }
}

let handler = async (m, { conn }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    if (!mime.startsWith('image/')) {
      throw 'Silakan kirim gambar dengan caption *hd/remini* atau reply gambar!';
    }
    let media = await q.download();
    if (!media) throw 'Gagal mengunduh gambar.';
    let upscaledUrl = await upscale(media);
    if (!upscaledUrl) throw 'Gagal melakukan Upscale gambar.';
    await conn.sendMessage(m.chat, {
      image: { url: upscaledUrl },
      caption: `*Done*`
    }, { quoted: m });
    // Hapus semua referensi media dari memori
    media = null;
    upscaledUrl = null;
  } catch (error) {
    await conn.reply(m.chat, `❌ Error: ${error.message || error}`, m);
  }
};

handler.help = ['remini', 'hd'];
handler.tags = ['tools'];
handler.command = ["remini", "hd"];
handler.limit = true;

module.exports = handler;