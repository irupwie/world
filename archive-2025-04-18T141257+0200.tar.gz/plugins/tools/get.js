const undici = require("undici");
const { extension } = require("mime-types");
const { html } = require("js-beautify");

const MAX_SIZE = 30 * 1024 * 1024; // 30MB

function isUrl(string) {
    let urlRegex = /(https?:\/\/[^\s]+)/g;
    let result = string.match(urlRegex);
    return result;
}

module.exports = {
    help: ["get"].map(a => a + " *[url]*"),
    tags: ["downloader"],
    command: ["get"],
    code: async (m, {
        conn,
        usedPrefix,
        command,
        text
    }) => {
        if (!text) throw `*• Example :* ${usedPrefix + command} *[url]*`;
        m.reply(wait);

        for (let i of isUrl(text)) {
            let data = await undici.fetch(i);
            let mime = data.headers.get("content-type").split(";")[0];
            let cap = `乂 *F E T C H  -  U R L*
    ◦  Request : ${i}
    ◦  Mimetype : ${mime}`;

            let body;
            if (/html/ig.test(mime)) {
                body = await data.text();
            } else if (/json/ig.test(mime)) {
                body = await data.json();
            } else if (/image|video|audio/ig.test(mime)) {
                const buffer = Buffer.from(await data.arrayBuffer());
                if (buffer.length > MAX_SIZE) {
                    m.reply(`${cap}\n\n*• File size exceeds 30MB limit (${(buffer.length / (1024 * 1024)).toFixed(2)} MB)*`);
                    continue;
                }
                conn.sendFile(m.chat, buffer, `result.${extension(mime)}`, cap, m, { mimetype: mime });
                continue;
            } else {
                try {
                    const buffer = Buffer.from(await data.buffer());
                    if (buffer.length > MAX_SIZE) {
                        m.reply(`${cap}\n\n*• File size exceeds 30MB limit (${(buffer.length / (1024 * 1024)).toFixed(2)} MB)*`);
                        continue;
                    }
                    conn.sendFile(m.chat, buffer, `result.${extension(mime)}`, cap, m, { mimetype: mime });
                    continue;
                } catch (e) {
                    body = await data.text();
                }
            }

            // Send HTML/JSON/Text
            if (/html/ig.test(mime)) {
                const htmlBuffer = Buffer.from(html(body));
                if (htmlBuffer.length > MAX_SIZE) {
                    m.reply(`${cap}\n\n*• File size exceeds 30MB limit (${(htmlBuffer.length / (1024 * 1024)).toFixed(2)} MB)*`);
                    continue;
                }
                await conn.sendMessage(m.chat, {
                    document: htmlBuffer,
                    caption: cap,
                    fileName: "result.html",
                    mimetype: mime
                }, { quoted: m });
            } else if (/json/ig.test(mime)) {
                const jsonText = JSON.stringify(body, null, 2);
                if (Buffer.byteLength(jsonText) > MAX_SIZE) {
                    m.reply(`${cap}\n\n*• JSON size exceeds 30MB limit*`);
                    continue;
                }
                m.reply(`${cap}\n\n${jsonText}`);
            } else {
                if (typeof body === "string" && Buffer.byteLength(body) > MAX_SIZE) {
                    m.reply(`${cap}\n\n*• Text size exceeds 30MB limit*`);
                } else {
                    m.reply(`${cap}\n\n\`\`\`\n${body}\n\`\`\``);
                }
            }
        }
    }
}