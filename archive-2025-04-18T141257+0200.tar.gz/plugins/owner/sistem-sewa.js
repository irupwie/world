let handler = async (m, { conn, args, usedPrefix, command }) => {
    let who
    if (m.isGroup) who = m.chat
    
    const now = new Date() * 1
    
    switch (command) {
        case "addsewa":
        case "setsewa":
        case "addexpired":
        case "addexpi":
            if (!args[0] || isNaN(args[0])) throw `Masukkan angka mewakili jumlah hari !\n*Misal : ${usedPrefix + command} 30*`
            
            if (m.isGroup && args[1]) who = args[1]
            else if (!m.isGroup) who = args[1]
            
            var jumlahHari = 86400000 * args[0]
            
            if (now < global.db.data.chats[who].expired) global.db.data.chats[who].expired += jumlahHari
            else global.db.data.chats[who].expired = now + jumlahHari
            
            m.reply(`Berhasil menetapkan hari kadaluarsa untuk Grup ini selama ${args[0]} hari.\n\nHitung Mundur : ${msToDate(global.db.data.chats[who].expired - now)}`)
            break
            
        case "delsewa":
        case "deletesewa":
        case "deleteexpired":
        case "delexpired":
        case "hapussewa":
        case "hapusexpired":
            if (m.isGroup && args[0]) who = args[0]
            else if (!m.isGroup) who = args[0]
            
            if (now < global.db.data.chats[who].expired) global.db.data.chats[who].expired = false
            else global.db.data.chats[who].expired = false
            
            conn.reply(m.chat, `Berhasil menghapus hari kadaluarsa untuk Grup ini`, m)
            break
            
        case "listsewa":
        case "sewalist":
        case "listexpired":
        case "expiredlist":
            // Get all chats with active expiration
            let groups = Object.entries(global.db.data.chats)
                .filter(([id, chat]) => chat.expired && now < chat.expired)
                .map(async ([id, chat]) => {
                    let metadata
                    try {
                        metadata = await conn.groupMetadata(id)
                    } catch (e) {
                        metadata = { subject: 'Unknown Group' }
                    }
                    
                    // Convert to Jakarta time
                    const jakartaTime = new Date(chat.expired).toLocaleString('en-US', {
                        timeZone: 'Asia/Jakarta'
                    })
                    const jakartaDate = new Date(jakartaTime)
                    
                    return {
                        id,
                        name: metadata.subject,
                        expired: chat.expired,
                        remainingTime: msToDate(chat.expired - now),
                        jakartaDate: jakartaDate
                    }
                })
            
            // Wait for all metadata to be fetched
            groups = await Promise.all(groups)
            
            if (groups.length === 0) {
                return m.reply('Tidak ada grup dengan masa aktif saat ini')
            }
            
            // Create list message
            let text = `*DAFTAR GRUP DENGAN MASA AKTIF*\n\n`
            groups.forEach((group, i) => {
                text += `*${i + 1}.* ${group.name}\n`
                text += `   ID: ${group.id}\n`
                text += `   Expired: ${formatDate(group.jakartaDate)} ${formatTime(group.jakartaDate)} WIB\n`
                text += `   Sisa Waktu: ${group.remainingTime}\n\n`
            })
            
            m.reply(text)
            break
    }
}

// Function to check expired groups and leave them
const checkExpired = async (conn) => {
    let groups = Object.entries(global.db.data.chats)
    let now = new Date() * 1
    
    for (let [id, chat] of groups) {
        if (chat.expired && now >= chat.expired) {
            // Send farewell message before leaving
            await conn.reply(id, `Masa aktif bot di grup ini telah habis. Bot akan keluar dari grup.\n\nTerima kasih telah menggunakan layanan kami. Untuk perpanjangan silahkan hubungi owner.`, null)
            
            // Wait a moment to ensure message is sent
            await new Promise(resolve => setTimeout(resolve, 1000))
            
            // Leave the group
            await conn.groupLeave(id)
            
            // Reset the expired status
            chat.expired = false
            
            console.log(`Bot left group ${id} due to expiration`)
        }
    }
}

// Format time as "09.29" (hours and minutes with leading zeros)
function formatTime(date) {
    const hours = String(date.getHours()).padStart(2, '0')
    const minutes = String(date.getMinutes()).padStart(2, '0')
    return `${hours}.${minutes}`
}

// Format date as "DD/MM/YYYY"
function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0')
    const month = String(date.getMonth() + 1).padStart(2, '0') // Month is 0-indexed
    const year = date.getFullYear()
    return `${day}/${month}/${year}`
}

handler.help = ['addsewa [day]', 'delesewa', 'listsewa']
handler.tags = ['owner']
handler.command = [
    "addsewa", "setsewa", "addexpired", "addexpi",
    "delsewa", "deletesewa", "deleteexpired", "delexpired", "hapussewa", "hapusexpired",
    "listsewa", "sewalist", "listexpired", "expiredlist"
]

// Use the strictest permission level (rowner) since one of the original handlers had it
handler.rowner = true

// Export the checkExpired function to be used elsewhere
handler.checkExpired = checkExpired

module.exports = handler

function msToDate(ms) {
    let temp = ms
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    let minutesms = ms % (60 * 1000);
    let sec = Math.floor((minutesms) / (1000));
    return days + " hari " + hours + " jam " + minutes + " menit";
}