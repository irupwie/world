module.exports = {
    help: ["bcgc", "bc", "broadcast", "broadcastgroup"].map(a => a + " *[input text]*"),
    tags: ["owner"],
    command: ["bcgc", "bc", "broadcast", "broadcastgroup"],
    code: async (m, {
        conn,
        usedPrefix,
        command,
        text,
        isOwner
    }) => {
        // Check if user is owner
        if (!isOwner) return m.reply('This command can only be used by owner');

        // Check if text is provided
        if (!text && !m.quoted) {
            return m.reply(`*• Example :* ${usedPrefix + command} [input text]`);
        }

        // Get message content
        const quotedMsg = m.quoted ? await m.getQuotedObj() : null;
        const content = text || (quotedMsg ? quotedMsg.text : '');

        // If no content available, show error
        if (!content && !m.quoted?.mimetype) {
            return m.reply(`Please provide text or quote a message to broadcast`);
        }

        // Filter groups or all chats based on command
        const isGroupBroadcast = /bcgc|broadcastgroup/i.test(command);
        const targetType = isGroupBroadcast ? 'Group' : 'Users';
        const chats = Object.keys(conn.chats).filter(id =>
            isGroupBroadcast ? id.endsWith('@g.us') : true
        );

        // If no targets found
        if (chats.length === 0) {
            return m.reply(`No ${targetType.toLowerCase()} found to broadcast to`);
        }

        // Show initial processing message using the proper format
        let key = await conn.sendMessage(
            m.chat, {
                text: `*[ BROADCAST PREPARING... ]*\n• Target: ${chats.length} ${targetType}`
            }, {
                quoted: m
            }
        );

        // Track progress
        let successCount = 0;
        let failCount = 0;
        const failedTargets = [];

        // Process broadcast with periodic status updates
        for (let i = 0; i < chats.length; i++) {
            const id = chats[i];
            const progress = Math.floor((i / chats.length) * 100);

            // Update progress every 10% or every 10 messages for smaller broadcasts
            if (i > 0 && (i % Math.max(1, Math.ceil(chats.length / 10)) === 0)) {
                await conn.sendMessage(
                    m.chat, {
                        text: `*[ BROADCAST PROGRESS: ${progress}% ]*\n• Processed: ${i}/${chats.length}\n• Success: ${successCount}\n• Failed: ${failCount}`,
                        edit: key.key
                    }, {
                        quoted: m
                    }
                );
            }

            try {
                // Prepare message to forward
                const msgToSend = m.quoted?.mimetype ?
                    quotedMsg.fakeObj :
                    conn.cMod(m.chat, quotedMsg || m, content);

                // Send message with timeout of 3 seconds max per message
                await Promise.race([
                    conn.copyNForward(id, msgToSend),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 3000))
                ]);

                successCount++;

                // Small delay to prevent flooding
                await new Promise(resolve => setTimeout(resolve, 100));
            } catch (error) {
                failCount++;
                failedTargets.push(id.split('@')[0]);
            }
        }

        // Create final message with results
        const resultMsg = `*[ BROADCAST COMPLETED ]*\n• Success: ${successCount} ${targetType}\n• Failed: ${failCount} ${targetType}\n• Total: ${chats.length} ${targetType}`;

        // Add failed targets info if any
        const finalMsg = failedTargets.length > 0 ?
            `${resultMsg}\n\n*Failed to send to:* ${failedTargets.slice(0, 5).join(', ')}${failedTargets.length > 5 ? ` +${failedTargets.length - 5} more` : ''}` :
            resultMsg;

        // Send final message using edit
        await conn.sendMessage(
            m.chat, {
                text: finalMsg,
                edit: key.key
            }, {
                quoted: m
            }
        );
    },
    owner: true
}