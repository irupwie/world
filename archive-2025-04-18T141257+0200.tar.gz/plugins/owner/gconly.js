let handler = async (m, { conn, args, isOwner }) => {
  if (!isOwner) return m.reply('Fitur ini hanya dapat digunakan oleh owner bot.')
  
  if (args[0] === 'on') {
    if (global.db.data.settings.grouponly) return m.reply('Mode grouponly sudah aktif')
    global.db.data.settings.grouponly = true
    m.reply('✅ Mode grouponly diaktifkan\nBot hanya dapat digunakan di dalam grup')
  } else if (args[0] === 'off') {
    if (!global.db.data.settings.grouponly) return m.reply('Mode grouponly sudah dinonaktifkan')
    global.db.data.settings.grouponly = false
    m.reply('❌ Mode grouponly dinonaktifkan\nBot dapat digunakan di chat pribadi')
  } else {
    const status = global.db.data.settings.grouponly ? 'aktif' : 'tidak aktif'
    m.reply(`Mode grouponly saat ini: ${status}\n\nPenggunaan: .grouponly on/off`)
  }
}

handler.help = ['grouponly [on/off]']
handler.tags = ['owner']
handler.command = ["grouponyl", "gconly"]
handler.rowner = true

module.exports = handler