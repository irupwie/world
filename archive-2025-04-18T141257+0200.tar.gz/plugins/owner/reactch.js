let handler = async (m, { text, args }) => {
    if (!text) {
        return m.reply('⚠ Gunakan format:\n*reactchannel <id_channel> <id_pesan> <emoji>*\natau\n*reactchannel <link_pesan> <emoji>*\n\n_Contoh:_\n*reactchannel 999733883@newsletter 3505 🤭*\n*reactchannel https://whatsapp.com/channel/0029VaDxxxxx/28 🤭*');
    }

    let id_channel, id_pesan, emoji;

    // Deteksi jika input berupa link pesan
    if (text.includes('whatsapp.com/channel/')) {
        let match = text.match(/channel\/([^\/]+)\/(\d+)\s+(.+)/);
        if (!match) {
            return m.reply('❌ Format link tidak valid. Pastikan link diikuti emoji. Contoh:\n*https://whatsapp.com/channel/ID/1234 🤭*');
        }

        id_channel = match[1] + '@newsletter';
        id_pesan = match[2];
        emoji = match[3];
    } else {
        if (args.length < 3) {
            return m.reply('⚠ Gunakan format: *reactchannel <id_channel> <id_pesan> <emoji>*\n\n_Contoh:_\n*reactchannel 999733883@newsletter 3505 🤭*');
        }

        id_channel = args[0];
        id_pesan = args[1];
        emoji = args.slice(2).join(' ');
    }

    try {
        await conn.newsletterReactMessage(id_channel, id_pesan, emoji);
        m.reply(`✅ *Berhasil menambahkan reaksi!*\n\n📌 *ID Channel:* ${id_channel}\n🆔 *ID Pesan:* ${id_pesan}\n😆 *Emoji:* ${emoji}`);
    } catch (err) {
        console.error(err);
        m.reply('❌ Gagal menambahkan reaksi ke pesan channel. Pastikan ID channel, ID pesan, dan emoji benar.');
    }
}

handler.help = ['reactchannel']
handler.tags = ['owner']
handler.command = ["reactchannel", "reactch"]
handler.owner = true

module.exports = handler