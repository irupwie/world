const fetch = require("node-fetch");
const FormData = require("form-data");
const fileType = require("file-type");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const data = db.data.sticker;

  switch (command) {
    case "setcmd":
      if (!m.quoted)
        throw `*[ Cara Penggunaan Fitur SetCmd ]*\n\n` +
              `• Fitur ini digunakan untuk menautkan perintah tertentu pada stiker yang dikirim.\n\n` +
              `*Langkah:*\n` +
              `1. Balas stiker yang ingin kamu tambahkan perintah.\n` +
              `2. Gunakan perintah: *${usedPrefix + command} namaPerintah*\n\n` +
              `*Contoh:* Balas stiker dengan ketik:\n` +
              `*${usedPrefix + command} halo*\n` +
              `Setelah itu, ketika stiker tersebut dikirim lagi, bot akan merespon dengan "halo".`;

      if (!text)
        throw `*[ Cara Penggunaan Fitur SetCmd ]*\n\n` +
              `• Kamu lupa menuliskan nama perintah.\n\n` +
              `*Contoh Benar:*\n` +
              `*${usedPrefix + command} halo*\n\n` +
              `Balas stiker dengan perintah di atas untuk menyimpan "halo" sebagai respon.`;

      var { key } = await conn.sendMessage(m.chat, { text: "⏳ Sedang memproses..." }, { quoted: m });
      try {
        let hash = m.quoted.fileSha256.toString("base64");
        const media = await m.quoted.download();
        const url = await uploadcatbox(media);
        data[hash] = {
          message: text,
          creator: m.name,
          jid: m.sender,
          url,
        };
        await conn.sendMessage(
          m.chat,
          { text: "*[ SUKSES MENAMBAHKAN PERINTAH KE STIKER ]*", edit: key },
          { quoted: m },
        );
      } catch (e) {
        throw e;
      }
      break;

    case "delcmd":
      if (!m.quoted)
        throw `*[ Cara Penggunaan Fitur DelCmd ]*\n\n` +
              `• Balas stiker yang sudah memiliki perintah untuk menghapusnya.\n\n` +
              `*Contoh:* Balas stiker lalu ketik:\n` +
              `*${usedPrefix + command}*`;

      let hashDel = await m.quoted.fileSha256.toString("base64");

      if (Object.keys(data).includes(hashDel)) {
        delete data[hashDel];
        m.reply("*[ SUKSES MENGHAPUS PERINTAH DARI STIKER ]*");
      } else {
        m.reply("*[ STIKER INI TIDAK MEMILIKI PERINTAH YANG TERDAFTAR ]*");
      }
      break;

    case "listcmd":
      let result = "";
      let index = 1;
      for (const key in data) {
        result += `*${index}. ${data[key].message}*\n`;
        result += `• Creator : ${data[key].creator}\n`;
        result += `• Jid : wa.me/${data[key].jid.split("@")[0]}\n`;
        result += `• Sticker : ${data[key].url}\n\n`;
        index++;
      }
      m.reply(result || "*[ TIDAK ADA PERINTAH STIKER YANG DITEMUKAN ]*");
      break;
  }
};

handler.help = ["setcmd", "delcmd", "listcmd"].map(v => v + " *[premium only]*");
handler.tags = ["owner"];
handler.command = ["setcmd", "delcmd", "listcmd"];
handler.owner = true;

module.exports = handler;

async function uploadcatbox(buffer) {
  const { ext } = await fileType.fromBuffer(buffer);
  const bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");

  const res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });

  if (!res.ok) throw new Error('Error uploading file: ' + res.statusText);

  const data = await res.text();
  return data;
}