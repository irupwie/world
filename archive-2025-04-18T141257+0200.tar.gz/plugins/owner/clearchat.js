let handler = async (m, { conn }) => {
  // Dapatkan informasi waktu
  const time = new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' });

  // Simpan informasi penghapus
  const who = m.sender;
  const chatId = m.chat;

  // Modifikasi chat (hapus pesan)
  await conn.chatModify({
    delete: true,
    lastMessages: [{
      key: m.key,
      messageTimestamp: m.messageTimestamp
    }]
  }, chatId);

  // Kirim pesan balasan dengan detail
  await m.reply(
    `*Chat berhasil dihapus!*\n\n` +
    `• *Oleh:* @${who.split('@')[0]}\n` +
    `• *Waktu:* ${time}\n` +
    `• *Chat ID:* ${chatId}`
  );
}

handler.help = ['deletechat'];
handler.tags = ['owner'];
handler.command = ["deletechat", "delchat", "clearchat"];
handler.owner = true;

module.exports = handler;