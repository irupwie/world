let handler = async function(m, {
    conn,
    text,
    args,
    usedPrefix,
    command
}) {
    // Fitur listprem: Menampilkan daftar user yang premium
    if (command === "listprem") {
        let users = Object.entries(global.db.data.users)
            .filter(([_, user]) => user.premium)
            .map(([jid, user]) => {
                let expired = user.premiumDate === "PERMANENT" ?
                    "PERMANENT" :
                    formatExpiredDate(user.premiumDate);
                return `• @${jid.split("@")[0]} - ${expired}`;
            });

        if (users.length === 0) throw "*[ NO PREMIUM USERS FOUND ]*";

        await conn.sendMessage(m.chat, {
            text: `*[ PREMIUM USERS LIST ]*\n\n${users.join("\n")}`,
            mentions: users.map(v => v.match(/@(\d+)/)[1] + "@s.whatsapp.net")
        }, {
            quoted: m
        });

        return;
    }

    // Fitur addprem: Menambahkan premium ke user dengan format durasi opsional
    if (command === "addprem") {
        let number = args[0]?.replace(/\D/g, "");
        let durationRaw = args[1] || "";

        // Jika menggunakan mention
        if (!number && m.mentionedJid && m.mentionedJid.length > 0) {
            number = m.mentionedJid[0].split("@")[0];
            durationRaw = args[1] || args[0] || "";
        }

        if (!number) throw `*[ INVALID FORMAT ]*

Silakan gunakan salah satu format berikut:

• ${usedPrefix + command} 628xxx
  → Memberikan premium PERMANENT ke user tersebut

• ${usedPrefix + command} 628xxx 3d
  → Memberikan premium selama 3 hari

• ${usedPrefix + command} @tag
  → Memberikan premium PERMANENT ke user yang ditag

• ${usedPrefix + command} @tag 1mo5d
  → Memberikan premium selama 1 bulan 5 hari ke user yang ditag

*Unit waktu yang tersedia:*
• s  = detik (second)
• m  = menit (minute)
• h  = jam (hour)
• d  = hari (day)
• mo = bulan (month)
• ye = tahun (year)

*Contoh penggunaan kombinasi:*
• 1h30m = 1 jam 30 menit
• 1mo2d12h = 1 bulan 2 hari 12 jam`;

        let jid = number + "@s.whatsapp.net";
        
        // Pastikan ada database dan user
        if (!global.db.data.users) global.db.data.users = {};
        if (!global.db.data.users[jid]) global.db.data.users[jid] = {};
        
        let user = global.db.data.users[jid];

        // Memeriksa user
        if (!user) throw "*[ USER NOT FOUND IN DATABASE ]*";
        if (user.registered === false) throw "*[ USER NOT REGISTERED ]*";
        if (user.banned) throw "*[ USER HAS BEEN BANNED ]*";

        let {
            key
        } = await conn.sendMessage(m.chat, {
            text: "*[ VERIFYING USER DATA... ]*"
        }, {
            quoted: m
        });

        try {
            // Jika terdapat input durasi, maka hitung waktu expire premium
            if (durationRaw) {
                let ms = parseDuration(durationRaw);
                if (!ms || isNaN(ms)) throw "*[ INVALID DURATION FORMAT ]*\nContoh: `1d`, `2h30m`, `1mo5d`";

                user.premium = true;
                user.premiumDate = Date.now() + ms;
                
                // Format tanggal expire dengan hari dan jam WIB
                let expiredFormatted = formatExpiredDate(user.premiumDate);

                await conn.sendMessage(m.chat, {
                    text: `*[ ✅ PREMIUM ADDED ]*
*• Username:* ${user.name || number}
*• Age:* ${user.age || 'N/A'}
*• Premium:* ✅
*• Expired:* ${expiredFormatted}`,
                    edit: key
                }, {
                    quoted: m
                });

                // Kirim pesan konfirmasi ke user yang ditambahkan premium
                try {
                    await conn.sendMessage(jid, {
                        text: `*[ THANK YOU FOR YOUR ORDER ]*
*• Username:* ${user.name || number}
*• Age:* ${user.age || 'N/A'}
*• Premium:* ✅
*• Expired:* ${expiredFormatted}

*✅ Enjoy exclusive premium features on ${global.namebot || 'Bot'} with unlimited access!*`
                    });
                } catch (err) {
                    console.log("Failed to send confirmation to user:", err);
                }
            } else {
                // Jika tidak ada input durasi, maka premium bersifat PERMANENT
                user.premium = true;
                user.premiumDate = "PERMANENT";

                await conn.sendMessage(m.chat, {
                    text: `*[ ✅ PREMIUM ADDED ]*
*• Username:* ${user.name || number}
*• Age:* ${user.age || 'N/A'}
*• Premium:* ✅
*• Expired:* PERMANENT`,
                    edit: key
                }, {
                    quoted: m
                });

                // Kirim pesan konfirmasi ke user yang ditambahkan premium
                try {
                    await conn.sendMessage(jid, {
                        text: `*[ THANK YOU FOR YOUR ORDER ]*
*• Username:* ${user.name || number}
*• Age:* ${user.age || 'N/A'}
*• Premium:* ✅
*• Expired:* PERMANENT

*✅ Enjoy exclusive premium features on ${global.namebot || 'Bot'} with unlimited access!*`
                    });
                } catch (err) {
                    console.log("Failed to send confirmation to user:", err);
                }
            }
        } catch (error) {
            console.error("Error in addprem:", error);
            await conn.sendMessage(m.chat, {
                text: `*[ ERROR ]*\n${error.toString()}`,
                edit: key
            }, {
                quoted: m
            });
        }
    }
    // Fitur delprem/unprem: Menghapus status premium user
    else if (command === "delprem" || command === "unprem") {
        let number = args[0]?.replace(/\D/g, "");
        if (!number && m.mentionedJid && m.mentionedJid.length > 0) {
            number = m.mentionedJid[0].split("@")[0];
        }
        if (!number) throw `*[ INVALID FORMAT ]*\n\nSilakan gunakan:\n• ${usedPrefix + command} 628xxx\n• ${usedPrefix + command} @tag`;

        let jid = number + "@s.whatsapp.net";
        
        // Pastikan database dan user ada
        if (!global.db.data.users) global.db.data.users = {};
        if (!global.db.data.users[jid]) global.db.data.users[jid] = {};
        
        let user = global.db.data.users[jid];

        if (!user) throw "*[ USER NOT FOUND IN DATABASE ]*";
        if (!user.premium) throw "*[ USER IS NOT PREMIUM ]*";

        user.premium = false;
        user.premiumDate = 0;

        await conn.sendMessage(m.chat, {
            text: `*[ ✅ PREMIUM REMOVED ]*
*• Username:* ${user.name || number}
*• Premium:* ❎`,
        }, {
            quoted: m
        });

        try {
            // Kirim notifikasi ke user yang premium-nya dicabut
            await conn.sendMessage(jid, {
                text: `*[ PREMIUM REVOKED ]*
*• Username:* ${user.name || number}
*• Premium:* ❎

*Your premium access on ${global.namebot || 'Bot'} has been revoked. Please reorder if you wish to regain access.*`
            });
        } catch (err) {
            console.log("Failed to send notification to user:", err);
        }
    }
};

handler.help = ["addprem", "delprem", "unprem", "listprem"].map(cmd => `${cmd} [number|@tag] [duration]`);
handler.tags = ["owner"];
handler.command = ["addprem", "delprem", "unprem", "listprem"];
handler.owner = true;

module.exports = handler;

// Fungsi helper untuk menghapus karakter tidak perlu dari nomor
function no(number) {
    return number.replace(/\s/g, "").replace(/([@+-])/g, "");
}

// Fungsi parseDuration untuk mengonversi string waktu ke milidetik
function parseDuration(str) {
    let time = 0;
    let regex = /(\d+)(s|m|h|d|mo|ye)/g;
    let match;
    while ((match = regex.exec(str)) !== null) {
        let val = parseInt(match[1]);
        let unit = match[2];
        switch (unit) {
            case 's':
                time += val * 1000;
                break;
            case 'm':
                time += val * 60 * 1000;
                break;
            case 'h':
                time += val * 60 * 60 * 1000;
                break;
            case 'd':
                time += val * 24 * 60 * 60 * 1000;
                break;
            case 'mo':
                time += val * 30 * 24 * 60 * 60 * 1000;
                break;
            case 'ye':
                time += val * 365 * 24 * 60 * 60 * 1000;
                break;
        }
    }
    return time;
}

// Fungsi baru untuk memformat tanggal expire dengan hari dan jam WIB
function formatExpiredDate(timestamp) {
    if (timestamp === "PERMANENT") return "PERMANENT";
    
    // Daftar nama hari dalam Bahasa Indonesia
    const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    
    // Konversi timestamp ke objek Date
    const date = new Date(timestamp);
    
    // Mendapatkan nama hari
    const dayName = days[date.getDay()];
    
    // Format tanggal DD-MM-YYYY
    const dateStr = `${String(date.getDate()).padStart(2, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${date.getFullYear()}`;
    
    // Format waktu HH:MM:SS WIB (UTC+7)
    // Tambahkan 7 jam untuk WIB
    date.setHours(date.getHours() + 7);
    const timeStr = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')} WIB`;
    
    // Gabungkan semua format
    return `${dayName}, ${dateStr} ${timeStr}`;
}