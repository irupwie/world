const fs = require("fs");
const path = require("path");

module.exports = {
    help: ["searchplugin", "findplugin", "cariplugin"].map((a) => a + " *[filter:query]*"),
    tags: ["owner"],
    command: ["searchplugin", "findplugin", "cariplugin"],
    code: async (m, {
        conn,
        usedPrefix,
        command,
        text,
        isOwner,
        isAdmin,
        isBotAdmin,
        isPrems,
        chatUpdate,
    }) => {
        if (!text) 
            throw `*• Example :* ${usedPrefix + command} *[filter:query]*

*Available filters:*
- ${usedPrefix + command} text:query - Search in all text (default)
- ${usedPrefix + command} file:name - Search in filenames only
- ${usedPrefix + command} cmd:command - Search for specific commands
- ${usedPrefix + command} tag:tagname - Search by tag
- ${usedPrefix + command} owner:true/false - Filter by owner-only plugins
- ${usedPrefix + command} premium:true/false - Filter by premium-only plugins
- ${usedPrefix + command} admin:true/false - Filter by admin-only plugins
- ${usedPrefix + command} group:true/false - Filter by group-only plugins

*Combine filters with AND:*
- ${usedPrefix + command} cmd:sticker tag:media
- ${usedPrefix + command} file:menu owner:true

*Examples:*
${usedPrefix + command} sticker
${usedPrefix + command} cmd:menu
${usedPrefix + command} tag:tools owner:false`;
        
        m.reply(wait);
        
        // Parse filters and queries
        const filters = parseFilters(text);
        const pluginsDir = process.cwd() + "/plugins/";
        let ListPlugins = Object.keys(plugins).map((a) => a.split("/plugins/")[1]);
        
        // Results containers
        let matches = [];
        let evalErrors = [];
        
        // Process each plugin
        for (let i = 0; i < ListPlugins.length; i++) {
            const filename = ListPlugins[i];
            const filePath = path.join(pluginsDir, filename);
            
            try {
                if (!fs.existsSync(filePath)) continue;
                
                // Read file content
                const content = fs.readFileSync(filePath, 'utf8');
                
                // Try to evaluate the plugin module to extract metadata
                let pluginModule;
                try {
                    // Use a safer alternative to direct eval
                    pluginModule = safeRequire(filePath);
                } catch (evalError) {
                    evalErrors.push({ filename, error: evalError.message });
                    // If we can't evaluate, we'll just search in raw content
                    pluginModule = null;
                }
                
                // Check if plugin matches all filters
                if (matchesAllFilters(filename, content, pluginModule, filters)) {
                    matches.push({
                        index: i + 1,
                        filename: filename,
                        plugin: pluginModule
                    });
                }
            } catch (error) {
                // Skip files that can't be read
                continue;
            }
        }
        
        // Prepare results message
        let resultMessage = `*🔍 Search Results*\n`;
        resultMessage += `*Query:* ${text}\n`;
        resultMessage += `*Found:* ${matches.length} plugin(s)\n`;
        
        if (matches.length === 0) {
            resultMessage += "\n📭 No plugins found matching your filters.";
        } else {
            resultMessage += "\n📋 *Matching Plugins:*\n";
            
            // Sort matches alphabetically by filename
            matches.sort((a, b) => a.filename.localeCompare(b.filename));
            
            // Display matches with their details
            matches.forEach((match, idx) => {
                resultMessage += `*${idx + 1}.* ${match.filename}`;
                
                // Add extra info if plugin metadata is available
                if (match.plugin) {
                    if (match.plugin.command) {
                        let commands = Array.isArray(match.plugin.command) 
                            ? match.plugin.command.join(", ") 
                            : match.plugin.command;
                        resultMessage += `\n   └ Commands: ${commands}`;
                    }
                    
                    if (match.plugin.tags) {
                        let tags = Array.isArray(match.plugin.tags) 
                            ? match.plugin.tags.join(", ") 
                            : match.plugin.tags;
                        resultMessage += `\n   └ Tags: ${tags}`;
                    }
                    
                    // Show permission flags
                    let flags = [];
                    if (match.plugin.owner) flags.push("Owner");
                    if (match.plugin.premium) flags.push("Premium");
                    if (match.plugin.group) flags.push("Group");
                    if (match.plugin.admin) flags.push("Admin");
                    if (flags.length > 0) {
                        resultMessage += `\n   └ Requires: ${flags.join(", ")}`;
                    }
                }
                
                resultMessage += `\n   └ Get: ${usedPrefix}gp ${match.index} or ${usedPrefix}gp ${match.filename}\n`;
            });
            
            // Add pagination if too many results
            if (matches.length > 20) {
                resultMessage = `*🔍 Search Results*\n`;
                resultMessage += `*Query:* ${text}\n`;
                resultMessage += `*Found:* ${matches.length} plugin(s)\n`;
                resultMessage += "\n📋 *Top 20 Matching Plugins:*\n";
                
                // Only show first 20 results
                for (let idx = 0; idx < 20; idx++) {
                    const match = matches[idx];
                    resultMessage += `*${idx + 1}.* ${match.filename} - ${usedPrefix}gp ${match.index}\n`;
                }
                
                resultMessage += `\n*...and ${matches.length - 20} more results.*`;
                resultMessage += `\n\n💡 *Tip:* Refine your search with filters for more specific results.`;
            }
        }
        
        m.reply(resultMessage);
        
        // Report any evaluation errors separately for debugging
        if (evalErrors.length > 0 && isOwner) {
            let errorMsg = `*⚠️ Plugin Evaluation Errors (${evalErrors.length}):*\n`;
            errorMsg += evalErrors.slice(0, 5).map(e => `- ${e.filename}: ${e.error}`).join("\n");
            if (evalErrors.length > 5) {
                errorMsg += `\n...and ${evalErrors.length - 5} more errors.`;
            }
            setTimeout(() => m.reply(errorMsg), 1000);
        }
    },
    owner: true
};

// Helper function to safely evaluate plugin module
function safeRequire(filePath) {
    try {
        // This is a simplified approach - in a real implementation,
        // you might want a more sophisticated sandboxed evaluation
        delete require.cache[require.resolve(filePath)];
        return require(filePath);
    } catch (e) {
        throw e;
    }
}

// Parse input to extract filters and queries
function parseFilters(text) {
    const filters = {
        text: [],
        file: [],
        cmd: [],
        tag: [],
        owner: null,
        premium: null,
        admin: null,
        group: null
    };
    
    // Split by spaces, but respect quoted segments
    const parts = text.match(/(?:[^\s"]+|"[^"]*")+/g) || [text];
    
    for (const part of parts) {
        const colonIndex = part.indexOf(':');
        
        if (colonIndex !== -1) {
            let [filterType, filterValue] = [
                part.slice(0, colonIndex).toLowerCase(),
                part.slice(colonIndex + 1)
            ];
            
            // Remove quotes if present
            if (filterValue.startsWith('"') && filterValue.endsWith('"')) {
                filterValue = filterValue.slice(1, -1);
            }
            
            // Handle boolean filters
            if (['owner', 'premium', 'admin', 'group'].includes(filterType)) {
                if (['true', 'yes', '1'].includes(filterValue.toLowerCase())) {
                    filters[filterType] = true;
                } else if (['false', 'no', '0'].includes(filterValue.toLowerCase())) {
                    filters[filterType] = false;
                }
                continue;
            }
            
            // Handle array filters
            if (filterType in filters) {
                filters[filterType].push(filterValue.toLowerCase());
            } else {
                // Unrecognized filter becomes a text search
                filters.text.push(part.toLowerCase());
            }
        } else {
            // No colon means it's a general text search
            filters.text.push(part.toLowerCase());
        }
    }
    
    return filters;
}

// Check if plugin matches all specified filters
function matchesAllFilters(filename, content, pluginModule, filters) {
    // If no filters specified, match everything
    if (Object.values(filters).every(f => 
        f === null || (Array.isArray(f) && f.length === 0))) {
        return true;
    }
    
    // File name filter
    if (filters.file.length > 0 && 
        !filters.file.some(query => filename.toLowerCase().includes(query))) {
        return false;
    }
    
    // Command filter
    if (filters.cmd.length > 0) {
        if (!pluginModule || !pluginModule.command) return false;
        
        const commands = Array.isArray(pluginModule.command) 
            ? pluginModule.command 
            : [pluginModule.command];
            
        if (!filters.cmd.some(query => 
            commands.some(cmd => 
                (typeof cmd === 'string' && cmd.toLowerCase().includes(query))
            )
        )) {
            return false;
        }
    }
    
    // Tag filter
    if (filters.tag.length > 0) {
        if (!pluginModule || !pluginModule.tags) return false;
        
        const tags = Array.isArray(pluginModule.tags) 
            ? pluginModule.tags 
            : [pluginModule.tags];
            
        if (!filters.tag.some(query => 
            tags.some(tag => 
                (typeof tag === 'string' && tag.toLowerCase().includes(query))
            )
        )) {
            return false;
        }
    }
    
    // Permission filters
    if (filters.owner !== null) {
        if (!pluginModule || Boolean(pluginModule.owner) !== filters.owner) {
            return false;
        }
    }
    
    if (filters.premium !== null) {
        if (!pluginModule || Boolean(pluginModule.premium) !== filters.premium) {
            return false;
        }
    }
    
    if (filters.admin !== null) {
        if (!pluginModule || Boolean(pluginModule.admin) !== filters.admin) {
            return false;
        }
    }
    
    if (filters.group !== null) {
        if (!pluginModule || Boolean(pluginModule.group) !== filters.group) {
            return false;
        }
    }
    
    // General text search (if no specific text filters provided, skip this check)
    if (filters.text.length > 0) {
        const lowerContent = content.toLowerCase();
        if (!filters.text.every(query => lowerContent.includes(query))) {
            return false;
        }
    }
    
    // If passed all filters
    return true;
}