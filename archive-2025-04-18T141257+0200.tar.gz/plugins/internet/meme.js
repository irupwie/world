const config = {
  defaultQuery: "meme",
  maxPages: 10,
  messageTemplate: "*====[ MEME FROM LAHELU ]====*\n*Title:* {title}\n*Total Upvotes:* {totalUpvotes}\n*Total Downvotes:* {totalDownvotes}\n*Total Comments:* {totalComments}\n*Create Time:* {createTime}\n*Media:* {media}\n*Sensitive:* {sensitive}\n*User Username:* {userUsername}\n*====[ MEME FROM LAHELU ]====*",
  waitMessage: "⏳ Tunggu sebentar, sedang mengambil meme...",
  errorMessage: "❌ Terjadi kesalahan saat mengambil data",
  dateFormat: { 
    dateStyle: 'medium', 
    timeStyle: 'short' 
  },
  // Filters
  minUpvotes: 0,
  includeSensitive: true,
  // API
  apiUrl: "https://lahelu.com/api/post/get-search"
};

/**
 * Format date according to locale and options
 * @param {string|number|Date} date - Date to format
 * @returns {string} Formatted date string
 */
const formatDate = (date) => {
  try {
    return new Date(date).toLocaleString('id-ID', config.dateFormat);
  } catch (error) {
    return new Date(date).toLocaleString();
  }
};

/**
 * Format message using template and data
 * @param {Object} data - Data to insert into template
 * @returns {string} Formatted message
 */
const formatMessage = (data) => {
  let message = config.messageTemplate;
  
  // Replace placeholders with actual data
  Object.keys(data).forEach(key => {
    const value = key === 'createTime' 
      ? formatDate(data[key])
      : key === 'sensitive' 
        ? (data[key] ? "✅" : "❌") 
        : data[key];
    
    message = message.replace(new RegExp(`{${key}}`, 'g'), value);
  });
  
  return message;
};

/**
 * Filter memes based on configured criteria
 * @param {Array} memes - Array of meme objects
 * @returns {Array} Filtered memes
 */
const filterMemes = (memes) => {
  return memes.filter(meme => {
    // Filter by minimum upvotes
    if (meme.totalUpvotes < config.minUpvotes) return false;
    
    // Filter sensitive content if configured
    if (!config.includeSensitive && meme.sensitive) return false;
    
    return true;
  });
};

const handler = async (m, { conn, text, args, usedPrefix, command }) => {
  // Allow custom query and page via arguments
  const query = text || config.defaultQuery;
  const page = args[1] ? parseInt(args[1]) : Math.floor(Math.random() * config.maxPages);
  
  const url = `${config.apiUrl}?query=${encodeURIComponent(query)}&page=${page}`;
  
  m.reply(config.waitMessage);
  
  try {
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.postInfos || data.postInfos.length === 0) {
      return conn.reply(m.chat, `❌ Tidak ditemukan meme dengan query "${query}"`, m);
    }
    
    // Filter memes based on criteria
    const filteredMemes = filterMemes(data.postInfos);
    
    if (filteredMemes.length === 0) {
      return conn.reply(m.chat, `❌ Tidak ada meme yang sesuai dengan filter yang ditetapkan`, m);
    }
    
    // Get random meme from filtered results
    const random = Math.floor(Math.random() * filteredMemes.length);
    const result = filteredMemes[random];
    
    // Format message using template
    const message = formatMessage(result);
    
    // Send the meme
    await conn.sendFile(
      m.chat,
      result.media,
      `lahelu-${result.id}.jpg`,
      message,
      m
    );
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    conn.reply(m.chat, config.errorMessage, m);
  }
};

handler.help = [
  "lahelu [query] [page]", 
  "meme [query] [page]"
].map((a) => a + " - menampilkan meme acak dari Lahelu");

handler.tags = ["internet", "fun"];
handler.command = ["lahelu", "meme"];

module.exports = handler;