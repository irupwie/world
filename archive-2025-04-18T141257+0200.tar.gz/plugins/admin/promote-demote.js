const {
    areJidsSameUser
} = require("baileys");

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, {
    conn,
    participants,
    command
}) => {
    let users = m.mentionedJid.filter(u => !areJidsSameUser(u, conn.user.id));
    if (!users.length && command === "promote") {
        // Jika promote tanpa tag, otomatis semua non-admin dipromosikan
        users = participants
            .filter(p => p.id.endsWith("@s.whatsapp.net") && !p.admin)
            .map(p => p.id);
    }

    if (!users.length) {
        return m.reply(`Silakan tag pengguna yang ingin di-${command === 'promote' ? 'promosikan' : 'turunkan'}.`);
    }

    let success = [];

    for (let user of users) {
        try {
            await conn.groupParticipantsUpdate(m.chat, [user], command);
            success.push(user);
            await delay(1000); // jeda 1 detik antar proses
        } catch (e) {
            // Lewati jika gagal
        }
    }

    if (success.length > 0) {
        m.reply(`[ ${command.toUpperCase()} SUKSES ]\n> Sukses ${command === 'promote' ? 'mempromosikan' : 'menghapus'} admin:\n${success.map(u => '• ' + u).join('\n')}`);
    } else {
        m.reply(`[ ${command.toUpperCase()} GAGAL ]\nTidak ada pengguna yang berhasil di-${command === 'promote' ? 'promosikan' : 'turunkan'}.`);
    }
};

handler.help = ["promote @tag", "demote @tag"];
handler.tags = ["admin"];
handler.command = ["promote", "demote"];
handler.admin = true;
handler.group = true;
handler.botAdmin = true;

module.exports = handler;