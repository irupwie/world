let handler = async (m, { conn, args, usedPrefix, command }) => {
    const groupId = m.chat;
    const [subCommandRaw, ...restArgs] = args;
    const subCommand = (subCommandRaw || '').toLowerCase();
    const options = restArgs.join(' ').trim();

    const formatDate = (timestamp) =>
        new Intl.DateTimeFormat('id-ID', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(timestamp * 1000));

    const reply = (text) => conn.reply(m.chat, text, m);

    const joinRequestList = await conn.groupRequestParticipantsList(groupId).catch(() => []);

    if (!subCommand) {
        return reply(
`*「 PANDUAN PERINTAH ACC 」*

Perintah ini digunakan untuk *mengelola permintaan masuk* ke grup yang *diatur melalui sistem "join request"*. Anda dapat menampilkan daftar pengguna yang meminta bergabung, lalu memilih untuk menyetujui atau menolak mereka berdasarkan urutan atau JID mereka.

*╭───〈 FORMAT UMUM 〉───*
│ ${usedPrefix}${command} [list|approve|reject] [opsi]
*╰─────────────────────*

*╭─〈 PENJELASAN SUBPERINTAH 〉─*
│ • *list* → Menampilkan daftar permintaan bergabung.
│ • *approve* → Menyetujui permintaan bergabung.
│ • *reject* → Menolak permintaan bergabung.
*╰────────────────────────*

*╭─〈 OPSI YANG DIDUKUNG 〉─*
│ • *1|2|3* → Pilih berdasarkan nomor urutan dari list.
│ • *@nomorjid* → Pilih langsung berdasarkan JID pengguna.
│ • *all* → Proses semua permintaan sekaligus.
*╰────────────────────────*

*╭─〈 CONTOH PENGGUNAAN 〉─*
│ • Tampilkan daftar:
│   ◦ ${usedPrefix}${command} list
│
│ • Setujui urutan ke-1 dan ke-3:
│   ◦ ${usedPrefix}${command} approve 1|3
│
│ • Tolak pengguna tertentu via JID:
│   ◦ ${usedPrefix}${command} reject 6281234567890@s.whatsapp.net
│
│ • Setujui semua permintaan:
│   ◦ ${usedPrefix}${command} approve all
│
│ • Tolak semua permintaan:
│   ◦ ${usedPrefix}${command} reject all
*╰────────────────────────*

*Note:*
- Hanya bisa digunakan oleh admin grup.
- Bot harus memiliki izin admin juga.
- Nomor urutan mengacu pada hasil dari perintah *list* sebelumnya.
`
        );
    }

    switch (subCommand) {
        case 'list':
            if (!joinRequestList.length) {
                return reply('✅ Tidak ada permintaan bergabung yang tertunda saat ini.');
            }

            const formattedList = joinRequestList
                .map((req, i) => {
                    const nomor = req.jid.split('@')[0];
                    const waktu = formatDate(req.request_time);
                    return `*${i + 1}.*\n• Nomor   : wa.me/${nomor}\n• Metode  : ${req.request_method}\n• Waktu   : ${waktu}`;
                })
                .join('\n\n');

            return reply(`*📋 Daftar Permintaan Bergabung:*\n\n${formattedList}`);

        case 'approve':
        case 'reject': {
            if (!options) {
                return reply(`Masukkan opsi valid! Gunakan *${usedPrefix}${command} ${subCommand} [all|1|2|jid]*`);
            }

            let targets = [];

            if (options.toLowerCase() === 'all') {
                targets = joinRequestList;
            } else {
                const inputs = options.split('|').map(v => v.trim());
                for (const input of inputs) {
                    if (/^\d+$/.test(input)) {
                        const index = parseInt(input) - 1;
                        if (joinRequestList[index]) targets.push(joinRequestList[index]);
                    } else if (input.includes('@')) {
                        const found = joinRequestList.find(req => req.jid === input);
                        if (found) targets.push(found);
                    }
                }
            }

            if (!targets.length) {
                return reply('❌ Tidak ditemukan permintaan yang cocok untuk diproses.');
            }

            for (const req of targets) {
                try {
                    await conn.groupRequestParticipantsUpdate(groupId, [req.jid], subCommand);
                } catch (e) {
                    console.error(`Gagal memproses ${req.jid}:`, e);
                }
            }

            await conn.sendMessage(m.chat, {
                react: {
                    text: '⚡',
                    key: m.key
                }
            });
            return;
        }

        default:
            return reply(
`*Perintah tidak dikenali!*

Gunakan salah satu format berikut:
• ${usedPrefix}${command} list
• ${usedPrefix}${command} approve 1|2|3
• ${usedPrefix}${command} reject nomor@jid
• ${usedPrefix}${command} approve all
• ${usedPrefix}${command} reject all`
            );
    }
};

handler.help = ['acc'];
handler.tags = ['admin'];
handler.command = ['acc'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.fail = null;

module.exports = handler;