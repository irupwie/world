const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const fetch = require('node-fetch');
const FormData = require('form-data');
const {
    fileTypeFromBuffer
} = require('file-type');
const moment = require('moment-timezone');

// Directory for storing JSON databases
const DB_DIR = path.join(process.cwd(), './database/store');
// Ensure the database directory exists
if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, {
        recursive: true
    });
}

// Function to upload media using Catbox
async function uploadMedia(buffer) {
    try {
        let ext = 'bin';
        try {
            const fileType = await fileTypeFromBuffer(buffer);
            if (fileType && fileType.ext) {
                ext = fileType.ext;
            }
        } catch (typeError) {
            console.error("Error determining file type:", typeError);
        }

        if (buffer.length > 20 * 1024 * 1024) {
            throw new Error("File terlalu besar, maksimal ukuran file adalah 20 MB.");
        }

        let bodyForm = new FormData();
        bodyForm.append("fileToUpload", buffer, "file." + ext);
        bodyForm.append("reqtype", "fileupload");

        let res = await fetch("https://catbox.moe/user/api.php", {
            method: "POST",
            body: bodyForm,
        });

        if (!res.ok) throw new Error('Error uploading file: ' + res.statusText);

        let fileUrl = await res.text();
        if (!fileUrl) throw new Error("Gagal mengunggah file.");

        return fileUrl;
    } catch (error) {
        console.error("Upload error:", error);
        throw error;
    }
}

const formatSize = (size) => {
    if (size < 1024) return size + " B";
    else if (size < 1048576) return (size / 1024).toFixed(2) + " KB";
    else if (size < 1073741824) return (size / 1048576).toFixed(2) + " MB";
    else return (size / 1073741824).toFixed(2) + " GB";
};

function getStoreDB(chatId) {
    const sanitizedChatId = chatId.replace(/[^a-zA-Z0-9]/g, '_');
    const dbPath = path.join(DB_DIR, `store_${sanitizedChatId}.json`);

    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, JSON.stringify({
            items: []
        }), 'utf8');
        return {
            items: []
        };
    }

    try {
        const data = fs.readFileSync(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading store database for ${chatId}:`, error);
        return {
            items: []
        };
    }
}

function saveStoreDB(chatId, data) {
    const sanitizedChatId = chatId.replace(/[^a-zA-Z0-9]/g, '_');
    const dbPath = path.join(DB_DIR, `store_${sanitizedChatId}.json`);

    try {
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error(`Error saving store database for ${chatId}:`, error);
        return false;
    }
}

function getMediaType(mimeType) {
    if (!mimeType) return 'text';
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (mimeType === 'audio/ogg; codecs=opus') return 'voice';
    return 'file';
}

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    const chatId = m.chat;

    switch (command.toLowerCase()) {
        case "addlist":
            return handleAddList(m, {
                conn,
                text,
                usedPrefix,
                command,
                chatId
            });

        case "dellist":
            return handleDelList(m, {
                conn,
                text,
                usedPrefix,
                command,
                chatId
            });

        case "list":
            return handleListStore(m, {
                conn,
                usedPrefix,
                chatId
            });

        default:
            m.reply("Command tidak dikenal");
            return;
    }
};

async function handleAddList(m, {
    conn,
    text,
    usedPrefix,
    command,
    chatId
}) {
    if (!text) {
        m.reply(`Uhm.. mau menambahkan apa?\n\n*Contoh:* ${usedPrefix + command} hai|halooo\n\n> *Contoh cara menambahkan pesan ke list & cara memanggil list nya :*\n> https://files.catbox.moe/l2bynd.jpg`);
        return;
    }

    let key, response;
    let isReplied = false;
    let quotedMessage = m.quoted ? m.quoted : m;
    let mediaType = 'text';
    let mediaUrl = null;

    if (text.includes("|")) {
        [key, response] = text.split("|").map(item => item.trim());

        if (!response && key) {
            if (m.quoted) {
                isReplied = true;
                let mimeType = (quotedMessage.msg || quotedMessage).mimetype || quotedMessage.mediaType || "";
                mediaType = getMediaType(mimeType);

                response = quotedMessage.text || quotedMessage.caption || quotedMessage.body || "";

                if ((mediaType === 'audio' || mediaType === 'voice') && !response) {
                    response = "";
                }
            } else {
                m.reply(`*Contoh:* ${usedPrefix + command} hai|halooo\n*atau*\n*Reply pesan dengan* ${usedPrefix + command} hai`);
                return;
            }
        }
    } else {
        key = text.trim();

        if (m.quoted) {
            isReplied = true;

            let mimeType = (quotedMessage.msg || quotedMessage).mimetype || quotedMessage.mediaType || "";
            mediaType = getMediaType(mimeType);

            response = quotedMessage.text || quotedMessage.caption || quotedMessage.body || "";

            if ((mediaType === 'audio' || mediaType === 'voice') && !response) {
                response = "";
            }
        } else {
            m.reply(`*Contoh:* ${usedPrefix + command} hai|halooo\n*atau*\n*Reply pesan dengan* ${usedPrefix + command} hai\n\n> *Contoh cara menambahkan pesan ke list & cara memanggil list nya :*\n> https://files.catbox.moe/l2bynd.jpg`);
            return;
        }
    }

    const storeDB = getStoreDB(chatId);

    const existingItem = storeDB.items.find(item => item.key === key);
    if (existingItem) {
        m.reply(`Maaf, ${key} sudah terdaftar di list!`);
        return;
    }

    try {
        if (isReplied && mediaType !== 'text') {
            let mimeType = (quotedMessage.msg || quotedMessage).mimetype || quotedMessage.mediaType || "";

            if (mimeType) {
                let mediaData;
                try {
                    mediaData = await quotedMessage.download();

                    if (!mediaData || mediaData.length === 0) {
                        throw new Error("Media tidak dapat diunduh");
                    }

                    mediaUrl = await uploadMedia(mediaData);
                } catch (mediaError) {
                    console.error("Media processing error:", mediaError);
                    m.reply(`Gagal memproses media: ${mediaError.message}`);
                    return;
                }
            }
        }

        const newItem = {
            key,
            response,
            mediaType,
            mediaUrl,
            timestamp: Date.now()
        };

        storeDB.items.push(newItem);

        if (saveStoreDB(chatId, storeDB)) {
            m.reply(`Sukses menambahkan *${key}* ke daftar store\n\n> Sihlakan ketik key itu tanpa prefix atau ./$&#!?}\n> *Contoh :* https://files.catbox.moe/zygz3v.jpg`);
        } else {
            m.reply("Gagal menyimpan data ke database");
        }
    } catch (error) {
        console.error("Add list error:", error);
        m.reply(`Error: ${error.message}`);
    }
}

async function handleDelList(m, {
    conn,
    text,
    usedPrefix,
    command,
    chatId
}) {
    if (!text) {
        m.reply(`Uhm.. mana yang mau dihapus?\nContoh:\n*${usedPrefix + command} Key*`);
        return;
    }

    const storeDB = getStoreDB(chatId);

    if (storeDB.items.length === 0) {
        m.reply("Belum ada list di grup ini!");
        return;
    }

    const indexToDelete = storeDB.items.findIndex(item => item.key === text);

    if (indexToDelete !== -1) {
        const itemToDelete = storeDB.items[indexToDelete];
        storeDB.items.splice(indexToDelete, 1);

        if (saveStoreDB(chatId, storeDB)) {
            m.reply(`Berhasil menghapus *${itemToDelete.key}* dari daftar list!`);
        } else {
            m.reply("Gagal menyimpan perubahan ke database");
        }
    } else {
        m.reply(`Maaf, ${text} tidak ditemukan di list!\nKetik ${usedPrefix}liststore untuk melihat daftar yang tersedia.`);
    }
}

async function handleListStore(m, {
    conn,
    usedPrefix,
    chatId
}) {
    const storeDB = getStoreDB(chatId);

    if (storeDB.items.length === 0) {
        m.reply(`Belum ada list store di grup ini.\nUntuk menambahkan ketik ${usedPrefix}addlist`);
        return;
    }

    let storeItems = storeDB.items.map(item => `⇒ ${item.key}`).join("\n");

    function getGreeting() {
        const currentHour = moment().tz("Asia/Jakarta").hour();
        return {
            0: "Selamat malam",
            6: "Selamat pagi",
            12: "Selamat siang",
            18: "Selamat sore"
        } [Math.floor(currentHour / 6)] || "Halo";
    }

    const userName = m.pushName || m.name || "sahabat";
    let responseText = `*${getGreeting()} Kak ${userName}*.\n\n`;
    responseText += "Berikut ini adalah daftar store yang ada di grup ini:\n";
    responseText += storeItems;
    responseText += "\n\n*Silahkan Ketik Kata Kunci Tersebut*\n*Tanpa Menggunakan Tanda #!/.*\n> *Contoh (dalam format foto) :*\n> https://files.catbox.moe/my19a0.png";

    m.reply(responseText);
}

handler.before = async (m, {
    conn
}) => {
    if (!m.text || !m.isGroup) return;

    const chatId = m.chat;
    const storeDB = getStoreDB(chatId);

    const storeItem = storeDB.items.find(item =>
        item.key.toLowerCase() === m.text.toLowerCase());

    if (storeItem) {
        if (storeItem.mediaUrl) {
            switch (storeItem.mediaType) {
                case 'image':
                    await conn.sendFile(
                        m.chat,
                        storeItem.mediaUrl,
                        'store_item.jpg',
                        storeItem.response,
                        m
                    );
                    break;
                case 'video':
                    await conn.sendFile(
                        m.chat,
                        storeItem.mediaUrl,
                        'store_item.mp4',
                        storeItem.response,
                        m,
                        false, {
                            asVideo: true
                        }
                    );
                    break;
                case 'audio':
                    await conn.sendFile(
                        m.chat,
                        storeItem.mediaUrl,
                        'store_item.mp3',
                        null,
                        m,
                        false, {
                            mimetype: 'audio/mp4'
                        }
                    );
                    if (storeItem.response) {
                        await m.reply(storeItem.response);
                    }
                    break;
                case 'voice':
                    await conn.sendFile(
                        m.chat,
                        storeItem.mediaUrl,
                        'store_item.opus',
                        null,
                        m,
                        false, {
                            mimetype: 'audio/ogg; codecs=opus',
                            ptt: true
                        }
                    );
                    if (storeItem.response) {
                        await m.reply(storeItem.response);
                    }
                    break;
                default:
                    await conn.sendFile(
                        m.chat,
                        storeItem.mediaUrl,
                        'store_item',
                        storeItem.response,
                        m
                    );
            }
        } else {
            await m.reply(storeItem.response);
        }
        return true;
    }
};

async function uploadcatbox(buffer) {
    const fileType = await fileTypeFromBuffer(buffer);
    let ext = fileType ? fileType.ext : 'bin';

    let bodyForm = new FormData();
    bodyForm.append("fileToUpload", buffer, "file." + ext);
    bodyForm.append("reqtype", "fileupload");

    let res = await fetch("https://catbox.moe/user/api.php", {
        method: "POST",
        body: bodyForm,
    });

    if (!res.ok) throw new Error('Error uploading file: ' + res.statusText);

    let data = await res.text();
    return data;
}

handler.help = ["addlist", "dellist", "list"];
handler.tags = ["group"];
handler.command = ["addlist", "dellist", "list"];
handler.group = true;
handler.admin = true;

module.exports = handler;