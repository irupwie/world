const handler = async (m, {
    conn,
    text,
    isROwner,
    isOwner,
    command
}) => {

    //=====================[ VALIDASI INPUT ]=====================//

    if (!text) {
        return m.reply(
            `*⚠️ Silakan masukkan teks yang ingin diatur!*\n\n` +

            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `*Contoh Penggunaan Sederhana:*\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `• ${command} Selamat datang @user di grup @subject!\n` +
            `• ${command} Sampai jumpa @user, semoga sukses selalu!\n\n` +

            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `*Contoh Penggunaan Kompleks:*\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `• ${command} Hai @user! Selamat datang di @subject.\n  Jangan lupa baca deskripsi: @desc\n\n` +
            `• ${command} @user telah meninggalkan grup @subject.\n  Semoga perjalananmu menyenangkan!\n\n` +
            `• ${command} Halo @user!\n  Kami senang kamu bergabung di @subject.\n  Baca rules di @desc ya!\n\n` +
            `• ${command} @user keluar dari grup @subject.\n  Sampai bertemu lagi di lain waktu.\n\n` +

            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `*Placeholder yang Didukung:*\n` +
            `━━━━━━━━━━━━━━━━━━━━━━\n` +
            `• @user    → Menyebut anggota\n` +
            `• @subject → Nama grup\n` +
            `• @desc    → Deskripsi grup`
        );
    }

    //=====================[ PENGAMBILAN DATA ]=====================//

    const chat = global.db.data.chats[m.chat] || {};
    let responseMessage = '';

    //=====================[ FUNGSI SETTING PESAN ]=====================//

    const setMessage = (type, value) => {
        if (isROwner) global.conn[type] = value;
        else if (isOwner) conn[type] = value;

        chat[type] = value;
    };

    //=====================[ PENANGANAN PERINTAH ]=====================//

    switch (command) {

        case 'setbye':
        case 'setleft':
            setMessage('sBye', text);

            responseMessage =
                `*✅ Pesan perpisahan berhasil disimpan!*\n\n` +
                `Pesan ini akan dikirim saat ada anggota keluar dari grup.\n\n` +
                `━━━━━━━━━━━━━━━━━━━━━━\n` +
                `*Placeholder yang Tersedia:*\n` +
                `━━━━━━━━━━━━━━━━━━━━━━\n` +
                `• @user    → Menyebut anggota keluar\n` +
                `• @subject → Nama grup\n` +
                `• @desc    → Deskripsi grup\n\n` +
                `━━━━━━━━━━━━━━━━━━━━━━\n` +
                `*Contoh pesan yang diatur:*\n\n${text}`;
            break;


        case 'setwelcome':
        case 'setwlc':
        case 'setwelc':
            setMessage('sWelcome', text);

            responseMessage =
                `*✅ Pesan selamat datang berhasil disimpan!*\n\n` +
                `Pesan ini akan dikirim saat ada anggota baru masuk ke grup.\n\n` +
                `━━━━━━━━━━━━━━━━━━━━━━\n` +
                `*Placeholder yang Tersedia:*\n` +
                `━━━━━━━━━━━━━━━━━━━━━━\n` +
                `• @user    → Menyebut anggota baru\n` +
                `• @subject → Nama grup\n` +
                `• @desc    → Deskripsi grup\n\n` +
                `━━━━━━━━━━━━━━━━━━━━━━\n` +
                `*Contoh pesan yang diatur:*\n\n${text}`;
            break;


        default:
            responseMessage =
                `*⚠️ Perintah tidak dikenal!*\n\n` +
                `Gunakan perintah berikut:\n\n` +
                `• *setwelcome* → Untuk mengatur pesan selamat datang\n` +
                `• *setbye*     → Untuk mengatur pesan perpisahan`;
    }

    //=====================[ BALASAN KE PENGGUNA ]=====================//

    m.reply(responseMessage);
};



//=====================[ METADATA HANDLER ]=====================//

handler.help = ['setbye [teks]', 'setwelcome [teks]'];
handler.tags = ['admin'];
handler.command = ['setbye', 'setleft', 'setwelcome', 'setwlc', 'setwelc'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;