const fs = require('fs')
const path = require('path')
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

const FILE_PATH = path.join(__dirname, '../../database/giveaway.json')

// Fungsi untuk baca dan simpan file giveaway
function loadGiveaway() {
    if (!fs.existsSync(FILE_PATH)) return {}
    try {
        return JSON.parse(fs.readFileSync(FILE_PATH))
    } catch {
        return {}
    }
}

function saveGiveaway(data) {
    fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2))
}

let handler = async (m, {
    conn,
    participants,
    usedPrefix,
    command,
    text,
    isAdmin
}) => {
    if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di dalam grup!'

    const id = m.chat
    let db = loadGiveaway()
    conn.giveway = db

    const getDate = () => new Date().toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    const mentionList = (list) => list.map((v, i) => `│ ${i + 1}. @${v.split('@')[0]}`).join('\n')

    const adminOnly = ['mulaigiveaway', 'startgiveaway', 'cekgiveaway', 'rollgiveaway', 'rollinggiveaway', 'rolling', 'hapusgiveaway', 'deletegiveaway']
    if (adminOnly.includes(command.toLowerCase()) && !isAdmin) throw '*Fitur ini hanya bisa digunakan oleh admin grup!*'

    switch (command.toLowerCase()) {
        case 'mulaigiveaway':
        case 'startgiveaway': {
            let q = m.quoted || m
            text = text || q?.text || q?.caption || q?.description
            if (!text) throw `Contoh: ${usedPrefix + command} GIVEAWAY AKUN PREMIUM`
            if (id in conn.giveway) throw '*Masih ada giveaway yang aktif di grup ini!*'

            const info = `Berhasil memulai giveaway!\n\n*${usedPrefix}ikut* - untuk ikut\n*${usedPrefix}cekgiveaway* - untuk cek\n*${usedPrefix}rollgiveaway* - cari pemenang\n*${usedPrefix}hapusgiveaway* - hapus giveaway\n\n*INFORMASI:*\n\n${text}`
            conn.giveway[id] = [
                await conn.sendMessage(id, {
                    text: info,
                    mentions: participants.map(p => p.id)
                }),
                [],
                text
            ]
            saveGiveaway(conn.giveway)
            break
        }

        case 'cekgiveaway': {
            if (!(id in conn.giveway)) throw `_*Tidak ada giveaway aktif di grup ini.*_\n\nGunakan *${usedPrefix}mulaigiveaway* untuk memulai.`
            let absen = conn.giveway[id][1]
            let date = getDate()
            let list = mentionList(absen)

            conn.reply(id, `*「 LIST PESERTA GIVEAWAY 」*\n\nTanggal: ${date}\n${conn.giveway[id][2]}\n\n┌ *Yang sudah ikut:*\n│ Total: ${absen.length}\n${list}\n└────\n\n_${global.wm}_`, m, {
                contextInfo: {
                    mentionedJid: absen
                }
            })
            break
        }

        case 'hapusgiveaway':
        case 'deletegiveaway': {
            if (!(id in conn.giveway)) throw '*Tidak ada giveaway yang sedang berlangsung!*'
            delete conn.giveway[id]
            saveGiveaway(conn.giveway)
            conn.sendMessage(id, {
                text: '*Giveaway telah selesai!*',
                mentions: participants.map(p => p.id)
            })
            break
        }

        case 'ikut':
        case 'ikutgiveaway': {
            if (!(id in conn.giveway)) throw '*Belum ada giveaway yang sedang berjalan.*'
            let absen = conn.giveway[id][1]
            if (absen.includes(m.sender)) throw '*Kamu sudah terdaftar dalam giveaway ini!*'
            absen.push(m.sender)
            saveGiveaway(conn.giveway)
            m.reply(`*Berhasil ikut giveaway!*\n\nTotal peserta saat ini: *${absen.length} orang*`)
            break
        }

        case 'rollgiveaway':
        case 'rolling':
        case 'rollinggiveaway': {
            if (!(id in conn.giveway)) throw '*Tidak ada giveaway aktif di grup ini!*'
            let absen = conn.giveway[id][1]
            if (!absen.length) throw '*Belum ada yang ikut giveaway!*'

            let date = getDate()
            let winner = absen[Math.floor(Math.random() * absen.length)]
            let tag = `@${winner.split('@')[0]}`
            let loadd = [
                '■□□□□ 20%',
                '■■□□□ 40%',
                '■■■□□ 60%',
                '■■■■□ 80%',
                '■■■■■ 100%',
                '*Sedang memilih pemenang...*'
            ]

            let {
                key
            } = await conn.sendMessage(id, {
                text: '*Memilih pemenang...*'
            })
            for (let l of loadd) {
                await sleep(1000)
                await conn.sendMessage(id, {
                    text: l,
                    edit: key
                })
            }

            conn.reply(id, `🎉 *SELAMAT!* 🎉\n${tag} adalah pemenang giveaway!\n\nTanggal: ${date}\n\n_*Gunakan perintah ${usedPrefix}hapusgiveaway untuk mengakhiri.*_`, m, {
                contextInfo: {
                    mentionedJid: absen
                }
            })
            break
        }

        default:
            throw '*Perintah giveaway tidak dikenali.*'
    }
}

handler.help = [
    'mulaigiveaway [teks]',
    'cekgiveaway',
    'ikutgiveaway',
    'rollgiveaway',
    'hapusgiveaway'
]
handler.tags = ['admin']
handler.command = [
    'mulaigiveaway',
    'cekgiveaway',
    'ikutgiveaway',
    'rollgiveaway',
    'hapusgiveaway'
]
handler.group = true

module.exports = handler