let handler = async (m, { text, conn, participants }) => {
  let targets = [];

  if (m.quoted) {
    targets.push(m.quoted.sender);
  }

  if (m.mentionedJid && m.mentionedJid.length > 0) {
    targets.push(...m.mentionedJid);
  }

  if (text) {
    let teks = text.replace(/[^0-9\s]/g, '').split(/\s+/).filter(Boolean);
    for (let num of teks) {
      if (!num.endsWith('@s.whatsapp.net')) num += '@s.whatsapp.net';
      targets.push(num);
    }
  }

  if (targets.length === 0) return m.reply(
    "Contoh penggunaan:\n" +
    "- Balas chat orang yang ingin dikeluarkan\n" +
    "- Tag @user\n" +
    "- .kick 628xxxxxx\n" +
    "- .kick 628xxxx1 628xxxx2"
  );

  let groupData = await conn.groupMetadata(m.chat);
  let failed = [], success = [];

  for (let target of targets) {
    if (target === conn.user.jid) {
      failed.push("Tidak bisa kick bot sendiri");
      continue;
    }
    if (target === m.sender) {
      failed.push("Tidak bisa kick diri sendiri");
      continue;
    }
    if (target === groupData.owner) {
      failed.push("Tidak bisa kick pemilik grup");
      continue;
    }

    let isValid = await conn.onWhatsApp(target);
    if (!isValid[0]?.exists) {
      failed.push(`Nomor tidak valid: ${target.split('@')[0]}`);
      continue;
    }

    try {
      let res = await conn.groupParticipantsUpdate(m.chat, [target], 'remove');
      if (res[0]?.status === 200) {
        success.push(target.split('@')[0]);
      } else {
        failed.push(`Gagal kick: ${target.split('@')[0]}`);
      }
    } catch (e) {
      failed.push(`Error saat kick: ${target.split('@')[0]}`);
    }
  }

  let msg = '';
  if (success.length) msg += `Berhasil kick:\n${success.map(v => '- ' + v).join('\n')}\n\n`;
  if (failed.length) msg += `Gagal kick:\n${failed.map(v => '- ' + v).join('\n')}`;

  m.reply(msg.trim());
};

handler.help = ['kick']
handler.tags = ['admin']
handler.command = ['kick', 'kik', 'kickmember', 'keluarkan']
handler.group = true;
handler.botAdmin = true;
handler.admin = true;

module.exports = handler;