//Simple Base Botz
// • Credits : wa.me/62895322391225 [ Asyl ]
// • Feature : group/totag


let handler = async (m, {
    conn,
    text,
    isAdmin,
    participants
}) => {

    let users = participants.map(u => u.id).filter(v => v !== conn.user.jid)
    if (!m.quoted) return m.reply(`Reply pesan text/media`)
    conn.sendMessage(m.chat, {
        forward: m.quoted.fakeObj,
        mentions: users
    })
}

handler.help = ['totag']
handler.tags = ['group']
handler.command = ["totag"]
handler.admin = true
handler.group = true

module.exports = handler