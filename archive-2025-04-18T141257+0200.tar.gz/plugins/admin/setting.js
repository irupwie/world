let handler = async (
  m,
  { isAdmin, isOwner, isBotAdmin, conn, args, usedPrefix, command },
) => {
  let input = args[0]?.toLowerCase() || command?.toLowerCase() || "";
  let isClose = {
    open: "not_announcement",
    buka: "not_announcement",
    on: "not_announcement",
    1: "not_announcement",
    close: "announcement",
    tutup: "announcement",
    off: "announcement",
    0: "announcement",
  }[input];

  if (isClose === undefined) {
    return m.reply(
`*「 PENGGUNAAN PERINTAH 」*

Perintah ini digunakan untuk mengatur siapa saja yang dapat mengirim pesan di grup WhatsApp.

*╭─❏ FORMAT UMUM:*
│ ${usedPrefix + command} [open|close]
*╰────*

*╭─❏ PENJELASAN:*
│ • *open / buka / on / 1*  → Membuka grup untuk semua anggota.
│ • *close / tutup / off / 0* → Menutup grup agar hanya admin yang bisa kirim pesan.
*╰────*

*╭─❏ CONTOH PENGGUNAAN:*
│ • Buka grup:
│   ${usedPrefix + command} open
│   ${usedPrefix + command} buka
│   ${usedPrefix + command} 1
│
│ • Tutup grup:
│   ${usedPrefix + command} close
│   ${usedPrefix + command} tutup
│   ${usedPrefix + command} 0
*╰────*

*Note:* Perintah ini hanya dapat digunakan oleh admin grup dan bot harus memiliki izin admin juga.`
    );
  }

  await conn.groupSettingUpdate(m.chat, isClose);

  let tanggal = new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
  let jam = new Date().toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: "Asia/Jakarta"
  });
  let user = `@${m.sender.split("@")[0]}`;

  if (isClose === "announcement") {
    m.reply(
`❌ *GRUP DITUTUP!*

📅 Tanggal: *${tanggal}*
⏰ Waktu  : *${jam} WIB*
👮 Admin  : ${user}

🚫 Grup telah ditutup! Hanya admin yang dapat mengirim pesan.`
    );
  } else {
    m.reply(
`✨ *GRUP DIBUKA* ✨

📅 Tanggal: *${tanggal}*
⏰ Waktu  : *${jam} WIB*
👮 Admin  : ${user}

🎉 Grup telah berhasil dibuka! Semua anggota kini dapat mengirim pesan.`
    );
  }
};

handler.help = ["group", "gc", "grup", "open", "close"].map((a) => a + " *[open/close]*");
handler.tags = ["admin"];
handler.command = ["group", "gc", "grup", "open", "close"];
handler.group = true;
handler.botAdmin = true;
handler.admin = true;

module.exports = handler;