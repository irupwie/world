const fs = require('fs')
const path = require('path')
const warnFile = path.join(__dirname, '../../database/warn.json')

/**
 * Load warning data from JSON file
 * @returns {Object} Warning data object
 */
function loadWarnData() {
    try {
        // Create default structure if file doesn't exist
        if (!fs.existsSync(warnFile)) {
            return { groups: {} }
        }
        
        const data = JSON.parse(fs.readFileSync(warnFile, 'utf-8'))
        if (!data || typeof data !== 'object') {
            return { groups: {} }
        }
        
        // Ensure we have a groups object
        if (!data.groups) data.groups = {}
        return data
    } catch (error) {
        console.error('Error loading warn data:', error)
        return { groups: {} }
    }
}

/**
 * Save warning data to JSON file
 * @param {Object} data Warning data to save
 * @returns {boolean} Success status
 */
function saveWarnData(data) {
    try {
        const dir = path.dirname(warnFile)
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true })
        }
        
        fs.writeFileSync(warnFile, JSON.stringify(data, null, 2))
        return true
    } catch (error) {
        console.error('Error saving warn data:', error)
        return false
    }
}

/**
 * Get or initialize group data
 * @param {Object} warnData Warning data object
 * @param {string} groupId Group ID
 * @returns {Object} Group data
 */
function getGroupData(warnData, groupId) {
    // Initialize group data if it doesn't exist
    if (!warnData.groups[groupId]) {
        warnData.groups[groupId] = {
            max: 5,
            users: {}
        }
    }
    return warnData.groups[groupId]
}

/**
 * Check if bot has admin privileges
 * @param {Array} participants Group participants
 * @param {Object} conn Connection object
 * @returns {boolean} True if bot is admin
 */
function isBotAdmin(participants, conn) {
    const botParticipant = participants.find(p => p.id === conn.user.jid)
    return botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin'
}

/**
 * Format warn status message
 * @param {string} name User name
 * @param {number} warns Current warns
 * @param {number} maxWarns Maximum warns
 * @returns {string} Formatted status message
 */
function formatWarnStatus(name, warns, maxWarns) {
    const percentage = Math.round((warns / maxWarns) * 100)
    const progressBar = createProgressBar(percentage)
    return `⚠️ *${name}*\n${progressBar} ${warns}/${maxWarns} [${percentage}%]`
}

/**
 * Create text-based progress bar
 * @param {number} percentage Percentage filled
 * @returns {string} Progress bar
 */
function createProgressBar(percentage) {
    const filled = Math.floor(percentage / 10)
    const empty = 10 - filled
    return '█'.repeat(filled) + '░'.repeat(empty)
}

let handler = async (m, {
    conn,
    text,
    args,
    usedPrefix,
    command,
    participants,
    isAdmin
}) => {
    // Validate group context
    if (!m.isGroup) {
        return m.reply('⚠️ Perintah ini hanya bisa digunakan dalam grup')
    }

    // Check admin permission for commands that require it
    const adminCommands = ['warn', 'unwarn', 'resetwarn', 'setwarn']
    if (adminCommands.includes(command) && !isAdmin) {
        return m.reply('⚠️ Perintah ini hanya bisa digunakan oleh admin grup')
    }

    const groupId = m.chat
    let warnData = loadWarnData()
    let groupData = getGroupData(warnData, groupId)

    // Handle setwarn command
    if (command === 'setwarn') {
        const maxWarn = parseInt(text)
        if (!text || isNaN(maxWarn) || maxWarn < 1) {
            return m.reply(`⚠️ Format salah!\nContoh: *${usedPrefix}setwarn 3*\nNilai minimum adalah 1`)
        }
        
        groupData.max = maxWarn
        if (saveWarnData(warnData)) {
            return m.reply(`✅ Batas maksimal warn untuk grup ini diubah menjadi *${groupData.max}*`)
        } else {
            return m.reply('❌ Gagal menyimpan perubahan')
        }
    }

    // Handle listwarn command to list all warned users
    if (command === 'listwarn') {
        const users = Object.entries(groupData.users).filter(([_, warns]) => warns > 0)
        
        if (users.length === 0) {
            return m.reply('✅ Tidak ada anggota yang memiliki warn di grup ini')
        }
        
        let message = `*Daftar Warn Grup*\nBatas maksimal: ${groupData.max}\n\n`
        for (const [userId, warns] of users) {
            try {
                const userName = await conn.getName(userId)
                message += `${formatWarnStatus(userName, warns, groupData.max)}\n`
            } catch (error) {
                message += `${formatWarnStatus(`User ${userId.split('@')[0]}`, warns, groupData.max)}\n`
            }
        }
        
        return m.reply(message)
    }

    // Handle cekwarn command - FIXED to avoid the JID error
    if (command === 'cekwarn') {
        try {
            let who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
            let name = await conn.getName(who)
            let jumlah = groupData.users[who] || 0
            
            // Fixed: Don't use the mentions option which was causing the error
            return m.reply(formatWarnStatus(name, jumlah, groupData.max))
        } catch (error) {
            console.error('Error in cekwarn:', error)
            return m.reply('❌ Terjadi kesalahan saat memeriksa warn')
        }
    }

    // Get target user for other commands (warn, unwarn, resetwarn)
    let who
    try {
        who = m.mentionedJid?.[0] || (m.quoted ? m.quoted.sender : null)
        if (!who) {
            // Fixed: Use m.reply instead of conn.sendMessage to avoid JID errors
            return m.reply(`⚠️ Tag atau reply pesan orang yang ingin di-*${command}*!`)
        }
    } catch (error) {
        console.error('Error getting target user:', error)
        return m.reply('❌ Terjadi kesalahan saat memproses perintah')
    }

    // Validate target user
    if (who === conn.user.jid) {
        return m.reply('❌ Saya tidak bisa melakukan ini pada diri saya sendiri')
    }

    const targetParticipant = participants.find(p => p.id === who)
    if (!targetParticipant) {
        return m.reply('❌ User tidak ditemukan dalam grup ini')
    }

    const isTargetAdmin = targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin'
    if (command === 'warn' && isTargetAdmin) {
        return m.reply('❌ Tidak dapat memberi warn pada admin grup')
    }

    // Initialize user warn count if it doesn't exist
    if (!groupData.users[who]) groupData.users[who] = 0
    
    // Get username safely
    let userName
    try {
        userName = await conn.getName(who)
    } catch (error) {
        console.error('Error getting user name:', error)
        userName = who.split('@')[0]
    }

    // Process commands
    switch (command) {
        case 'warn':
            try {
                // Add reason if provided
                const reason = text.trim() ? `\nAlasan: ${text}` : ''
                
                // Increase warn count
                groupData.users[who] += 1
                
                // Check if max warns reached
                if (groupData.users[who] >= groupData.max) {
                    // Fixed: Use m.reply without mentions to avoid JID errors
                    m.reply(`${formatWarnStatus(userName, groupData.users[who], groupData.max)}${reason}\n\n⚠️ *${userName}* telah mencapai batas maksimal warn dan akan dikeluarkan dari grup.`)
                    
                    try {
                        // Check bot admin status
                        const botIsAdmin = isBotAdmin(participants, conn)
                        if (!botIsAdmin) {
                            return m.reply('❌ Gagal mengeluarkan user. Bot harus menjadi admin grup untuk melakukan ini.')
                        }
                        
                        // Remove user from group
                        await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
                        groupData.users[who] = 0
                        m.reply(`✅ *${userName}* telah dikeluarkan dari grup dan warn direset.`)
                    } catch (error) {
                        console.error('Error during kick:', error)
                        m.reply(`❌ Terjadi kesalahan saat mengeluarkan user: ${error.message}`)
                    }
                } else {
                    // Fixed: Use m.reply without mentions to avoid JID errors
                    m.reply(`${formatWarnStatus(userName, groupData.users[who], groupData.max)}${reason}`)
                }
            } catch (error) {
                console.error('Error in warn command:', error)
                m.reply('❌ Terjadi kesalahan saat memproses perintah warn')
            }
            break
            
        case 'unwarn':
            try {
                if (groupData.users[who] <= 0) {
                    return m.reply(`❌ *${userName}* tidak memiliki warn yang dapat dikurangi di grup ini.`)
                }
                
                groupData.users[who] = Math.max(0, groupData.users[who] - 1)
                // Fixed: Use m.reply without mentions to avoid JID errors
                m.reply(formatWarnStatus(userName, groupData.users[who], groupData.max))
            } catch (error) {
                console.error('Error in unwarn command:', error)
                m.reply('❌ Terjadi kesalahan saat memproses perintah unwarn')
            }
            break
            
        case 'resetwarn':
            try {
                if (!groupData.users[who] || groupData.users[who] === 0) {
                    return m.reply(`❌ *${userName}* tidak memiliki warn yang dapat direset di grup ini.`)
                }
                
                groupData.users[who] = 0
                // Fixed: Use m.reply without mentions to avoid JID errors
                m.reply(`✅ Semua warn untuk *${userName}* di grup ini telah dihapus.`)
            } catch (error) {
                console.error('Error in resetwarn command:', error)
                m.reply('❌ Terjadi kesalahan saat memproses perintah resetwarn')
            }
            break
    }

    // Save changes to warn data file
    saveWarnData(warnData)
}

handler.help = [
    'warn @tag [alasan]', 
    'unwarn @tag', 
    'resetwarn @tag', 
    'cekwarn [@tag]', 
    'setwarn [nomor]',
    'listwarn'
]
handler.tags = ['admin', 'group']
handler.command = ['warn', 'unwarn', 'resetwarn', 'cekwarn', 'setwarn', 'listwarn']
handler.group = true

// Only check admin requirement in the command handler
module.exports = handler