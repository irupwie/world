const moment = require("moment-timezone");
const fs = require("fs");
const file = require.resolve(__filename);

global.owner = ["33221852120"];
global.mods = ["33221852120"];
global.prems = ["33221852120"];

global.nameowner = "Denjii";
global.nomorown = "33221852120";

global.namebot = "Cikoo";
global.version = "1.1.0";
global.wm = "Ciko";
global.packname = "Ciko Bot wa";
global.author = `Time : ${moment().tz("Asia/Jakarta").format("HH.mm")} WIB`;
global.mail = "irupwie@gmail.com";

global.sourceUrl = "google.com";
global.saluran = "120363397789310208@newsletter";
global.tekssaluran = `WaBot`

global.multiplier = 1400;

global.wait = "*( Loading )* Plase Wait...";
global.eror = "*Error System*";
global.done = "*Result*";

global.thumb = "https://i.pinimg.com/originals/f8/84/8f/f8848f0aab4353d651c34a4be63af0d1.jpg";
global.icon = "https://i.pinimg.com/originals/e5/7f/9a/e57f9a98c998175cd5734f1afe774faa.png";

global.fetch = require("node-fetch");
global.axios = require("axios");
global.cheerio = require("cheerio");

global.Func = new (require(process.cwd() + "/lib/func"))();
global.lolhuman = "Akiraa";

global.capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);

global.fkontak = {
  key: {
    participants: "33221852120@s.whatsapp.net",
    remoteJid: "status@broadcast",
    fromMe: false,
    id: "Halo",
  },
  message: {
    contactMessage: {
      vcard: `BEGIN:VCARD
VERSION:3.0
N:Sy;Bot;;;
FN:y
item1.TEL;waid=33221852120:33221852120
item1.X-ABLabel:Ponsel
END:VCARD`,
    },
  },
  participant: "33221852120@s.whatsapp.net",
};

global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    const emot = {
      exp: "✨", money: "🪙", potion: "🥤", diamond: "💎",
      common: "📦", uncommon: "🎁", mythic: "🗳️", legendary: "🗃️",
      pet: "🎁", sampah: "🗑", armor: "🥼", sword: "⚔️",
      kayu: "🪵", batu: "🪨", string: "🕸️", kuda: "🐎",
      kucing: "🐈", anjing: "🐕", petFood: "🍖", gold: "👑",
      emerald: "💚"
    };
    const results = Object.keys(emot)
      .map(v => [v, new RegExp(v, "gi")])
      .filter(v => v[1].test(string));
    return results.length ? emot[results[0][0]] : "";
  },
};

global.doc = pickRandom([
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/msword",
  "application/pdf",
]);

global.tanggal = async (numer) => {
  const myMonths = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  const myDays = [
    "Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu"
  ];
  const tgl = new Date(numer);
  const day = tgl.getDate();
  const bulan = tgl.getMonth();
  const thisDay = tgl.getDay();
  const year = tgl.getFullYear();
  const d = new Date();
  const gmt = new Date(0).getTime() - new Date("1 January 1970").getTime();
  const weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][
    Math.floor((d * 1 + gmt) / 84600000) % 5
  ];
  return `${myDays[thisDay]}, ${day} - ${myMonths[bulan]} - ${year}`;
};

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log("Update config.js");
  delete require.cache[file];
  require(file);
});
