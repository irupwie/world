export const config = {
  prefix: "s."
}