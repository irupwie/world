import { system } from "@minecraft/server";

export async function showForm(player, form, timeout = Infinity) {
    const startTick = system.currentTick;
    while ((system.currentTick - startTick) < timeout) {
        const response = await form.show(player);
        
        if (response.cancelationReason !== "UserBusy") {
            return response;
        }
    }
    
    throw new Error(`Timed out after ${timeout} ticks`);
};