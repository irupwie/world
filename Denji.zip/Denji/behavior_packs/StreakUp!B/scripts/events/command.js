import { config } from "../config";

const Event = {
  name: "chatSend",
  type: 0,
  run: async(chat, db) => {
    if (!chat.message.startsWith(config.prefix)) return;

    chat.cancel = true;

    const player = chat.sender;
    const message = chat.message;
    const args = message.slice(config.prefix.length)
        .trim()
        .split(/ +/g);
    const cmd = args.shift()
        .toLowerCase();
    try {
        const {
            default: command
        } = await import(`../commands/${cmd}.js`);
        
        command.run(chat, player, args, db);
    } catch (err) {
        if (err instanceof ReferenceError) {
            player.sendMessage(`§cInvalid command ${cmd}. Check if the command actually exists.`);
        } else {
            console.error(err);
        }
    }
  }
}

export default Event;