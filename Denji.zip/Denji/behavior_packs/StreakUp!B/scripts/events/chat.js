import { config } from "../config";
import { world } from "@minecraft/server";

const Event = {
  name: "chatSend",
  type: 0,
  run: async(chat, db) => {
    if (chat.message.startsWith(config.prefix)) return;

    chat.cancel = true;
    const player = chat.sender;
    const message = chat.message;
    
    world.sendMessage(`§l§8[§r §6${player.getDynamicProperty("streak") || 0}§l§8]§r ${player.name}: §7${message}`)
    
  }
}

export default Event;