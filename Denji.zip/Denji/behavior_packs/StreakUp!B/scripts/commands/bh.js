const Command = {
  name: "bh",
  run: async(chat, player, args, db) => {
   const [q] = args;
   if(q === "prev") {
    const now = new Date();
    now.setDate(now.getDate() - 2); 
    const formattedDate = now.toLocaleDateString();

    player.setDynamicProperty("lastActive", formattedDate);
    player.setDynamicProperty("streak", 99)
    player.sendMessage(`§a[lastActive] set to: §f${formattedDate}. Please restart the game.`);
   }
   if(q === "now") {
   
    const formattedDate = new Date().toLocaleDateString();
   
   player.setDynamicProperty("streak", player.getDynamicProperty("streak") + 1)
    player.setDynamicProperty("lastActive", formattedDate);
    player.sendMessage(`§a[lastActive] set to: §f${formattedDate}. Please restart the game.`); 
   }
   
   if(q === "next") {
     const now = new Date();
    now.setDate(now.getDate() - 1); 
    const formattedDate = now.toLocaleDateString();

    player.setDynamicProperty("lastActive", formattedDate);
    player.sendMessage(`§a[lastActive] set to: §f${formattedDate}. Please restart the game.`);
   }
  }
}

export default Command;