import { world } from "@minecraft/server";

const Command = {
  name: "streak",
  run: async(chat, player, args, db) => {
    
  const targetName = args[0] || player.name; 

if (!targetName) return player.sendMessage("§eUsage: .streak <player>");

const targetPlayer = world.getAllPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());

if (!targetPlayer) return player.sendMessage(`§c§lERROR: §r§cPlayer "${targetName}" not found or is offline.`);

const streak = targetPlayer.getDynamicProperty("streak") || 0;
const lastActive = targetPlayer.getDynamicProperty("lastActive") || "Unknown";

if(!streak || !lastActive) return player.sendMessage("§c§lERROR: §r§cPlayer doesn't have a streak yet.")

player.sendMessage(
  `§6§l-----[ STREAK INFO ]-----§r\n` +
  `§bName:§r ${targetPlayer.name}\n` +
  `§a§l Streak:§r ${streak} days\n` +
  `§7§l Last Active:§r ${lastActive}\n` +
  `§6§l-------------------------`
);
  }
}

export default Command;