import { world, system } from "@minecraft/server";
import { Database } from "./functions/database";

const db = new Database("streaksDB");

system.run(async() => {
  const events = ["command", "join_streak", "chat"];
  
  for(const eventName of events) {
  const {
        default: mainEvent
   } = await import(`./events/${eventName}.js`);
  
  
   world[mainEvent.type === 0 ? "beforeEvents" : "afterEvents"][mainEvent.name].subscribe((...args) => mainEvent.run(...args, db))
  }
});